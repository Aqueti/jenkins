/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_Message_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  class Message::Message_private {
  public:
    aqt_Message Message = nullptr;
    aqt_Status status = aqt_STATUS_OKAY;
  };

  Message::Message()
  {
    m_private = new Message_private;
    aqt_Message obj = nullptr;
    m_private->status = aqt_MessageCreate(&obj);
    m_private->Message = obj;
  }

  Message::Message(::std::string deviceID, ::std::string objectID,
	  ::std::string className, ::std::string functionName,
	  ::std::string value, struct timeval time,
	  aqt_MessageLevel level)
  {
    m_private = new Message_private;
    aqt_Message obj;
    m_private->status = aqt_MessageCreate(&obj);
    m_private->Message = obj;
	aqt_Status s = aqt_STATUS_OKAY;
    s = aqt_MessageSetDeviceID(m_private->Message, deviceID.c_str());
    if (s != aqt_STATUS_OKAY) {
      m_private->status = s;
    }
	s = aqt_MessageSetObjectID(m_private->Message, objectID.c_str());
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
	s = aqt_MessageSetClassName(m_private->Message, className.c_str());
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
	s = aqt_MessageSetFunctionName(m_private->Message, functionName.c_str());
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
	s = aqt_MessageSetValue(m_private->Message, value.c_str());
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
	s = aqt_MessageSetTimeStamp(m_private->Message, time);
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
	s = aqt_MessageSetLevel(m_private->Message, level);
	if (s != aqt_STATUS_OKAY) {
		m_private->status = s;
	}
  }

  Message::Message(aqt_Message Message)
  {
    m_private = new Message_private;
    if (!Message) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return;
    }
    m_private->status = aqt_MessageCopy(&m_private->Message, Message);
  }

  Message::~Message()
  {
    if (m_private) {
      if (m_private->Message) {
        aqt_MessageDestroy(m_private->Message);
      }
      delete m_private;
    }
  }

  Message::Message(const Message &copy)
  {
    m_private = new Message_private();
    m_private->status = aqt_MessageCopy(&m_private->Message, copy.RawMessage());
  }

  Message &Message::operator = (const Message &copy)
  {
    if (m_private) {
      if (m_private->Message) {
        aqt_MessageDestroy(m_private->Message);
      }
      delete m_private;
    }
    m_private = new Message_private();
    m_private->status = aqt_MessageCopy(&m_private->Message, copy.RawMessage());
    return *this;
  }

  aqt_Status Message::GetStatus()
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return m_private->status;
  }

  ::std::string Message::DeviceID() const
  {
    ::std::string ret;
    if (!m_private->Message) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *val = "";
    m_private->status = aqt_MessageGetDeviceID(m_private->Message, &val);
    ret = val;
    return ret;
  }

  aqt_Status Message::DeviceID(::std::string deviceID)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetDeviceID(m_private->Message, deviceID.c_str());
  }

  ::std::string Message::ObjectID() const
  {
	  ::std::string ret;
	  if (!m_private->Message) {
		  m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
		  return ret;
	  }
	  const char *val = "";
	  m_private->status = aqt_MessageGetObjectID(m_private->Message, &val);
	  ret = val;
	  return ret;
  }

  aqt_Status Message::ObjectID(::std::string objectID)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetObjectID(m_private->Message, objectID.c_str());
  }

  ::std::string Message::ClassName() const
  {
	  ::std::string ret;
	  if (!m_private->Message) {
		  m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
		  return ret;
	  }
	  const char *val = "";
	  m_private->status = aqt_MessageGetClassName(m_private->Message, &val);
	  ret = val;
	  return ret;
  }

  aqt_Status Message::ClassName(::std::string className)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetClassName(m_private->Message, className.c_str());
  }

  ::std::string Message::FunctionName() const
  {
	  ::std::string ret;
	  if (!m_private->Message) {
		  m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
		  return ret;
	  }
	  const char *val = "";
	  m_private->status = aqt_MessageGetFunctionName(m_private->Message, &val);
	  ret = val;
	  return ret;
  }

  aqt_Status Message::FunctionName(::std::string functionName)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetFunctionName(m_private->Message, functionName.c_str());
  }

  ::std::string Message::Value() const
  {
    ::std::string ret;
    if (!m_private->Message) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *val = "";
    m_private->status = aqt_MessageGetValue(m_private->Message, &val);
    ret = val;
    return ret;
  }

  aqt_Status Message::Value(::std::string val)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetValue(m_private->Message, val.c_str());
  }

  struct timeval Message::TimeStamp() const
  {
	  struct timeval ret = {};
	  if (!m_private->Message) {
		  m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
		  return ret;
	  }
	  m_private->status = aqt_MessageGetTimeStamp(m_private->Message, &ret);
	  return ret;
  }

  aqt_Status Message::TimeStamp(struct timeval val)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetTimeStamp(m_private->Message, val);
  }

  aqt_MessageLevel Message::Level() const
  {
	  aqt_MessageLevel ret = {};
	  if (!m_private->Message) {
		  m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
		  return ret;
	  }
	  m_private->status = aqt_MessageGetLevel(m_private->Message, &ret);
	  return ret;
  }

  aqt_Status Message::Level(aqt_MessageLevel val)
  {
    if (!m_private || !m_private->Message) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_MessageSetLevel(m_private->Message, val);
  }

  aqt_Message const Message::RawMessage() const
  {
    aqt_Message ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (!m_private->Message) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_STATUS_OKAY;
    return m_private->Message;
  }

} // End namespace aqt
