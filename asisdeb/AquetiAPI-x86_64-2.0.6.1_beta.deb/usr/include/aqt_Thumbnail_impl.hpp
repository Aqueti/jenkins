/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_Thumbnail_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class Thumbnail::Thumbnail_private {
    public:
      aqt_Thumbnail Thumbnail = nullptr;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    Thumbnail::Thumbnail()
    {
      m_private = new Thumbnail_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "Thumbnail");
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      aqt_Thumbnail obj = nullptr;
      m_private->status = aqt_ThumbnailCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_ThumbnailSetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->Thumbnail = obj;
    }

    Thumbnail::Thumbnail(aqt_Thumbnail Thumbnail)
    {
      m_private = new Thumbnail_private;
      if (!Thumbnail) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_ThumbnailCopy(&m_private->Thumbnail, Thumbnail);
    }

    Thumbnail::~Thumbnail()
    {
      if (m_private) {
        if (m_private->Thumbnail) {
          aqt_ThumbnailDestroy(m_private->Thumbnail);
        }
        delete m_private;
      }
    }

    Thumbnail::Thumbnail(const Thumbnail &copy)
    {
      if (m_private) {
        if (m_private->Thumbnail) {
          aqt_ThumbnailDestroy(m_private->Thumbnail);
        }
        delete m_private;
      }
      m_private = new Thumbnail_private();
      m_private->status = aqt_ThumbnailCopy(&m_private->Thumbnail, copy.RawThumbnail());
    }

    Thumbnail &Thumbnail::operator = (const Thumbnail &copy)
    {
      m_private = new Thumbnail_private();
      m_private->status = aqt_ThumbnailCopy(&m_private->Thumbnail, copy.RawThumbnail());
      return *this;
    }

    aqt_Status Thumbnail::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval Thumbnail::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetInfo(m_private->Thumbnail, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string Thumbnail::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetInfo(m_private->Thumbnail, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status Thumbnail::Time(struct timeval val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetInfo(m_private->Thumbnail, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status Thumbnail::Name(::std::string val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetInfo(m_private->Thumbnail, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    double Thumbnail::XNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_ThumbnailGetCenter(m_private->Thumbnail, &x, &y);
      ret = x;
      return ret;
    }

    double Thumbnail::YNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_ThumbnailGetCenter(m_private->Thumbnail, &x, &y);
      ret = y;
      return ret;
    }

    double Thumbnail::WidthNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double width, height;
      m_private->status = aqt_ThumbnailGetSize(m_private->Thumbnail, &width, &height);
      ret = width;
      return ret;
    }

    double Thumbnail::HeightNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double width, height;
      m_private->status = aqt_ThumbnailGetSize(m_private->Thumbnail, &width, &height);
      ret = height;
      return ret;
    }

    aqt_ImageType Thumbnail::ImageType() const
    {
      aqt_ImageType ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetThumbnailType(m_private->Thumbnail, &ret))) {
        return ret;
      }
      return ret;
    }

    ::std::vector<uint8_t> Thumbnail::ImageData() const
    {
      ::std::vector<uint8_t> ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetThumbnailDataLength(m_private->Thumbnail, &count))) {
        return ret;
      }
      ret.resize(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_ThumbnailGetThumbnailData(m_private->Thumbnail, ret.data()))) {
        return ret;
      }
      return ret;
    }

    aqt_Status Thumbnail::XNorm(double val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_ThumbnailGetCenter(m_private->Thumbnail, &x, &y);
      x = val;
      return aqt_ThumbnailSetCenter(m_private->Thumbnail, x, y);
    }

    aqt_Status Thumbnail::YNorm(double val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_ThumbnailGetCenter(m_private->Thumbnail, &x, &y);
      y = val;
      return aqt_ThumbnailSetCenter(m_private->Thumbnail, x, y);
    }

    aqt_Status Thumbnail::WidthNorm(double val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double width, height;
      m_private->status = aqt_ThumbnailGetSize(m_private->Thumbnail, &width, &height);
      width = val;
      return aqt_ThumbnailSetSize(m_private->Thumbnail, width, height);
    }

    aqt_Status Thumbnail::HeightNorm(double val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double width, height;
      m_private->status = aqt_ThumbnailGetSize(m_private->Thumbnail, &width, &height);
      height = val;
      return aqt_ThumbnailSetSize(m_private->Thumbnail, width, height);
    }

    aqt_Status Thumbnail::ImageType(aqt_ImageType val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_ThumbnailSetThumbnailType(m_private->Thumbnail, val);
    }

    aqt_Status Thumbnail::ImageData(::std::vector<uint8_t> val)
    {
      if (!m_private || !m_private->Thumbnail) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_ThumbnailSetThumbnailData(m_private->Thumbnail, val.data(),
        static_cast<uint32_t>(val.size()));
    }

    aqt_Thumbnail const Thumbnail::RawThumbnail() const
    {
      aqt_Thumbnail ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->Thumbnail) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->Thumbnail;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

