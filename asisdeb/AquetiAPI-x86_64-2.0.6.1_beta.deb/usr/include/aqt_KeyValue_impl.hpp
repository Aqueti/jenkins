/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_KeyValue_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  class KeyValue::KeyValue_private {
  public:
    aqt_KeyValue KeyValue = nullptr;
    aqt_Status status = aqt_STATUS_OKAY;
  };

  KeyValue::KeyValue()
  {
    m_private = new KeyValue_private;
    aqt_KeyValue obj = nullptr;
    m_private->status = aqt_KeyValueCreate(&obj);
    if (m_private->status != aqt_STATUS_OKAY) {
      return;
    }
    m_private->KeyValue = obj;
  }

  KeyValue::KeyValue(::std::string key, ::std::string value)
  {
    m_private = new KeyValue_private;
    aqt_KeyValue obj;
    m_private->status = aqt_KeyValueCreate(&obj);
    m_private->KeyValue = obj;
    aqt_Status s = aqt_KeyValueSetKey(m_private->KeyValue, key.c_str());
    if (s != aqt_STATUS_OKAY) {
      m_private->status = s;
    }
    s = aqt_KeyValueSetValue(m_private->KeyValue, value.c_str());
    if (s != aqt_STATUS_OKAY) {
      m_private->status = s;
    }
  }

  KeyValue::KeyValue(aqt_KeyValue KeyValue)
  {
    m_private = new KeyValue_private;
    if (!KeyValue) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return;
    }
    m_private->KeyValue = KeyValue;
    m_private->status = aqt_STATUS_OKAY;
  }

  KeyValue::~KeyValue()
  {
    if (m_private) {
      if (m_private->KeyValue) {
        aqt_KeyValueDestroy(m_private->KeyValue);
      }
      delete m_private;
    }
  }

  KeyValue::KeyValue(const KeyValue &copy)
  {
    m_private = new KeyValue_private();
    m_private->status = aqt_KeyValueCopy(&m_private->KeyValue, copy.RawKeyValue());
  }

  KeyValue &KeyValue::operator = (const KeyValue &copy)
  {
    if (m_private) {
      if (m_private->KeyValue) {
        aqt_KeyValueDestroy(m_private->KeyValue);
      }
      delete m_private;
    }
    m_private = new KeyValue_private();
    m_private->status = aqt_KeyValueCopy(&m_private->KeyValue, copy.RawKeyValue());
    return *this;
  }

  aqt_Status KeyValue::GetStatus()
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return m_private->status;
  }

  ::std::string KeyValue::Key() const
  {
    ::std::string ret;
    if (!m_private || !m_private->KeyValue) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *val = "";
    m_private->status = aqt_KeyValueGetKey(m_private->KeyValue, &val);
    ret = val;
    return ret;
  }

  aqt_Status KeyValue::Key(::std::string key)
  {
    if (!m_private || !m_private->KeyValue) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_KeyValueSetKey(m_private->KeyValue, key.c_str());
  }

  ::std::string KeyValue::Value() const
  {
    ::std::string ret;
    if (!m_private || !m_private->KeyValue) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *val = "";
    m_private->status = aqt_KeyValueGetValue(m_private->KeyValue, &val);
    ret = val;
    return ret;
  }

  aqt_Status KeyValue::Value(::std::string val)
  {
    if (!m_private || !m_private->KeyValue) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_KeyValueSetValue(m_private->KeyValue, val.c_str());
  }

  aqt_KeyValue const KeyValue::RawKeyValue() const
  {
    aqt_KeyValue ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (!m_private->KeyValue) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_STATUS_OKAY;
    return m_private->KeyValue;
  }

} // End namespace aqt
