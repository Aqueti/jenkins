/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_ReservationPolicy_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  class ReservationPolicy::ReservationPolicy_private {
  public:
    aqt_ReservationPolicy ReservationPolicy = nullptr;
    aqt_Status status = aqt_STATUS_OKAY;
  };

  ReservationPolicy::ReservationPolicy()
  {
    m_private = new ReservationPolicy_private;
    aqt_ReservationPolicy obj = nullptr;
    m_private->status = aqt_ReservationPolicyCreate(&obj);
    m_private->ReservationPolicy = obj;
  }

  ReservationPolicy::ReservationPolicy(aqt_ReservationPolicy ReservationPolicy)
  {
    m_private = new ReservationPolicy_private;
    if (!ReservationPolicy) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return;
    }
    m_private->ReservationPolicy = ReservationPolicy;
    m_private->status = aqt_STATUS_OKAY;
  }

  ReservationPolicy::~ReservationPolicy()
  {
    if (m_private) {
      if (m_private->ReservationPolicy) {
        aqt_ReservationPolicyDestroy(m_private->ReservationPolicy);
      }
      delete m_private;
    }
  }

  ReservationPolicy::ReservationPolicy(const ReservationPolicy &copy)
  {
    m_private = new ReservationPolicy_private();
    m_private->status = aqt_ReservationPolicyCopy(&m_private->ReservationPolicy, copy.RawReservationPolicy());
  }

  ReservationPolicy &ReservationPolicy::operator = (const ReservationPolicy &copy)
  {
    if (m_private) {
      if (m_private->ReservationPolicy) {
        aqt_ReservationPolicyDestroy(m_private->ReservationPolicy);
      }
      delete m_private;
    }
    m_private = new ReservationPolicy_private();
    m_private->status = aqt_ReservationPolicyCopy(&m_private->ReservationPolicy, copy.RawReservationPolicy());
    return *this;
  }

  aqt_Status ReservationPolicy::GetStatus()
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return m_private->status;
  }

  struct timeval ReservationPolicy::KeepUntil() const
  {
    struct timeval ret = {};
    if (!m_private->ReservationPolicy) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_ReservationPolicyGetKeepUntil(m_private->ReservationPolicy, &ret);
    return ret;
  }

  aqt_Status ReservationPolicy::KeepUntil(struct timeval val)
  {
    if (!m_private || !m_private->ReservationPolicy) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_ReservationPolicySetKeepUntil(m_private->ReservationPolicy, val);
  }

  aqt_ReservationPolicy const ReservationPolicy::RawReservationPolicy() const
  {
    aqt_ReservationPolicy ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (!m_private->ReservationPolicy) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_STATUS_OKAY;
    return m_private->ReservationPolicy;
  }

} // End namespace aqt
