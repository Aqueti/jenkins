/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
 * @file aqt_api.h
 * @brief Aqueti C API, an extensible wrapped API that is exposed by the DLLs.
 *
 * This is the C implementation of the API, which is wrapped both above and below
 * by C++ (an hourglass design) and whose C++ API is wrapped using SWIG into Python.
 * You probably do not want to use this C API directly, but rather want to include
 * the aqt_api.hpp file, but look at the aqt_api_defs.hpp file for the objects that
 * you will actually use.  If you want to write C code directly, then the current file
 * is the one you'll want.  Each of the sets of functions use an opaque pointer to
 * a structure to enable future expansion without requiring code to be recompiled.
 * @author Aqueti.
 * @date February 2, 2018.
*/

//----------------------------------------------------------------------------------------
// Include the configuration file that defines the import or export for DLLs on Windows.
// These are left undefined on other platforms.  The CMake system adds a definition that
// causes export when the library is built and import for other applications.
#include <aqt_export.h>
#include <stdint.h>
#include <stdbool.h>
#ifndef _WIN32
#include <sys/time.h>
#else
#include <Winsock2.h> // For struct timeval
#endif

//----------------------------------------------------------------------------------------
// If we're compiling with a C++ compiler, explicitly mark this section for C export.
// This will keep the symbols unmangled.
#ifdef __cplusplus
extern "C" {
#endif

//---------------------------------------------------------------------------
/// @brief Status enumeration, returned by all aqt_* C API functions.
typedef int aqt_Status;
  /// @brief All is okay.
  #define aqt_STATUS_OKAY (0)

  /// @brief A timeout was exceeded (not an error).
  #define aqt_STATUS_TIMEOUT (1)
  /// @brief There are no more elements available (not an error).
  #define aqt_STATUS_NO_NEXT_ELEMENT (2)

  /// @brief Can be used to see if the return was a system error.
  #define aqt_STATUS_HIGHEST_WARNING (1000)

  /// @brief Error: Bad parameter passed to function.
  #define aqt_STATUS_BAD_PARAMETER (1001)
  /// @brief Error: Out of memory when trying to execute function.
  #define aqt_STATUS_OUT_OF_MEMORY (1002)
  /// @brief Error: Function not yet implemented.
  #define aqt_STATUS_NOT_IMPLEMENTED (1003)
  /// @brief Error: Attempted deletion of a NULL pointer.
  #define aqt_STATUS_DELETE_OF_NULL_POINTER (1004)
  /// @brief Error: Attempting to delete an object failed.
  #define aqt_STATUS_DELETION_FAILED (1005)
  /// @brief Error: Internal failure: calling an object with a NULL object pointer.
  #define aqt_STATUS_NULL_OBJECT_POINTER (1006)
  /// @brief Error: Attempting to reference an object that does not exist.
  #define aqt_STATUS_NO_SUCH_OBJECT (1007)
  /// @brief Error: Attempting to create an object that already exists.
  #define aqt_STATUS_OBJECT_ALREADY_EXISTS (1008)
  /// @brief Error: Function could not open the requested file for writing.
  #define aqt_STATUS_CANNOT_OPEN_FILE_FOR_WRITE (1009)
  /// @brief Error: Function could not write to the requested file.
  #define aqt_STATUS_ERROR_WRITING_FILE (1010)
  /// @brief Error: Internal error: Network failure.
  #define aqt_STATUS_ERROR_NETWORK (1011)
  /// @brief Error: Could not create object.
  #define aqt_STATUS_CREATION_FAILED (1012)
  /// @brief Error: Unexpected internal state.
  #define aqt_STATUS_UNEXPECTED_INTERNAL_STATE (1013)
  /// @brief Error: Object not yet ready for this command.
  #define aqt_STATUS_OBJECT_NOT_READY (1014)
  /// @brief Error: System has insufficient privileges to complete the operation
  #define aqt_STATUS_INSUFFICIENT_PRIVILEGES (1015)

/// @brief Helper function to return a descriptive error message based on a status value.
/// @param [in] status Return value from an aqt_* C API or C++ API call.
/// @return Null-terminated string describing the status condition.
AQT_EXPORT const char *aqt_ErrorMessage(aqt_Status status);

//---------------------------------------------------------------------------
/// @brief Stream type enumeration describing render-stream format.
typedef int aqt_StreamType;
  /// @brief Render Stream type undefined or uninitialized.
  #define aqt_STREAM_TYPE_NONE (-1)
  /// @brief Render Stream should display on a monitor on the renderin machine.
  #define aqt_STREAM_TYPE_LOCALDISPLAY (0)
  /// @brief Render Stream should send JPEG frames.
  #define aqt_STREAM_TYPE_JPEG (1)
  /// @brief Render Stream should send H.264 frames.
  #define aqt_STREAM_TYPE_H264 (2)
  /// @brief Render Stream should send H.265 frames.
  #define aqt_STREAM_TYPE_H265 (3)

//---------------------------------------------------------------------------
/// @brief Image type.  This is used both for the rendering API and the external
/// processing API.
typedef int aqt_ImageType;
  /// @brief Image is empty (not of any defined type).
  #define aqt_EMPTY_IMAGE (0)
  /// @brief Image is JPEG format.
  #define aqt_JPEG_IMAGE (1)
  /// @brief Image is an H.264 I frame.
  #define aqt_H264_I_FRAME (2)
  /// @brief Image is an H.264 P frame.
  #define aqt_H264_P_FRAME (3)
  /// @brief Image is an H.265 I frame.
  #define aqt_H265_I_FRAME (4)
  /// @brief Image is an H.265 P frame.
  #define aqt_H265_P_FRAME (5)

//---------------------------------------------------------------------------
/// @brief Data type enumeration for non-image data in the rendering API and the
/// external processing API.
typedef int aqt_DataType;
  /// @brief Data is empty (not of any defined type).
  #define aqt_DATA_NONE (-1)
  /// @brief Data type is an image.
  #define aqt_DATA_IMAGE (0)
  /// @brief Data type is a rectangle.
  #define aqt_DATA_RECTANGLE (1)
  /// @brief Data type is a point.
  #define aqt_DATA_POINT (2)
  /// @brief Data type is a thumbnail.
  #define aqt_DATA_THUMBNAIL (3)
  /// @brief Data type is an array of floating-point numbers.
  #define aqt_DATA_FLOATARRAY (4)
  /// @brief Data type is an array of unsigned 8-bit integers.
  #define aqt_DATA_U8ARRAY (5)

//---------------------------------------------------------------------------
/// @brief Interval of time, defined as >= start and < end
typedef struct {
  struct timeval start;  ///< Time interval is >= start and < end
  /// Time interval is >= start and < end.  For an interval that is
  /// not yet completed (currently recording), this value will be
  /// aqt_Interval_UNDEFINED_END.
  struct timeval end;
} aqt_Interval;
/// @brief Constant time value for the end of time.
extern AQT_EXPORT const struct timeval aqt_Interval_UNDEFINED_END;

//---------------------------------------------------------------------------
/// @brief Data type enumeration for message levels in the logging and issue
/// systems.
typedef int32_t aqt_MessageLevel;
/// @brief Minimum number representing an information message.
#define aqt_MESSAGE_MINIMUM_INFO (INT32_MIN)
/// @brief Minimum number representing a warning message.
#define aqt_MESSAGE_MINIMUM_WARNING (0)
/// @brief Minimum number representing an error message.
#define aqt_MESSAGE_MINIMUM_ERROR (INT32_MAX/3)
/// @brief Minimum number representing a critical error message.
#define aqt_MESSAGE_MINIMUM_CRITICAL_ERROR (2*aqt_MESSAGE_MINIMUM_ERROR)

//---------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a logging message.
///
/// Use the aqt_MessageGet* functions to read its values.  Call the
/// aqt_MessageSet* functions to set them (not normally called by client code).
/// When done with the info, call aqt_MessageDestroy().

typedef struct aqt_Message_ *aqt_Message;

/// @brief Create a Message and initialize with default values.
/// @param [out] returnMessage Pointer to the Message to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageCreate(aqt_Message *returnMessage);

/// @brief Create a Message and initialize with copies of values from another.
/// @param [out] returnMessage Pointer to the Message to be constructed.
/// @param [in] MessageToCopy The message to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageCopy(aqt_Message *returnMessage,
	aqt_Message MessageToCopy);

/// @brief Destroy a Message.
///
/// Used to destroy Messages obtained from aqt_MessageCreate() or
/// aqt_GetNextLogMessage().
/// @param [in] obj Structure to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageDestroy(aqt_Message obj);

/// @brief Read the Message device ID parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store a pointer to the result.
///        This value is valid until aqt_MessageDestroy() is called on
///        this Message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetDeviceID(aqt_Message obj,
	const char **val);

/// @brief Set the Message device ID parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.  This value is copied in.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetDeviceID(aqt_Message obj,
	const char *val);

/// @brief Read the Message object ID parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store a pointer to the result.
///        This value is valid until aqt_MessageDestroy() is called on
///        this Message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetObjectID(aqt_Message obj,
	const char **val);

/// @brief Set the Message object ID parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.  This value is copied in.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetObjectID(aqt_Message obj,
	const char *val);

/// @brief Read the Message class parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store a pointer to the result.
///        This value is valid until aqt_MessageDestroy() is called on
///        this Message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetClassName(aqt_Message obj,
	const char **val);

/// @brief Set the Message class parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.  This value is copied in.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetClassName(aqt_Message obj,
	const char *val);

/// @brief Read the Message function parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store a pointer to the result.
///        This value is valid until aqt_MessageDestroy() is called on
///        this Message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetFunctionName(aqt_Message obj,
	const char **val);

/// @brief Set the Message function parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.  This value is copied in.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetFunctionName(aqt_Message obj,
	const char *val);

/// @brief Read the Message value parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store a pointer to the result.
///        This value is valid until aqt_MessageDestroy() is called on
///        this Message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetValue(aqt_Message obj,
	const char **val);

/// @brief Set the Message value parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.  This value is copied in.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetValue(aqt_Message obj,
	const char *val);

/// @brief Read the Message timestamp parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetTimeStamp(aqt_Message obj,
	struct timeval *val);

/// @brief Set the Message timestamp parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetTimeStamp(aqt_Message obj,
	struct timeval val);

/// @brief Read the Message level parameter.
/// @param [in] obj Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageGetLevel(aqt_Message obj,
	aqt_MessageLevel *val);

/// @brief Set the Message level parameter.
/// @param [in] obj Structure to use.
/// @param [in] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_MessageSetLevel(aqt_Message obj,
	aqt_MessageLevel val);

//---------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a reservation policy.
///
/// Use the aqt_ReservationPolicyGet* functions to read its values.  Call
/// the aqt_ReservationPolicySet* functions to set them.  When done with the info,
/// call aqt_ReservationPolicyDestroy().

typedef struct aqt_ReservationPolicy_ *aqt_ReservationPolicy;

/// @brief Constant to be passed to StartRecording indication that the system
/// default value should be used.
#define aqt_RESERVATION_POLICY_USE_SYSTEM_DEFAULT (NULL)

/// @brief Create a reservation policy and initialize with default values.
///
/// The default value specifies that the data does not need to be kept.
/// @param [out] returnRP Pointer to the policy to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationPolicyCreate(aqt_ReservationPolicy *returnRP);

/// @brief Create a reservation policy and initialize with copies of values from another.
/// @param [out] returnRP Pointer to the policy to be constructed.
/// @param [in] RPToCopy The policy to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationPolicyCopy(aqt_ReservationPolicy *returnRP,
  aqt_ReservationPolicy RPToCopy);

/// @brief Destroy a ReservationPolicy.
///
/// Used to destroy ReservationPolicys obtained from
/// aqt_ReservationPolicyCreate() or aqt_ReservationInfoGetReservationPolicy()
/// @param [in] rp ReservationPolicy to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationPolicyDestroy(aqt_ReservationPolicy rp);

/// @brief Read the ReservationPolicy keep-until parameter.
/// @param [in] rp Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationPolicyGetKeepUntil(aqt_ReservationPolicy rp,
  struct timeval *val);

/// @brief Set the ReservationPolicy keep-until parameter.
/// @param [in] rp Structure to use.
/// @param [in] val New width to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationPolicySetKeepUntil(aqt_ReservationPolicy rp,
  struct timeval val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a key-value pair.
///
/// Use the aqt_KeyValueGet functions to read its values.  Call
/// the aqt_KeyValueSet functions to set them.  When done with the info,
/// call aqt_KeyValueDestroy().

typedef struct aqt_KeyValue_ *aqt_KeyValue;

/// @brief Create a KeyValue and initialize with default values.
/// @param [out] returnKV Pointer to the KeyValue to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueCreate(aqt_KeyValue *returnKV);

/// @brief Create a KeyValue and initialize with copies of values from another.
/// @param [out] returnKV Pointer to the KeyValue to be constructed.
/// @param [in] KVToCopy The KeyValue to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueCopy(aqt_KeyValue *returnKV, aqt_KeyValue KVToCopy);

/// @brief Destroy a KeyValue, freeing its resources.
///
/// Used to destroy KeyValues obtained from
/// aqt_KeyValueCreate() or aqt_ReservationInfoGetMetaData()
/// @param [in] kv KeyValue to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueDestroy(aqt_KeyValue kv);

/// @brief Read the KeyValue key (returns pointers to stored data).
/// @param [in] kv Structure to use.
/// @param [out] key Pointer to the location to store the result.  This is only
///        valid until aqt_KeyValueDestroy() or aqt_KeyValueSetKey() has been
///        called on the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueGetKey(aqt_KeyValue kv, const char **key);

/// @brief Set the KeyValue key (copies the data in).
/// @param [in] kv Structure to use.
/// @param [in] key New key to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueSetKey(aqt_KeyValue kv, const char *key);

/// @brief Read the KeyValue value (returns pointers to stored data).
/// @param [in] kv Structure to use.
/// @param [out] value Pointer to the location to store the result.  This is only
///        valid until aqt_KeyValueDestroy() or aqt_KeyValueSetValue() has been called
///        on the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueGetValue(aqt_KeyValue kv, const char **value);

/// @brief Set the KeyValue key and value (copies the data in).
/// @param [in] kv Structure to use.
/// @param [in] value New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_KeyValueSetValue(aqt_KeyValue kv, const char *value);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores reservation information.
///
/// Use the aqt_ReservationInfoGet* functions to read its values.  Call
/// the aqt_ReservationInfoSet* functions to set them.  When done with the Info,
/// call aqt_ReservationInfoDestroy().

typedef struct aqt_ReservationInfo_ *aqt_ReservationInfo;

/// @brief Create a reservation Info and initialize with default values.
/// @param [out] returnRI Pointer to the Info to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoCreate(aqt_ReservationInfo *returnRI);

/// @brief Create a reservation info and initialize with copies of values from another.
/// @param [out] returnRI Pointer to the info to be constructed.
/// @param [in] RIToCopy The info to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoCopy(aqt_ReservationInfo *returnRI,
  aqt_ReservationInfo RIToCopy);

/// @brief Destroy a ReservationInfo.
///
/// Used to destroy ReservationInfos obtained from
/// aqt_ReservationInfoCreate() or aqt_APIGetReservationInfo().
/// @param [in] ri ReservationInfo to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoDestroy(aqt_ReservationInfo ri);

/// @brief Get the entity name associated with a ReservationInfo.
/// @param [in] ri Object to use.
/// @param [out] returnName Pointer to a location to store a pointer to the name.
///        This pointer will be valid until aqt_ReservationInfoDestroy() is called
///        or aqt_ReservationInfoSetEntityName() is called.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetEntityName(aqt_ReservationInfo ri,
  const char **returnName);

/// @brief Set the Entity name associated with a ReservationInfo.
/// @param [in] ri Object to use.
/// @param [in] name Name of the Entity who is to be associated with the reservation.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoSetEntityName(aqt_ReservationInfo ri,
  const char *name);

/// @brief Read the ReservationInfo's Interval parameter.
/// @param [in] ri Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetInterval(aqt_ReservationInfo ri,
  aqt_Interval *val);

/// @brief Set the ReservationInfo's Interval parameter.
/// @param [in] ri Structure to use.
/// @param [in] val New interval to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoSetInterval(aqt_ReservationInfo ri,
  aqt_Interval val);

/// @brief Read the ReservationInfo's ReservationPolicy parameter.
///
/// This copies the information in the aqt_ReservationPolicy and does not
/// take ownership of the pointer; the code that created the policy must
/// also destroy it.
/// @param [in] ri Structure to use.
/// @param [out] val Pointer to the location to store the result.
///        The caller must call aqt_ReservationPolicyDestroy() on the
///        result when it is done with it to avoid leaking memory.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetReservationPolicy(aqt_ReservationInfo ri,
  aqt_ReservationPolicy *val);

/// @brief Set the ReservationInfo's ReservationPolicy parameter.
///
/// This copies the data so the caller is responsible for destroying the
/// aqt_ReservationPolicy when they are done with it.
/// @param [in] ri Structure to use.
/// @param [in] val New reservation policy to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoSetReservationPolicy(aqt_ReservationInfo ri,
  aqt_ReservationPolicy val);

/// @brief Get the user name associated with a ReservationInfo.
/// @param [in] ri Object to use.
/// @param [out] returnName Pointer to a location to store a pointer to the name.
///        This pointer will be valid until aqt_ReservationInfoDestroy() is called
///        or aqt_ReservationInfoSetUserName() is called.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetUserName(aqt_ReservationInfo ri,
  const char **returnName);

/// @brief Set the user name associated with a ReservationInfo.
/// @param [in] ri Object to use.
/// @param [in] name Name of the user who is to be associated with the reservation.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoSetUserName(aqt_ReservationInfo ri,
  const char *name);

/// @brief Returns how many entries there are in the KeyValue array for a ReservationInfo.
///
/// This function should be called before calling aqt_ReservationInfoGetMetaData() so
/// that the client knows how many values are present.  It remains valid until
/// aqt_ReservationInfoDestroy() or aqt_ReservationInfoSetMetaData() are called
/// on this object.
/// @param [in] ri Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetNumMetaData(aqt_ReservationInfo ri, uint32_t *returnVal);

/// @brief Reads a metadata entry associated with a ReservationInfo().
///
/// The function aqt_ReservationInfoGetNumMetaData() should be called to find out
/// how many entries are available.
/// @param [in] ri Object to use.
/// @param [in] which Which MetaData to retrieve, 0 being the first one.  This
///        must be less than the value returned by aqt_ReservationInfoGetNumMetaData().
/// @param [out] returnVal Pointer to location to copy the result to.  The caller must
///        call aqt_KeyValueDestroy() on the result when it is finished with it.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoGetMetaData(aqt_ReservationInfo ri, uint32_t which,
  aqt_KeyValue *returnVal);

/// @brief Sets the MetaData values associated with a ReservationInfo().
///
/// The values are copied in, so they should be both allocated and destroyed by the
/// caller.
/// @param [in] ri Object to use.
/// @param [in] data Pointer to the start of an array of meta data values to be set.
/// @param [in] count Number of meta data entries in the array.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ReservationInfoSetMetaData(aqt_ReservationInfo ri,
  aqt_KeyValue *data, uint32_t count);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores an image.
///
/// This stores information about an image retured by the external analysis
/// API, as well as a pointer to its data.
///
/// aqt_ExternalAnalysisGetNextImage() returns an image.
/// Use the aqt_ImageGet* functions to read its values.  When done with an image,
/// call aqt_ImageDestroy().
///
/// The Set* functions are used by the internal code and are not normally used by client code.

typedef struct aqt_Image_ *aqt_Image;

/// @brief Type of a deletion function, not normally used by client code.
typedef void(*aqt_DeletionFunction)(void *userData, const uint8_t *dataToDelete);

/// @brief Create an image and initialize with default values.
/// @param [out] returnIm Pointer to the image to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageCreate(aqt_Image *returnIm);

/// @brief Create an image and initialize with copies of values from another image.
///
/// The data pointed to by the image is not copied, only a pointer to it.
/// @param [out] returnIm Pointer to the image to be constructed.
/// @param [in] imageToCopy The image to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageCopy(aqt_Image *returnIm, aqt_Image imageToCopy);

/// @brief Destroy an image.
///
/// Used to destroy images obtained from aqt_ExternalAnalysisGetNextImage(),
/// aqt_ImageCreate(), or aqt_ImageCopy().  Does not free the underlying image
/// data -- call aqt_ImageReleaseData() to do that.
/// @param [in] im Image to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageDestroy(aqt_Image im);

/// @brief Read the image width.
/// @param [in] im Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageGetWidth(aqt_Image im, uint32_t *val);

/// @brief Set the image width.  Not normally called by client code.
/// @param [in] im Structure to use.
/// @param [in] val New width to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageSetWidth(aqt_Image im, uint32_t val);

/// @brief Read the image height.
/// @param [in] im Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageGetHeight(aqt_Image im, uint32_t *val);

/// @brief Set the image height.  Not normally called by client code.
/// @param [in] im Structure to use.
/// @param [in] val New height to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageSetHeight(aqt_Image im, uint32_t val);

/// @brief Read the image acquisition time.
/// @param [in] im Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageGetTime(aqt_Image im, struct timeval *val);

/// @brief Set the image acquisition time.  Not normally called by client code.
/// @param [in] im Structure to use.
/// @param [in] val New time to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageSetTime(aqt_Image im, struct timeval val);

/// @brief Read the image type.
/// @param [in] im Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageGetType(aqt_Image im, aqt_ImageType *val);

/// @brief Set the image type.  Not normally called by client code.
/// @param [in] im Structure to use.
/// @param [in] val New type to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageSetType(aqt_Image im, aqt_ImageType val);

/// @brief Read a pointer to the image data and size.
/// @param [in] im Structure to use.
/// @param [out] data Pointer to a pointer to the binary image data.
///              The data is not copied, only a pointer to the data is stored.
/// @param [out] size Pointer to a location to store the image size.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageGetData(aqt_Image im, const uint8_t **data, uint32_t *size);

/// @brief Set the image type.  Not normally called by client code.
/// @param [in] im Structure to use.
/// @param [in] data Pointer to the binary image data.
///              The data is not copied, only a pointer to the data is stored.
/// @param [in] size The image size.
/// @param [in] deleteFunction Pointer to a deletion function, or NULL for no deletion.
/// @param [in] userData Passed back to the deleteFunction, may be NULL.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageSetData(aqt_Image im, const uint8_t *data, uint32_t size,
  aqt_DeletionFunction deleteFunction, void *userData);

/// @brief Read a pointer to the image data and size.
///
/// This function will be implemented in such a way that it is robust to being
/// called multiple times to release the same data, with the second and later calls
/// doing nothing.
/// @param [in] im Structure to use.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ImageReleaseData(aqt_Image im);

//---------------------------------------------------------------------------
// Aqueti overall API class and its parameters and methods.

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores parameters to pass to aqt_APICreate().
typedef struct aqt_APICreateParams_ *aqt_APICreateParams;

/// @brief Construct a set of parameters that can be used to construct an API.
///
/// Constructs a set of parameters to be passed to aqt_APICreate().  The various
/// parameters should be set here before calling that routine.  Once the API has been
/// created, call aqt_APICreateParamatersDestroy() to free the resources associated
/// with this parameter set.
/// @param [out] returnParams Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersCreate(aqt_APICreateParams *returnParams);

/// @brief Destroy a set of parameters created by aqt_APICreateParametersCreate().
/// @param [in] params Object that was created by aqt_APICreateParametersCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersDestroy(aqt_APICreateParams params);

/// @brief Get the user name previously set by aqt_APICreateParametersSetName().
/// @param [in] params Object that was created by aqt_APICreateParametersCreate().
/// @param [out] returnName Pointer to a location to store a pointer to the name.
///        This pointer will be valid until aqt_APICreateParametersDestroy() is called
///        on these params.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersGetName(
  aqt_APICreateParams params,
  const char **returnName);

/// @brief Set the name of the user who is connecting to the API.
/// @param [in] params Object that created by aqt_APICreateParametersCreate().
/// @param [in] name Name of the user who is connecting to the API.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersSetName(
  aqt_APICreateParams params,
  const char *name);

/// @brief Get the user name previously set by aqt_APICreateParametersSetCredentials().
/// @param [in] params Object that was created by aqt_APICreateParametersCreate().
/// @param [out] returnCredentials Pointer to a location to store a pointer to the credentials.
///        This pointer will be valid until aqt_APICreateParametersDestroy() is called
///        on these params.
/// @param [out] returnSize Pointer to a location to store the size of the pointed-to
///        credentials.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersGetCredentials(
  aqt_APICreateParams params,
  const uint8_t **returnCredentials, uint32_t *returnSize);

/// @brief Set the credentials of the user who is connecting to the API.
/// @param [in] params Object that created by aqt_APICreateParametersCreate().
/// @param [in] credentials Credentials of the user who is connecting to the API.
/// @param [in] size Size in bytes of the credentials.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersSetCredentials(
  aqt_APICreateParams params,
  const uint8_t *credentials, uint32_t size);

/// @brief Add a URL to be tested to see if it points to an active API server.
/// @param [in] params Object that created by aqt_APICreateParametersCreate().
/// @param [in] URL URL to add to list of those to be tested.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersAddConnectionURL(
  aqt_APICreateParams params,
  const char *URL);

/// @brief Get the number of specific URLs that have been added to search for.
/// @param [in] params Object that was created by aqt_APICreateParametersCreate().
/// @param [out] returnCount Pointer to location to store the number of URLs.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersGetConnectionURLCount(
  aqt_APICreateParams params,
  uint32_t *returnCount);

/// @brief Get a URL previously added by aqt_APICreateParametersAddConnectionURL().
/// @param [in] params Object that was created by aqt_APICreateParametersCreate().
/// @param [in] which Index (starts with 0) of the URL to retrieve.  The function
///        aqt_APICreateParametersGetConnectionURLCount() returns how many there are.
/// @param [out] returnURL Pointer to a location to store a pointer to the URL.
///        This pointer will be valid until aqt_APICreateParametersDestroy() is called
///        on these params.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateParametersGetConnectionURL(
  aqt_APICreateParams params,
  uint32_t which,
  const char **returnURL);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that manages an API.
typedef struct aqt_API_ *aqt_API;

/// @brief Construct an API.
///
/// aqt_APIDestroy() should be called when the application is finished with the API
/// to avoid leaking resources.
/// @param [out] returnAPI Pointer to location to store the result, not changed on error.
/// @param [in] params Parameters to use when constructing the API.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreate(aqt_API *returnAPI, aqt_APICreateParams params);

/// @brief Destroy an API.
/// @param [in] api API returned from aqt_APICreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIDestroy(aqt_API api);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores Camera intrinsic parameters.
///
/// A vector of these structures is contained in aqt_APICameraInfo.  There can be
/// multiple such instances for a single camera, with different minimum-pixel sizes.
/// An application should select the one that has the desired resolution.
///
/// Use the aqt_APICameraInstrinsicGet* functions to read its values.

typedef struct aqt_APICameraIntrinsic_ *aqt_APICameraInstrinsic;

/// @brief Read the width of the viewpoint in degrees.
/// @param [in] intrinsic Parameter set to use.
/// @param [out] returnWidth Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraInstrinsicGetWidthDegrees(
  aqt_APICameraInstrinsic intrinsic, double *returnWidth);

/// @brief Read the height of the viewpoint in degrees.
/// @param [in] intrinsic Parameter set to use.
/// @param [out] returnHeight Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraInstrinsicGetHeightDegrees(
  aqt_APICameraInstrinsic intrinsic, double *returnHeight);

/// @brief Read the maximum dimension of minimum-sized pixel in degrees.
/// @param [in] intrinsic Parameter set to use.
/// @param [out] returnSize Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraInstrinsicGetPixelSizeDegrees(
  aqt_APICameraInstrinsic intrinsic, double *returnSize);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores Camera extrinsic parameters.
///
/// This reports the position and orientation of the camera.  The position is stored
/// in longitude (fractional degrees), latitude (fractional degrees) and altitude
/// above sea level (meters).  The orientation is the yaw (rotation about Z, applied
/// first), pitch (rotation about Y, applied second), and roll (rotation about X,
/// applied last) with respect to a right-handed coordinate system describing a
/// camera whose principal ray is pointing up along -Z and whose X axis (towards the
/// right in the image) is pointing East, and whose Y axis (from the bottom of the
/// image towards the top) is pointing North; the Yaw, Pitch, and Roll describe how
/// to rotate this canonical camera to point in the direction of the actual camera.
///
/// An instance of this structure is contained in aqt_APICameraInfo.
///
/// Use the aqt_APICameraExtrinsicGet* functions to read its values.

typedef struct aqt_APICameraExtrinsic_ *aqt_APICameraExtrinsic;

/// @brief Read the latitude of the camera location in degrees.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnLatitude Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetLatitude(
  aqt_APICameraExtrinsic extrinsic, double *returnLatitude);

/// @brief Read the longitude of the camera location in degrees.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnLongitude Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetLongitude(
  aqt_APICameraExtrinsic extrinsic, double *returnLongitude);

/// @brief Read the altitude above sea level of the camera location in meters.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnAltitude Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetAltitude(
  aqt_APICameraExtrinsic extrinsic, double *returnAltitude);

/// @brief Read the roll of the camera orientation in degrees.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnRoll Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetRoll(
  aqt_APICameraExtrinsic extrinsic, double *returnRoll);

/// @brief Read the pitch of the camera orientation in degrees.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnPitch Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetPitch(
  aqt_APICameraExtrinsic extrinsic, double *returnPitch);

/// @brief Read the yaw of the camera orientation in degrees.
/// @param [in] extrinsic Parameter set to use.
/// @param [out] returnYaw Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraExtrinsicGetYaw(
  aqt_APICameraExtrinsic extrinsic, double *returnYaw);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a single-center-of-projection camera description.
///
/// The Name in this structure is used to identify the camera to other objects in the
/// system.  Its intrinsic and extrinsic parameters can be used to determine which
/// cameras to use.
///
/// Use the aqt_APICameraGet* functions to read its values.

typedef struct aqt_APICameraInfo_ *aqt_APICameraInfo;

/// @brief Read the count of camera intrinsic parameters.
///
/// Call this function to find out how many sets of intrinsic parameters
/// there are in a camera before calling aqt_APICameraGetIntrinsic() to read
/// each one.
/// @param [in] info Info to use.
/// @param [out] returnCount Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraGetIntrinsicCount(
  aqt_APICameraInfo info, uint32_t *returnCount);

/// @brief Read one intrinsic calibration for the camera.
/// @param [in] info Info to use.
/// @param [in] which Index of the calibration to read, with the first
///        being 0.  Before calling this, you can call aqt_APICameraGetIntrinsicCount()
///        to find out how many calibrations there are.
/// @param [out] returnIntrinsic Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraGetIntrinsic(
  aqt_APICameraInfo info, uint32_t which,
  aqt_APICameraInstrinsic *returnIntrinsic);

/// @brief Read the extrinsic calibration of the camera.
/// @param [in] info Info to use.
/// @param [out] returnExtrinsic Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraGetExtrinsic(
  aqt_APICameraInfo info, aqt_APICameraExtrinsic *returnExtrinsic);

/// @brief Read the name of the camera.
/// @param [in] info Info to use.
/// @param [out] returnName Pointer to location to store a pointer to the constant
///              null-terminated string holding the camera name.  This pointer will
///              remain valid until the next call to aqt_APIGetAvailableCameraCount()
///              or until aqt_APIDestroy() is called, so it should be copied if it is to be
///              used after that.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICameraGetName(
  aqt_APICameraInfo info, const char **returnName);

/// @brief Latches camera information for retrieval by aqt_APIGetAvailableCameraInfo().
///
/// This function latches the camera information until the next call to this
/// function, so that calls to aqt_APIGetAvailableCameraInfo() will return
/// consistent results.
/// This function must be called before aqt_APIGetAvailableCameraInfo() will return
/// non-empty results.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnCount Pointer to the location to store the results.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_APIGetAvailableCameraCount(aqt_API api,
  uint32_t *returnCount);

/// @brief Reads information latched by aqt_APIGetAvailableCameraCount().
///
/// The function aqt_APIGetAvailableCameraCount() must be called to latch the camera
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] which Index of the camera info to read, with the first
///        being 0.  Before calling this, you can call aqt_APIGetAvailableCameraCount()
///        to find out how many cameras there are.
/// @param [out] returnInfo Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetAvailableCameraInfo(aqt_API api, uint32_t which,
  aqt_APICameraInfo *returnInfo);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a renderer description.
///
/// The Name in this structure is used to identify the renderer to other objects in the
/// system.
///
/// Use the aqt_APIRendererGet* functions to read its values.

typedef struct aqt_APIRendererInfo_ *aqt_APIRendererInfo;

/// @brief Read the name of the renderer.
/// @param [in] info Structure to get the information from.
/// @param [out] returnName Pointer to location to store a pointer to the constant
///              null-terminated string holding the renderer name.  This pointer will
///              remain valid until the next call to aqt_APIGetAvailableRendererCount()
///              or until aqt_APIDestroy() is called, so it should be copied if it is to be
///              used after that.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIRendererGetName(
  aqt_APIRendererInfo info, const char **returnName);

/// @brief Latches renderer information for retrieval by aqt_APIGetAvailableRendererInfo().
///
/// This function latches the renderer information until the next call to this
/// function, so that calls to aqt_APIGetAvailableRendererInfo() will return
/// consistent results.
/// This function must be called before aqt_APIGetAvailableRendererInfo() will return
/// non-empty results.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnCount Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_APIGetAvailableRendererCount(aqt_API api,
  uint32_t *returnCount);

/// @brief Reads information latched by aqt_APIGetAvailableRendererCount().
///
/// The function aqt_APIGetAvailableRendererCount() must be called to latch the renderer
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] which Index of the renderer info to read, with the first
///        being 0.  Before calling this, you can call aqt_APIGetAvailableRendererCount()
///        to find out how many renderers there are.
/// @param [out] returnInfo Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetAvailableRendererInfo(aqt_API api, uint32_t which,
  aqt_APIRendererInfo *returnInfo);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a DataRouter description.
///
/// The Name in this structure is used to identify the DataRouter to other objects in the
/// system.
///
/// Use the aqt_APIDataRouterGet* functions to read its values.

typedef struct aqt_APIDataRouterInfo_ *aqt_APIDataRouterInfo;

/// @brief Read the name of the DataRouter.
/// @param [in] info Structure to get the information from.
/// @param [out] returnName Pointer to location to store a pointer to the constant
///              null-terminated string holding the DataRouter name.  This pointer will
///              remain valid until the next call to aqt_APIGetAvailableDataRouterCount()
///              or until aqt_APIDestroy() is called, so it should be copied if it is to be
///              used after that.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIDataRouterGetName(
  aqt_APIDataRouterInfo info, const char **returnName);

/// @brief Latches DataRouter information for retrieval by aqt_APIGetAvailableDataRouterInfo().
///
/// This function latches the DataRouter information until the next call to this
/// function, so that calls to aqt_APIGetAvailableDataRouterInfo() will return
/// consistent results.
/// This function must be called before aqt_APIGetAvailableDataRouterInfo() will return
/// non-empty results.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnCount Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_APIGetAvailableDataRouterCount(aqt_API api,
  uint32_t *returnCount);

/// @brief Reads information latched by aqt_APIGetAvailableDataRouterCount().
///
/// The function aqt_APIGetAvailableDataRouterCount() must be called to latch the DataRouter
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] which Index of the DataRouter info to read, with the first
///        being 0.  Before calling this, you can call aqt_APIGetAvailableDataRouterCount()
///        to find out how many DataRouters there are.
/// @param [out] returnInfo Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetAvailableDataRouterInfo(aqt_API api, uint32_t which,
  aqt_APIDataRouterInfo *returnInfo);

/// @brief Reads the current system time for the camera.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnTime Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetCurrentSystemTime(aqt_API api, struct timeval *returnTime);

/// @brief Enumerates the formats available for external storage.
typedef int aqt_ExternalDataFormat;
/// @brief External format is a Zip archive.
#define aqt_EXTERNAL_FORMAT_ZIP (0)
/// @brief External format is a gnu-zipped tar archive.
#define aqt_EXTERNAL_FORMAT_TGZ (1)

/// @brief Exports the specified range of the specified data from the specified entity.
/// @param [in] api Object returned by aqt_APICreate().
/// @param outputURL Description of the file or other location to store the exported data to.
/// @param format External format to use when storing the data.
/// @param entityName Name of the entity whose data is to be exported.  Can be obtained with
///        aqt_APICameraGetName() and other similar functions.  The character '*'
///        can be used to specify "any" for a portion of the name; just the name * will export
///        all entities to the file.
/// @param [in] interval Range of time over which data should be exported.  To
///        export all time, set the start to 0 and the end to aqt_Interval_UNDEFINED_END.
/// @param [in] types Vector of data types to be exported, or NULL to export all data types.
/// @param [in] numTypes Number of types to be exported, or 0 to export all data types.
/// @return aqt_STATUS_OKAY on success, a specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIExportStoredDataRange(aqt_API api, const char *outputURL,
  aqt_ExternalDataFormat format,
  const char *entityName, aqt_Interval interval, aqt_DataType *types, uint32_t numTypes);

/// @brief Imports the specified range of the specified data from the specified entity.
/// @param [in] api Object returned by aqt_APICreate().
/// @param inputURL Description of the file or other location to read the imported data from.
/// @param format External format that was used when storing the data.
/// @param entityName Name of the entity whose data is to be imported.  The character '*'
///        can be used to specify "any" for a portion of the name; just the name * will import
///        all entities from the file.
/// @param [in] interval Range of time over which data should be imported.  To
///        import all time, set the start to 0 and the end to aqt_Interval_UNDEFINED_END.
/// @param [in] types Vector of data types to be imported, or NULL to
///        import all data types.
/// @param [in] numTypes Number of types to be imported, or 0 to import all data types.
/// @return aqt_STATUS_OKAY on success, a specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIImportStoredDataRange(aqt_API api, const char *inputURL,
  aqt_ExternalDataFormat format,
  const char *entityName, aqt_Interval interval, aqt_DataType *types, uint32_t numTypes);

/// @brief Latches status and returns length for retrieval by aqt_APIGetDetailedStatus().
///
/// This function latches the detailed status information until the next call to this
/// function as well as returning the length of the detailed status so that the caller
/// can allocate resources before calling aqt_APIGetDetailedStatus().
/// This function must be called before aqt_APIGetDetailedStatus() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] entityName Name of the entity within the system whose status is to be
///        returned.  This can be the name in the various aqt_API*Info types, where
///        * = Render, Camera, DataRouter.
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_APIGetDetailedStatusLength(aqt_API api, const char *entityName,
  uint32_t *returnVal);

/// @brief Reads status latched by aqt_APIGetDetailedStatusLength().
///
/// The function aqt_APIGetDetailedStatusLength() must be called to latch the
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_APIGetDetailedStatusLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetDetailedStatus(aqt_API api, char *returnVal);

/// @brief Latches parameters and returns length for retrieval by aqt_APIGetParameters().
///
/// This function latches the parameters until the next call to this
/// function as well as returning the length of the parameters so that the caller
/// can allocate resources before calling aqt_APIGetParameters().
/// This function must be called before aqt_APIGetParameters() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] entityName Name of the entity within the system whose status is to be
///        returned.  This can be the name in the various aqt_API*Info types, where
///        * = Render, Camera, DataRouter.
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_APIGetParametersLength(aqt_API api, const char *entityName,
  uint32_t *returnVal);

/// @brief Reads parameters latched by aqt_APIGetParametersLength().
/// The function aqt_APIGetParametersLength() must be called to latch the
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_APIGetParametersLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetParameters(aqt_API api, char *returnVal);

/// @brief Set parameters for an entity in the system.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] entityName Name of the entity within the system whose status is to be
///        returned.  This can be the name in the various aqt_API*Info types, where
///        * = Render, Camera, DataRouter.
/// @param [in] val JSON-formatted string describing the parameters to be set and
///        their new settings.  A complete set of parameters can be retrieved for an
///        object by calling aqt_APIGetParameters() on that object.  It is okay to
///        set the entire parameter set or only a subset of the parameters.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetParameters(aqt_API api, const char *entityName, const char *val);

/// @brief Returns length of and latches name information for retrieval by aqt_APIGetExternalNTPServerName().
///
/// This function latches the NTP server name until the next call to this
/// function and returns the length of the name so that the caller can allocate
/// sufficient resources.
/// This function must be called before aqt_APIGetExternalNTPServerName() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetExternalNTPServerNameLength(aqt_API api, uint32_t *returnVal);

/// @brief Reads status latched by aqt_APIGetExternalNTPServerNameLength().
///
/// The function aqt_APIGetExternalNTPServerNameLength() must be called to latch the
/// information before this function will return anything.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_APIGetExternalNTPServerNameLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetExternalNTPServerName(aqt_API api, char *returnVal);

/// @brief Set the name of the NTP server to be used by the system.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] val Domain name or dotted-decimal IP address of the external NTP server
///        to be used by the system.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetExternalNTPServerName(aqt_API api, const char *val);

/// @brief Latches data and returns length for later retrieval by aqt_APIGetUserData().
///
/// This function latches the user data until the next call to this
/// function and returns the length of the data so that the caller can allocate
/// sufficient resources.
/// This function must be called before aqt_APIGetUserData() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] baseName The base name to query by.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  If there is
///         no user data associated with this name, aqt_STATUS_NO_SUCH_OBJECT is returned.
AQT_EXPORT aqt_Status aqt_APIGetUserDataLength(aqt_API api, const char *baseName, uint32_t *returnVal);

/// @brief Reads user-associated string latched by aqt_APIGetUserDataLength().
///
/// The API provides an internal database that maps user-supplied strings
/// to other user-supplied strings.  This can be used to provide "nicknames"
/// or aliases to devices in the system, which can help a user interface
/// provide short, memorable names for them.  For example, by mapping the
/// camera name returned by GetAvailableCameras()[0].Name() to "Front door",
/// the system can provide a user-meaningful name.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] baseName The base name whose alias should be returned.
/// @param [out] returnVal Pointer to location to store the result, allocated by caller.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetUserData(aqt_API api, const char *baseName, char *returnVal);

/// @brief Set string associated with a user-defined string.
///
/// The API provides an internal database that maps user-supplied strings
/// to other user-supplied strings.  This can be used to provide "nicknames"
/// or aliases to devices in the system, which can help a user interface
/// provide short, memorable names for them.  For example, by mapping the
/// camera name returned by GetAvailableCameras()[0].Name() to "Front door",
/// the system can provide a user-meaningful name.  This function lets you
/// set the string.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] baseName The base name by which the user data will be looked up.  If there has
///             previously been set data for this baseName, it will be overwritten by the
///             new data.
/// @param [in] userData Data that is to be associated with the baseName.  If this is a NULL
///             pointer or a pointer to \0, clear the user data associated with baseName.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetUserData(aqt_API api, const char *baseName, const char *userData);

//----------------------------------------------------------------------------------------
/// @brief Type declaration for log message callback handler function.
///
/// Function declaration for the type of a callback handler that will be called
/// to handle a new log message.  This includes the message data and a user-data pointer
/// that the caller passed in.
/// @param [in] message The message that has been received.
/// @param [in] userData Pointer to the data that was passed into the userData
///             parameter for the aqt_LogMessageCallback function, handed
///             back here so that the client can tell itself how to behave.  This
///             is usually cast into a pointer to the actual object type.
typedef void(*aqt_LogMessageCallback)(aqt_Message const frame, void *userData);

/// @brief Set the streaming state for log messages.  Must be set true to receive messages.
/// @param [in] api aqt_API created by calling aqt_APICreate().
/// @param [in] running Set to true begin streaming, false to stop.  The API
///        starts out not streaming.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetLogMessageStreamingState(aqt_API api, bool running);

/// @brief Set a callback function to be called on each new log message.
///
/// Either aqt_LogMessageSetStreamCallback() or aqt_GetNextLogMessage() should
/// be used to get messages, but not both.  If the callback handler
/// is set, it will be called from a separate thread whenever a new message is available.
/// If there is no callback handler set, messages will queue up in memory until the program calls
/// aqt_GetNextLogMessage().
/// @param [in] api aqt_API created by calling aqt_APICreate().
/// @param [in] handler Function to call from the receiving thread whenever a new message
///        is received.  Set to NULL to disable.    Note: The receiver
///        must destroy the message by calling aqt_MessageDestroy() when it is
///        done with it.
/// @param [in] userData Pointer that is passed into the function whenever it is called.
///        Should point to a variable or structure or class object that has all of the state
///        that the function needs to process a message.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetLogMessageCallback(aqt_API api,
	aqt_LogMessageCallback handler, void *userData);

/// @brief Get the next available log message.
///
/// Either aqt_APISetLogMessageCallback() or aqt_APIGetNextLogMessage() should
/// be used to get log messages, but not both.  If the callback handler
/// is set, it will be called from a separate thread whenever a new message is available.
/// If there is no callback handler set, messages will queue up in memory until the program calls
/// aqt_APIGetNextLogMessage().
/// @param [in] api aqt_API created by calling aqt_APICreate().
/// @param [in] message A pointer to the message that has been received.  Note: The receiver
///        must destroy the message by calling aqt_MessageDestroy() when it is
///        done with it.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_TIMEOUT and sets the message pointer to NULL if there is
///        not a message available.
AQT_EXPORT aqt_Status aqt_APIGetNextLogMessage(aqt_API api, aqt_Message *message);

/// @brief Sets the range of message levels to be returned.
///
/// This method filters log messages so that only those of sufficient urgency
/// are returned.  It should be called before streaming is enabled.
/// @param [in] api aqt_API created by calling aqt_APICreate().
/// @param level Minimum level to be returned, defaults to aqt_MESSAGE_MINIMUM_INFO.
/// @return aqt_STATUS_OKAY on success, a specific error code on failure.
AQT_EXPORT aqt_Status aqt_APISetLogMessageMinimumLevel(aqt_API api, aqt_MessageLevel level);

/// @cond IGNORE_FOR_NOW
/// @brief Filters the events for a following issue report to a specific entity.
///
/// This can be called before aqt_APICreateIssueReport() to limit the events in
/// the issue report to a specific entity in the system.  This is not normally called.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] entityName Name of the entity for which logs should be retrieved;
///        defaults to all entities in the system.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
/// @todo Make variable parameters to this function and fill them in.
/// AQT_EXPORT aqt_Status aqt_APIIssueReportSetNameFilter(aqt_API api, const char *entityName);

/// @brief Filters the events for a following issue report to a time range.
///
/// This can be called before aqt_APICreateIssueReport() to limit the events in
/// the issue report to a specific time range.  This is not normally called.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] interval Range of time to report events for.  Defaults to a system-
///        specified range up to the present.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
/// @todo Make variable parameters to this function and fill them in.
/// AQT_EXPORT aqt_Status aqt_APIIssueReportSetIntervalFilter(aqt_API api, aqt_Interval interval);

/// @brief Filters the events for a following issue report to those above a specified level.
///
/// This can be called before aqt_APICreateIssueReport() to limit the events in
/// the issue report to those at or above the specified level.  This is not normally called.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] level Minimum level of event to report.  Defaults to all events.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
/// @todo Make variable parameters to this function and fill them in.
/// AQT_EXPORT aqt_Status aqt_APIIssueReportSetLevelFilter(aqt_API api, aqt_EventType level);
/// @endcond IGNORE_FOR_NOW

/// @brief Creates a file containing an issue report including system state.
///
/// This will create a file containing a complete description of the state
/// of every device in the system along with a user-supplied summary and
/// user-supplied description.  This file is intended to be sent to Aqueti
/// as an error report, with the information aiding in the debugging of the
/// problem.  **This function may take a long time to complete.**
/// If it is not desired to get all information at all levels and default time
/// duration from all entities in the system, one or more of the
/// aqt_APIFilterIssueReport*() functions should be called ahead of time.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] fileNameToWrite Path and name to the file to write the
///        information to.  This should be a name on the client computer.
/// @param [in] summary Summary information to be included in the report.
/// @param [in] description Detailed description of the issue to be included
///        in the report.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICreateIssueReport(aqt_API api, const char *fileNameToWrite,
  const char *summary, const char *description);

/// @brief Length of the reservation ID type.
#define aqt_ReservationIDLength (25)
/// @brief Reservation ID type.
typedef char aqt_ReservationID[aqt_ReservationIDLength];
  /// @brief Invalid ID returned in case of an error.
  #define aqt_ReservationID_INVALID ("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0")

/// @brief Adds a data reservation to the system.
///
/// This adds a new reservation to the system, which describes how long to keep data
/// in a specified range from a specified entity.  It also associates a user and other
/// data with the reservation.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] reservation Information about the reservation to add.
/// @param [out] returnID A pointer to a place to store the ID of the reservation, or NULL
///        to ignore the ID.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIAddReservation(aqt_API api, aqt_ReservationInfo reservation,
  aqt_ReservationID *returnID);

/// @brief Latches the IDs for data reservations in the system and returns how many there are.
///
/// This stores an internal array of the available reservation IDs in the system and returns
/// how many are in this array.  This must be called before aqt_APIGetReservationIDs() will
/// return any values.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] searchParams Parameters used to restrict the search results to a desired
///        subset of the reservations.  Fill in non-default entries for each field in the
///        structure passed on to restrict to reservations with that value.  Any field that
///        is left at the default value will not restrict the search.  An unrestricted search
///        will result in all reservations in the system being returned.
/// @param [out] returnCount A pointer to a place to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetNumReservationIDs(aqt_API api, aqt_ReservationInfo searchParams,
  uint32_t *returnCount);

/// @brief Retrieves reservation ID latched by aqt_APIGetNumReservationIDs().
///
/// This reads an ID latched by the most recent call to aqt_APIGetNumReservationIDs(),
/// which must be called before a value can be returned.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] which Index of the ID to return.  The first is 0 and this must be
///        less than the count returned by aqt_APIGetNumReservationIDs().
/// @param [out] returnID A pointer to a place to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetReservationID(aqt_API api, uint32_t which,
  aqt_ReservationID *returnID);

/// @brief Retrieves reservation information associated with the specified ID.
///
/// This uses a reservation ID obtained either by aqt_APIAddReservation() or
/// by aqt_APIGetReservationID() to find the associated aqt_ReservationInfo.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] ID Identifier to look up.
/// @param [out] returnInfo A pointer to a place to store the result on success,
///        a NULL pointer on failure.  The caller must call aqt_ReservationInfoDestroy()
///        on the object (on success) when it is done with it to avoid leaking memory.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIGetReservationInfo(aqt_API api, aqt_ReservationID ID,
  aqt_ReservationInfo *returnInfo);

/// @brief Replaces a data reservation to the system.
///
/// This replaces an existing reservation to the system, which describes how long to keep data
/// in a specified range from a specified entity.  It also associates new user and other
/// data with the reservation.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] ID Identifier of the reservation to replace.
/// @param [in] reservation Information about the reservation to add.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIReplaceReservation(aqt_API api, aqt_ReservationID ID,
  aqt_ReservationInfo reservation);

/// @brief Cancel the reservation associated with the specified ID.
///
/// This uses a reservation ID obtained either by aqt_APIAddReservation() or
/// by aqt_APIGetReservationID() to find the associated reservation, which
/// is then removed from the system.  This reduces the reference count on any
/// reserved data, possibly making it available for deletion.
/// @param [in] api Object returned by aqt_APICreate().
/// @param [in] ID Identifier of the reservation to cancel.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APICancelReservation(aqt_API api, aqt_ReservationID ID);

//---------------------------------------------------------------------------
// Aqueti rendering API class and its parameters and methods.

//---------------------------------------------------------------------------
/// @brief Floating-point shader parameter type enumeration.
typedef int aqt_RenderFloatShaderParamType;
  /// @brief Minimum index for a Floating-point shader parameter.
  #define aqt_RFSP_MIN (0)
  /// @brief Floating-point shader parameter setting display gain (~contrast).
  #define aqt_RFSP_GAIN (0)
  /// @brief Floating-point shader parameter setting display offset (~brightness).
  #define aqt_RFSP_OFFSET (1)
  /// @brief Floating-point shader parameter setting display gamma correction.
  #define aqt_RFSP_GAMMA (2)
  /// @brief Floating-point shader parameter setting spatial denoising in pixels.
  #define aqt_RFSP_DENOISE_PIXEL_BLUR (3)
  /// @brief Floating-point shader parameter setting brightness denoising in (0-1).
  #define aqt_RFSP_DENOISE_BRIGHTNESS_BLUR (4)
  /// @brief Maximum index for a Floating-point shader parameter.
  #define aqt_RFSP_MAX (4)

//---------------------------------------------------------------------------
/// @brief Boolean shader parameter type enumeration.
typedef int aqt_RenderBoolShaderParamType;
  /// @brief Minimum index for a Boolean shader parameter.
  #define aqt_RBSP_MIN (0)
  /// @brief Boolean shader parameter turning denoising on or off.
  #define aqt_RBSP_DENOISE (0)
  /// @brief Maximum index for a Boolean shader parameter.
  #define aqt_RBSP_MAX (0)

//---------------------------------------------------------------------------
/// @brief Projection type enumeration.
///
/// The projection type that is being used by the virtual camera that is
/// rendering the scene.
typedef int aqt_RenderProjectionType;
  /// @brief Minimum index for a rendering projection type.
  #define aqt_RPT_MIN (0)
  /// @brief Rendering projection type perspective (default).
  #define aqt_RPT_PERSPECTIVE (0)
  /// @brief Rendering projection type orthographic.
  #define aqt_RPT_ORTHOGRAPHIC (1)
  /// @brief Maximum index for a rendering projection type.
  #define aqt_RPT_MAX (1)

//---------------------------------------------------------------------------
/// @brief Projection manifold enumeration.
///
/// The projection manifold is the surface onto which projection is performed
/// by the virtual camera that is rendering the scene.  Planar projection is
/// usual for many systems and has the benefit that straight lines in the real
/// world remain straight but does its not work for wide fields of view (it is
/// undefined for fields of view >= 180 degrees and it causes large height
/// differences in images from cameras that have wide fields of view).
/// Cylindrical projection reduces the difference in image sizes, but causes
/// straight lines in the real world to become curved.
typedef int aqt_RenderProjectionManifold;
  /// @brief Minimum index for a rendering projection manifold.
  #define aqt_RPM_MIN (0)
  /// @brief Rendering projection manifold is a plane.
  #define aqt_RPM_PLANE (0)
  /// @brief Rendering projection manifold is a cylinder (default).
  #define aqt_RPM_CYLINDER (1)
  /// @brief Maximum index for a rendering projection manifold.
  #define aqt_RPM_MAX (1)

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to C struct that describes time for a render stream.
///
/// Provides access to the information needed to control the replay time of
/// an aqt_RenderStream.  Includes both the camera time and the rate of play
/// of the camera time with respect to the wall-clock time on the local
/// machine.
typedef struct aqt_RenderTimeState_ *aqt_RenderTimeState;

/// @brief Create a RenderTimeState.
///
/// Depending on its parameters, creates either a shared or a non-shared
/// time state that can be used to control the behavior of an aqt_RenderStream.
/// aqt_RenderTimeStateDestroy() should be called when the application is done
/// using the time controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Empty string ("") to create a non-shared time state or
///        name to be used to share this state between render streams.  It is
///        an error to attempt to create a second stream in the API that has the
///        same name as an existing shared time state.  It is not an error to
///        create multiple non-shared time states for used by different
///        render streams.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateCreate(aqt_RenderTimeState *returnState,
   aqt_API api, const char *name);

/// @brief Get a reference to an existing aqt_RenderTimeState.
///
/// Gets a reference to a shared, named
/// time state that can be used to control the behavior of multiple aqt_RenderStream
/// objects and keep them synchronized.
/// aqt_RenderTimeStateDestroy() should be called when the application is done
/// using the time controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Non-empty name to be used to share this state between render streams.
///        It is an error if a shared time state with this name does not yet exist.
///        Create shared time states using aqt_RenderTimeStateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateOpenExisting(aqt_RenderTimeState *returnState,
  aqt_API api, const char *name);

/// @brief Destroy an aqt_RenderTimeState or a reference to one.
///
/// Removes a reference count any possibly destroys an aqt_RenderTimeState that
/// was created using either aqt_RenderTimeStateCreate() or
/// aqt_RenderTimeStateOpenExisting().
/// @param [in] state State returned by aqt_RenderTimeStateCreate() or
///        aqt_RenderTimeStateOpenExisting().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateDestroy(aqt_RenderTimeState state);

/// @brief Get the current time from an aqt_RenderTimeState.
///
/// Returns the camera time referenced by the time controller at the current
/// wall-clock time.  The internal state is continually adjusted at the
/// specified play rate; this function returns the integrated value as of
/// the time the function is called.
/// @param [in] state State returned by aqt_RenderTimeStateCreate() or
///        aqt_RenderTimeStateOpenExisting().
/// @param [out] time Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateGetTime(aqt_RenderTimeState state,
  struct timeval *time);

/// @brief Set the current time on an aqt_RenderTimeState.
///
/// Sets the camera time for the time controller at the current
/// wall-clock time.  The internal state is modified to jump to the specified
/// time, but the rate of replay is not changed.
/// @param [in] state State returned by aqt_RenderTimeStateCreate() or
///        aqt_RenderTimeStateOpenExisting().
/// @param [in] time The time to be set.  The default is one second behind
///        the current time when the object is created.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateSetTime(aqt_RenderTimeState state,
  struct timeval time);

/// @brief Get the current replay rate from an aqt_RenderTimeState.
///
/// Returns the replay rate of the time controller at the current
/// wall-clock time.  This is how many times as fast camera replay happens
/// compared to wall-clock time; a value of 2 replays at double rate and
/// a value of 0.5 replays at half rate.
/// @param [in] state State returned by aqt_RenderTimeStateCreate() or
///        aqt_RenderTimeStateOpenExisting().
/// @param [out] rate Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateGetPlaySpeed(aqt_RenderTimeState state,
  double *rate);

/// @brief Set the current replay rate on an aqt_RenderTimeState.
///
/// Sets the replay rate of the time controller at the current
/// wall-clock time.  This is how many times as fast camera replay happens
/// compared to wall-clock time; a value of 2 replays at double rate and
/// a value of 0.5 replays at half rate.  Does not directly change the
/// current replay time, only its derivative.
/// @param [in] state State returned by aqt_RenderTimeStateCreate() or
///        aqt_RenderTimeStateOpenExisting().
/// @param [in] rate New rate to replay.  The default is 1.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderTimeStateSetPlaySpeed(aqt_RenderTimeState state,
  double rate);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to C struct that describes a view frustum for a render stream.
///
/// Provides access to the information needed to control the view frustum of
/// an aqt_RenderStream.  Includes the horizontal and vertical fields of view
/// of the camera; the maximum ranges of pan, tilt, and zoom; the current
/// values of panl, tilt, and zoom, and the temporal derivatives (rates of change)
/// for pan, tilt, and zoom.  Handles clamping values to the specified ranges.
typedef struct aqt_RenderViewState_ *aqt_RenderViewState;

/// @brief Create a RenderViewState.
///
/// Depending on its parameters, creates either a shared or a non-shared
/// view state that can be used to control the behavior of an aqt_RenderStream.
/// aqt_RenderViewStateDestroy() should be called when the application is done
/// using the view controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Empty string ("") to create a non-shared view state or
///        name to be used to share this state between render streams.  It is
///        an error to attempt to create a second stream in the API that has the
///        same name as an existing shared view state.  It is not an error to
///        create multiple non-shared view states for used by different
///        render streams.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateCreate(aqt_RenderViewState *returnState,
  aqt_API api, const char *name);

/// @brief Get a reference to an existing aqt_RenderViewState.
///
/// Gets a reference to a shared, named
/// view state that can be used to control the behavior of multiple aqt_RenderStream
/// objects and keep them synchronized.
/// aqt_RenderViewStateDestroy() should be called when the application is done
/// using the view controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Non-empty name to be used to share this state between render streams.
///        It is an error if a shared view state with this name does not yet exist.
///        Create shared view states using aqt_RenderViewStateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateOpenExisting(aqt_RenderViewState *returnState,
  aqt_API api, const char *name);

/// @brief Destroy an aqt_RenderViewState or a reference to one.
///
/// Removes a reference count any possibly destroys an aqt_RenderViewState that
/// was created using either aqt_RenderViewStateCreate() or
/// aqt_RenderViewStateOpenExisting().
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateDestroy(aqt_RenderViewState state);

/// @brief Get the current pan in degrees from an aqt_RenderViewState.
///
/// Returns the pan value referenced by the view controller at the current
/// wall-clock time.  The internal state is continually adjusted at the
/// specified play rate; this function returns the integrated value as of
/// the time the function is called.  This values is clamped to ensure that
/// the view frustum doesn't go out of range.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetPanDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the current pan on an aqt_RenderViewState.
///
/// Sets the pan in degrees for the view controller at the current
/// wall-clock time.  The internal state is modified to jump to the specified
/// pan, but the rate of replay is not changed.  The pan value is clamped
/// so that the combined state (pan, tilt, and zoom) contains a frustum
/// that is within the specified bounds.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  Default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetPanDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the minimum pan in degrees from an aqt_RenderViewState.
///
/// Returns the minimum pan value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMinPanDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the minimum pan on an aqt_RenderViewState.
///
/// Sets the minimum pan in degrees for the view controller.  The default
/// value is -45.  If the minimum pan is -180 and the maximum is 180, there
/// is no limit to the pan that can be performed.  When there is a limit, the
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the minimum pan may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is -45.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMinPanDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the maximum pan in degrees from an aqt_RenderViewState.
///
/// Returns the maximum pan value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMaxPanDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the maximum pan on an aqt_RenderViewState.
///
/// Sets the maximum pan in degrees for the view controller.  The default
/// value is 90.  If the minimum pan is -180 and the maximum is 180, there
/// is no limit to the pan that can be performed.  When there is a limit, the
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the minimum pan may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 90.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMaxPanDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the current pan rate in degrees/second from an aqt_RenderPanState.
///
/// Returns the pan rate of the view controller at the current
/// wall-clock time.  This is how many degrees per second the pan is
/// changing.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetPanSpeedDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the current pan rate in degrees/second on an aqt_RenderPanState.
///
/// Sets the pan rate of the view controller at the current
/// wall-clock time.  This is how many degrees per second the pan is
/// changing.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New pan rate in degrees per second.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetPanSpeedDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the current tilt in degrees from an aqt_RenderViewState.
///
/// Returns the tilt value referenced by the view controller at the current
/// wall-clock time.  The internal state is continually adjusted at the
/// specified play rate; this function returns the integrated value as of
/// the time the function is called.  This values is clamped to ensure that
/// the view frustum doesn't go out of range.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetTiltDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the current tilt on an aqt_RenderViewState.
///
/// Sets the tilt in degrees for the view controller at the current
/// wall-clock time.  The internal state is modified to jump to the specified
/// tilt, but the rate of replay is not changed.  The tilt value is clamped
/// so that the combined state (pan, tilt, and zoom) contains a frustum
/// that is within the specified bounds.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetTiltDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the minimum tilt in degrees from an aqt_RenderViewState.
///
/// Returns the minimum tilt value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMinTiltDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the minimum tilt on an aqt_RenderViewState.
///
/// Sets the minimum tilt in degrees for the view controller.  The default
/// value is -25.  The
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the minimum tilt may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is -25.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMinTiltDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the maximum tilt in degrees from an aqt_RenderViewState.
///
/// Returns the maximum tilt value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMaxTiltDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the maximum tilt on an aqt_RenderViewState.
///
/// Sets the maximum tilt in degrees for the view controller.  The default
/// value is 25.  The
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the maximum tilt may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 25.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMaxTiltDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the current tilt rate in degrees/second from an aqt_RenderPanState.
///
/// Returns the tilt rate of the view controller at the current
/// wall-clock time.  This is how many degrees per second the tilt is
/// changing.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetTiltSpeedDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the current tilt rate in degrees/second on an aqt_RenderPanState.
///
/// Sets the tilt rate of the view controller at the current
/// wall-clock time.  This is how many degrees per second the tilt is
/// changing.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New pan rate in degrees per second.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetTiltSpeedDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the current zoom in degrees from an aqt_RenderViewState.
///
/// Returns the zoom value referenced by the view controller at the current
/// wall-clock time.  The internal state is continually adjusted at the
/// specified play rate; this function returns the integrated value as of
/// the time the function is called.  This values is clamped to ensure that
/// the view frustum doesn't go out of range.
/// Zoom of 1 is the default zoom, with higher zooms making pixels in the
/// image appear larger and smaller zooms making them appear smaller.  For
/// perspective planar projections, the pixel size is the specified multiple of
/// the original (zoom=1) size.  Other projection models have different results.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetZoom(aqt_RenderViewState state,
  double *val);

/// @brief Set the current zoom on an aqt_RenderViewState.
///
/// Sets the zoom in factors for the view controller at the current
/// wall-clock time.  The internal state is modified to jump to the specified
/// zoom, but the rate of zoom is not changed.  The zoom value is clamped
/// so that the combined state (pan, tilt, and zoom) contains a frustum
/// that is within the specified bounds
/// Zoom of 1 is the default zoom, with higher zooms making pixels in the
/// image appear larger and smaller zooms making them appear smaller.  For
/// perspective planar projections, the pixel size is the specified multiple of
/// the original (zoom=1) size.  Other projection models have different results.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 1.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetZoom(aqt_RenderViewState state,
  double val);

/// @brief Get the minimum zoom from an aqt_RenderViewState.
///
/// Returns the minimum zoom value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMinZoom(aqt_RenderViewState state,
  double *val);

/// @brief Set the minimum zoom on an aqt_RenderViewState.
///
/// Sets the minimum zoom for the view controller.  The default
/// value is 1.  The
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the minimum tilt may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 1.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMinZoom(aqt_RenderViewState state,
  double val);

/// @brief Get the maximum zoom from an aqt_RenderViewState.
///
/// Returns the maximum zoom value for the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a structure to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetMaxZoom(aqt_RenderViewState state,
  double *val);

/// @brief Set the maximum zoom on an aqt_RenderViewState.
///
/// Sets the maximum zoom for the view controller.  The default
/// value is 10.  The
/// entire view state (fields of view, pan, tilt, and zoom) is clamped so that
/// no part of the frustum goes beyond it; changing the maximum zoom may therefore
/// cause additional clamping of the other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value to be set.  The default is 10.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetMaxZoom(aqt_RenderViewState state,
  double val);

/// @brief Get the current zoom rate in factors/second from an aqt_RenderPanState.
///
/// Returns the zoom rate of the view controller at the current
/// wall-clock time.  This is how many factors per second the zoom is
/// changing.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetZoomSpeed(aqt_RenderViewState state,
  double *val);

/// @brief Set the current zoom rate in factors/second on an aqt_RenderPanState.
///
/// Sets the factor by which the zoom will be changed over each second; a
/// speed of 2 doubles the size each second, a speed of 0.5 halves it each
/// second, and a value of 1 leaves it the same.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New pan rate in degrees per second.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetZoomSpeed(aqt_RenderViewState state,
  double val);

/// @brief Get the horizontal field of view in degrees from an aqt_RenderPanState.
///
/// Returns the horizontal field of view of the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetHorizontalFOVDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the horizontal field of view in degrees from an aqt_RenderPanState.
///
/// Sets the horizontal field of view of the view controller.  For planar
/// projections, this must be less than 180.  For cylindrical fields of
/// view, this must be less than or equal to 360.  Changing this may cause
/// clamping of other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [in] val New value.  Default is 90.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetHorizontalFOVDegrees(aqt_RenderViewState state,
  double val);

/// @brief Get the horizontal field of view in degrees from an aqt_RenderPanState.
///
/// Returns the horizontal field of view of the view controller.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateGetVerticalFOVDegrees(aqt_RenderViewState state,
  double *val);

/// @brief Set the vertical field of view in degrees from an aqt_RenderPanState.
///
/// Sets the vertical field of view of the view controller.
/// This must be less than 180.  Changing this may cause
/// clamping of other values.
/// @param [in] state State returned by aqt_RenderViewStateCreate() or
///        aqt_RenderViewStateOpenExisting().
/// @param [out] val Pointer to a value to be filled in with the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderViewStateSetVerticalFOVDegrees(aqt_RenderViewState state,
  double val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores virtual camera pose parameters.
///
/// This reports the position and orientation of the virtual camera.  The position is stored
/// in longitude (fractional degrees), latitude (fractional degrees) and altitude
/// above sea level (meters).  The orientation is the yaw (rotation about Z, applied
/// first), pitch (rotation about Y, applied second), and roll (rotation about X,
/// applied last) with respect to a right-handed coordinate system describing a
/// camera whose principal ray is pointing up along -Z and whose X axis (towards the
/// right in the image) is pointing East, and whose Y axis (from the bottom of the
/// image towards the top) is pointing North; the Yaw, Pitch, and Roll describe how
/// to rotate this canonical camera to point in the direction of the actual camera.

typedef struct aqt_RenderPoseState_ *aqt_RenderPoseState;

/// @brief Create a render pose state.
///
/// Depending on its parameters, creates either a shared or a non-shared
/// pose state that can be used to control the behavior of an aqt_RenderStream.
/// aqt_RenderPoseStateDestroy() should be called when the application is done
/// using the pose controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Empty string ("") to create a non-shared pose state or
///        name to be used to share this state between render streams.  It is
///        an error to attempt to create a second stream in the API that has the
///        same name as an existing shared time state.  It is not an error to
///        create multiple non-shared pose states for used by different
///        render streams.
AQT_EXPORT aqt_Status aqt_RenderPoseStateCreate(
  aqt_RenderPoseState *returnState,
  aqt_API api, const char *name);

/// @brief Get a reference to an existing aqt_RenderPoseState.
///
/// Gets a reference to a shared, named
/// pose state that can be used to control the behavior of multiple aqt_RenderStream
/// objects and keep them synchronized.
/// aqt_RenderPoseStateDestroy() should be called when the application is done
/// using the pose controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Non-empty name to be used to share this state between render streams.
///        It is an error if a shared pose state with this name does not yet exist.
///        Create shared pose states using aqt_RenderPoseStateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateOpenExisting(
  aqt_RenderPoseState *returnState,
  aqt_API api, const char *name);

/// @brief Destroy an aqt_RenderPoseState or a reference to one.
///
/// Removes a reference count any possibly destroys an aqt_RenderPoseState that
/// was created using either aqt_RenderPoseStateCreate() or
/// aqt_RenderPoseStateOpenExisting().
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateDestroy(aqt_RenderPoseState state);

/// @brief Read the latitude of the camera location in degrees.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetLatitude(aqt_RenderPoseState state, double *val);

/// @brief Set the latitude in degrees on an aqt_RenderPoseState.
///
/// Sets the latitude of the pose controller at the current
/// wall-clock time.  This is the location on planet of the virtual
/// camera's center of projection.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetLatitude(aqt_RenderPoseState state, double val);

/// @brief Read the longitude of the camera location in degrees.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetLongitude(aqt_RenderPoseState state, double *val);

/// @brief Set the longitude in degrees on an aqt_RenderPoseState.
///
/// Sets the longitude of the pose controller at the current
/// wall-clock time.  This is the location on planet of the virtual
/// camera's center of projection.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetLongitude(aqt_RenderPoseState state, double val);

/// @brief Read the altitude above sea level of the camera location in meters.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetAltitude(aqt_RenderPoseState state, double *val);

/// @brief Set the altitude in meters above sea level on an aqt_RenderPoseState.
///
/// Sets the altitude of the pose controller at the current
/// wall-clock time.  This is the location on planet of the virtual
/// camera's center of projection.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is -1e10 ("undefined").
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetAltitude(aqt_RenderPoseState state, double val);

/// @brief Read the roll of the camera orientation in degrees.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetRoll(aqt_RenderPoseState state, double *val);

/// @brief Set the roll in degrees on an aqt_RenderPoseState.
///
/// Sets the roll of the pose controller at the current wall-clock time.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetRoll(aqt_RenderPoseState state, double val);

/// @brief Read the pitch of the camera orientation in degrees.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetPitch(aqt_RenderPoseState state, double *val);

/// @brief Set the pitch in degrees on an aqt_RenderPoseState.
///
/// Sets the pitch of the pose controller at the current wall-clock time.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetPitch(aqt_RenderPoseState state, double val);

/// @brief Read the yaw of the camera orientation in degrees.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateGetYaw(aqt_RenderPoseState state, double *val);

/// @brief Set the yaw in degrees on an aqt_RenderPoseState.
///
/// Sets the pitch of the pose controller at the current wall-clock time.
/// @param [in] state State returned by aqt_RenderPoseStateCreate() or
///        aqt_RenderPoseStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderPoseStateSetYaw(aqt_RenderPoseState state, double val);

//----------------------------------------------------------------------------------------
/// @brief Holds the data for an image subset state, which drives a virtual camera.
///
/// An image subset state stores the fraction of the total view frustum that is
/// being rendered.  It is used to support tiled rendering, where different render
/// streams provide the outputs for a set of tiled displays but they are all
/// controlled by the same view and time states.  The subset is a fraction of the
/// total frustum, which can be used to skip spaces taken up by monitor frames to
/// provide gaps in the overall view that matches the gaps caused by the frames.
/// The range in X goes from 0 at the left side of the frustum to 1 at the right.
/// The range in Y goes from 0 at the top of the frustum to 1 at the bottom.
/// The default range in both X and Y goes from 0 to 1.
typedef struct aqt_RenderImageSubsetState_ *aqt_RenderImageSubsetState;

/// @brief Create a render image subset state.
///
/// Depending on its parameters, creates either a shared or a non-shared
/// image subset state that can be used to control the behavior of an aqt_RenderStream.
/// aqt_RenderImageSubsetStateDestroy() should be called when the application is done
/// using the image subset controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Empty string ("") to create a non-shared image subset state or
///        name to be used to share this state between render streams.  It is
///        an error to attempt to create a second stream in the API that has the
///        same name as an existing shared time state.  It is not an error to
///        create multiple non-shared image subset states for used by different
///        render streams.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateCreate(
  aqt_RenderImageSubsetState *returnState,
  aqt_API api, const char *name);

/// @brief Get a reference to an existing aqt_RenderImageSubsetState.
///
/// Gets a reference to a shared, named
/// image subset state that can be used to control the behavior of multiple aqt_RenderStream
/// objects and keep them synchronized.
/// aqt_RenderImageSubsetStateDestroy() should be called when the application is done
/// using the image subset controller to avoid leaking resources.  Calling destroy on
/// a shared resource removes one reference count but does not necessarily
/// destroy the object itself.
/// @param [out] returnState Pointer to location to store the result, not changed on error.
/// @param [in] api API returned by aqt_CreateAPI().
/// @param [in] name Non-empty name to be used to share this state between render streams.
///        It is an error if a shared image subset state with this name does not yet exist.
///        Create shared image subset states using aqt_RenderImageSubsetStateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateOpenExisting(
  aqt_RenderImageSubsetState *returnState,
  aqt_API api, const char *name);

/// @brief Destroy an aqt_RenderImageSubsetState or a reference to one.
///
/// Removes a reference count any possibly destroys an aqt_RenderImageSubsetState that
/// was created using either aqt_RenderImageSubsetStateCreate() or
/// aqt_RenderImageSubsetStateOpenExisting().
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateDestroy(aqt_RenderImageSubsetState state);

/// @brief Read the minimum X of the image subset in the range 0-1.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateGetMinX(aqt_RenderImageSubsetState state,
  double *val);

/// @brief Set the minimum X in 0-1 on an aqt_RenderImageSubsetState.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateSetMinX(aqt_RenderImageSubsetState state,
  double val);

/// @brief Read the maximum X of the image subset in the range 0-1.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateGetMaxX(aqt_RenderImageSubsetState state,
  double *val);

/// @brief Set the maximum X in 0-1 on an aqt_RenderImageSubsetState.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [in] val New value to set.  The default is 1.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateSetMaxX(aqt_RenderImageSubsetState state,
  double val);

/// @brief Read the minimum Y of the image subset in the range 0-1.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateGetMinY(aqt_RenderImageSubsetState state,
  double *val);

/// @brief Set the minimum Y in 0-1 on an aqt_RenderImageSubsetState.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [in] val New value to set.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateSetMinY(aqt_RenderImageSubsetState state,
  double val);

/// @brief Read the maximum Y of the image subset in the range 0-1.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [out] val Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateGetMaxY(aqt_RenderImageSubsetState state,
  double *val);

/// @brief Set the maximum Y in 0-1 on an aqt_RenderImageSubsetState.
/// @param [in] state State returned by aqt_RenderImageSubsetStateCreate() or
///        aqt_RenderImageSubsetStateOpenExisting().
/// @param [in] val New value to set.  The default is 1.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderImageSubsetStateSetMaxY(aqt_RenderImageSubsetState state,
  double val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_RenderStream.
///
/// Stores the properties of a RenderStream.  Passed into the RenderStream to describe how
/// it should behave.
typedef struct aqt_StreamProperties_ *aqt_StreamProperties;

/// @brief Construct an aqt_StreamProperties with default values.
///
/// The application should call aqt_StreamPropertiesDestroy() when it is done
/// with them to avoid leaking resources.
/// @param [out] returnProp Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesCreate(aqt_StreamProperties *returnProp);

/// @brief Destroy an aqt_StreamProperties, freeing its resources.
/// @param [in] prop Properties returned by aqt_StreamPropertiesCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesDestroy(aqt_StreamProperties prop);

/// @brief Read the stream type.
/// @param [in] prop Structure to use.
/// @param [out] type Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetType(aqt_StreamProperties prop, aqt_StreamType *type);

/// @brief Set the stream type.
/// @param [in] prop Structure to use.
/// @param [in] type Its default value is aqt_STREAM_TYPE_H264.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetType(aqt_StreamProperties prop, aqt_StreamType type);

/// @brief Read the width of each image in the stream.
/// @param [in] prop Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetWidth(aqt_StreamProperties prop, uint32_t *val);

/// @brief Set the width of all images in the stream.
/// @param [in] prop Structure to use.
/// @param [in] val Its default value is 1920.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetWidth(aqt_StreamProperties prop, uint32_t val);

/// @brief Read the height of all images in the stream.
/// @param [in] prop Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetHeight(aqt_StreamProperties prop, uint32_t *val);

/// @brief Set the height of all images in the stream.
/// @param [in] prop Structure to use.
/// @param [in] val Its default value is 1080.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetHeight(aqt_StreamProperties prop, uint32_t val);

/// @brief Read the frames/second for the stream.
/// @param [in] prop Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetFrameRate(aqt_StreamProperties prop, double *val);

/// @brief Set the frames/second for the stream.
/// @param [in] prop Structure to use.
/// @param [in] val Its default value is 30.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetFrameRate(aqt_StreamProperties prop, double val);

/// @brief Read the value of the can-skip parameter.
/// @param [in] prop Structure to use.
/// @param [out] val Pointer to a caller-allocated variable to store the state of the
///         stream.  When can-skip is true, the stream will perform best-effort display
///         of each frame but may display stale data from time to time as the system
///         becomes overloaded.  When can-skip is true, the system waits as long as
///         necessary to decompress and display all available frames for an image even
///         if this makes it render much more slowly than the specified frame rate.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetCanSkip(aqt_StreamProperties prop, bool *val);

/// @brief Set the value of the can-skip parameter.
/// @param [in] prop Structure to use.
/// @param [in] val When can-skip is true, the stream will perform best-effort display
///         of each frame but may display stale data from time to time as the system
///         becomes overloaded.  When can-skip is true, the system waits as long as
///         necessary to decompress and display all available frames for an image even
///         if this makes it render much more slowly than the specified frame rate.
///         Its default value is true.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetCanSkip(aqt_StreamProperties prop, bool val);

/// @brief Set the value of the quality parameter.
/// @param [in] prop Structure to use.
/// @param [out] val Pointer to a caller-allocated variable to store the result.
///       For streams that involve compression, the Quality parameter determines
///       the level of compression, from 0 (most compressed, lowest bit rate) to
///       1 (least compressed, highest bit rate).
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetQuality(aqt_StreamProperties prop, double *val);

/// @brief Set the value of the quality parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve compression, the Quality parameter determines
///       the level of compression, from 0 (most compressed, lowest bit rate) to
///       1 (least compressed, highest bit rate).    The default value is 0.8.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetQuality(aqt_StreamProperties prop, double val);

/// @brief Read the value of the IDR Interval parameter.
/// @param [in] prop Structure to use.
/// @param [in] val Pointer to a caller-allocated variable to store the result.
///       For streams that involve compression with multiple frame types, the
///       IDRInterval parameter determines how many prediction (P) frames come
///       between Image frames.  An IDR frame guarantees that no images following
///       it depend on any images from before it.  A value of 1 will make every
///       frame an IDR frame.  The default value is 30.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetIDRInterval(aqt_StreamProperties prop, uint32_t *val);

/// @brief Set the value of the IDR Interval parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve compression with multiple frame types, the
///       IDRInterval parameter determines how many prediction (P) frames come
///       between Image frames.  An IDR frame guarantees that no images following
///       it depend on any images from before it.  A value of 1 will make every
///       frame an IDR frame.  The default value is 30.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetIDRInterval(aqt_StreamProperties prop, uint32_t val);

/// @brief Read the value of the window X position parameter.
/// @param [in] prop Structure to use.
/// @param [out] val For streams that involve direct display to a monitor, the
///       WindowX parameter describes where the screen will be placed on the
///       operating system's display.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetWindowX(aqt_StreamProperties prop, int32_t *val);

/// @brief Set the value of the window X position parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve direct display to a monitor, the
///       WindowX parameter describes where the screen will be placed on the
///       operating system's display.  The default value is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetWindowX(aqt_StreamProperties prop, int32_t val);

/// @brief Read the value of the window Y position parameter.
/// @param [in] prop Structure to use.
/// @param [out] val For streams that involve direct display to a monitor, the
///       WindowX parameter describes where the screen will be placed on the
///       operating system's display.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetWindowY(aqt_StreamProperties prop, int32_t *val);

/// @brief Set the value of the window X position parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve direct display to a monitor, the
///       WindowX parameter describes where the screen will be placed on the
///       operating system's display.  The default value is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetWindowY(aqt_StreamProperties prop, int32_t val);

/// @brief Read the value of the FullScreen parameter.
/// @param [in] prop Structure to use.
/// @param [out] val For streams that involve direct display to a monitor, the
///       FullScreen parameter determines whether the stream will be shown in
///       a window (false) or on the entire display (true).  This can cause the
///       resolution to not exactly match what was requested.  The default is true.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetFullScreen(aqt_StreamProperties prop, bool *val);

/// @brief Set the value of the FullScreen parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve direct display to a monitor, the
///       FullScreen parameter determines whether the stream will be shown in
///       a window (false) or on the entire display (true).  This can cause the
///       resolution to not exactly match what was requested.  The default is true.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetFullScreen(aqt_StreamProperties prop, bool val);

/// @brief Read the value of the Display parameter.
/// @param [in] prop Structure to use.
/// @param [out] val For streams that involve direct display to a monitor,
///       the Display parameter determines which
///       of the attached displays will be used for the full-screen display.
///       Display mapping is operating-system dependent and can also depend on
///       the order in which displays are discovered.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesGetDisplay(aqt_StreamProperties prop, uint32_t *val);

/// @brief Set the value of the Display parameter.
/// @param [in] prop Structure to use.
/// @param [in] val For streams that involve direct display to a monitor,
///       the Display parameter determines which
///       of the attached displays will be used for the full-screen display.
///       Display mapping is operating-system dependent and can also depend on
///       the order in which displays are discovered.  The default is 0.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_StreamPropertiesSetDisplay(aqt_StreamProperties prop, uint32_t val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a RenderStateInfo.
///
/// Context information for images that come in as frames from the render system.
/// This describes the state of the virtual camera at the time that the frame was
/// rendered.
///
/// The Set* functions are used by the internal code and are not normally used by client code.
/// @todo Add pose parameters.
typedef struct aqt_RenderStateInfo_ *aqt_RenderStateInfo;

/// @brief Create a render state info and initialize with default values.
/// @param [out] returnInfo Pointer to the image to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoCreate(aqt_RenderStateInfo *returnInfo);

/// @brief Create a render state info and initialize with copies of values from another.
/// @param [out] returnInfo Pointer to the info to be constructed.
/// @param [in] infoToCopy The info to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoCopy(aqt_RenderStateInfo *returnInfo,
  aqt_RenderStateInfo infoToCopy);

/// @brief Destroy a render state info.
///
/// Used to destroy infos obtained from aqt_ExternalAnalysisGetNextImage(),
/// aqt_RenderStateInfoCreate(), or aqt_RenderStateInfoCopy().  This destruction
/// is usually done for the user code when the RenderFrame is destroyed.
/// @param [in] info Info to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoDestroy(aqt_RenderStateInfo info);

/// @brief Read the pan info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetPan(aqt_RenderStateInfo info, double *val);

/// @brief Set the pan info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetPan(aqt_RenderStateInfo info, double val);

/// @brief Read the tilt info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetTilt(aqt_RenderStateInfo info, double *val);

/// @brief Set the tilt info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetTilt(aqt_RenderStateInfo info, double val);

/// @brief Read the zoom info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetZoom(aqt_RenderStateInfo info, double *val);

/// @brief Set the zoom info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetZoom(aqt_RenderStateInfo info, double val);

/// @brief Read the horizontal field of view info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetHFOV(aqt_RenderStateInfo info, double *val);

/// @brief Set the horizontal field of view info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetHFOV(aqt_RenderStateInfo info, double val);

/// @brief Read the vertical field of view info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetVFOV(aqt_RenderStateInfo info, double *val);

/// @brief Set the vertical field of view info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetVFOV(aqt_RenderStateInfo info, double val);

/// @brief Read the image subset MinX info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetSubsetMinX(aqt_RenderStateInfo info, double *val);

/// @brief Set the image subset MinX info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetSubsetMinX(aqt_RenderStateInfo info, double val);

/// @brief Read the image subset MaxX info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetSubsetMaxX(aqt_RenderStateInfo info, double *val);

/// @brief Set the image subset MaxX info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetSubsetMaxX(aqt_RenderStateInfo info, double val);

/// @brief Read the image subset MinY info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetSubsetMinY(aqt_RenderStateInfo info, double *val);

/// @brief Set the image subset MinY info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetSubsetMinY(aqt_RenderStateInfo info, double val);

/// @brief Read the image subset MaxY info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetSubsetMaxY(aqt_RenderStateInfo info, double val);

/// @brief Set the image subset MaxY info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetSubsetMaxY(aqt_RenderStateInfo info, double *val);

/// @brief Read the render start time info.
/// @param [in] info Structure to use.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoGetRenderStartTime(aqt_RenderStateInfo info, struct timeval *val);

/// @brief Set the render start time info.  Not normally called by client code.
/// @param [in] info Structure to use.
/// @param [out] val New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStateInfoSetRenderStartTime(aqt_RenderStateInfo info, struct timeval val);

//----------------------------------------------------------------------------------------
/// @brief Stores an image from an aqt_RenderStream along with its image info.
typedef struct aqt_RenderFrame_ *aqt_RenderFrame;

/// @brief Create a frame and initialize with default values.
///
/// Call aqt_RenderFrameDestroy() when done with the frame (and after
/// calling release on its image data) to avoid leaking resources.
/// @param [out] returnFrame Pointer to the frame to be constructed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameCreate(aqt_RenderFrame *returnFrame);

/// @brief Create a frame and initialize with values from another frame.
///
/// Call aqt_RenderFrameDestroy() when done with the frame (and after
/// calling release on its image data) to avoid leaking resources.
/// @param [out] returnFrame Pointer to the frame to be constructed.
/// @param [in] frameToCopy The frame to copy information from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameCopy(aqt_RenderFrame *returnFrame,
  aqt_RenderFrame frameToCopy);

/// @brief Destroy a frame.
///
/// Used to destroy a frame obtained from aqt_RenderFrameCreate(),
/// aqt_RenderFrameCopy(), or aqt_RenderStreamGetNextFrame(), or
/// in a registered callback handler on a render stream.
/// It does destroy the image and info data associated with the frame.
/// Does not free the underlying image data -- call aqt_ImageReleaseData()
/// on its image to do that.
/// @param [in] frame Frame to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameDestroy(aqt_RenderFrame frame);

/// @brief Read the aqt_RenderStateInfo associated with this frame.
/// @param [in] frame Structure to read from.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameGetState(aqt_RenderFrame frame,
  aqt_RenderStateInfo *val);

/// @brief Set the aqt_RenderStateInfo associated with this frame.
///
/// Not normally called by client code.
/// @param [in] frame Structure to use.
/// @param [out] val New render state info to set.  Makes a copy of the state.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameSetState(aqt_RenderFrame frame, aqt_RenderStateInfo val);

/// @brief Read the aqt_Image associated with this frame.
/// @param [in] frame Structure to read from.
/// @param [out] val Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameGetImage(aqt_RenderFrame frame, aqt_Image *val);

/// @brief Set the aqt_Image associated with this frame.
///
/// Not normally called by client code.
/// @param [in] frame Structure to use.
/// @param [out] val New image to set.  Makes a copy of the image.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderFrameSetImage(aqt_RenderFrame frame, aqt_Image val);

/// @brief Enumerates the types of letterbox cropping that are available.
typedef int aqt_LetterBoxApproaches;
/// @brief Read back rectangles from the rendered frame buffer and adaptively update.
#define aqt_LB_READBACK_AND_OPTIMIZE (0)
/// @brief Geometrically optimize based on corners end edge centers from microcameras.
#define aqt_LB_CHECK_8_POINTS_PER_MICROCAMERA (1)

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to C structure that stores parameters to pass to aqt_RenderStreamCreate.
typedef struct aqt_RenderStreamCreateParams_ *aqt_RenderStreamCreateParams;

/// @brief Construct a set of parameters that can be used to construct an aqt_RenderStream.
///
/// Constructs a set of parameters to be passed to aqt_RenderStreamCreate().  The various
/// parameters should be set here before calling that routine.  Once the stream has been
/// created, call aqt_RenderStreamCreateParametersDestroy() to free the resources associated
/// with this parameter set.
/// @param [out] returnParams Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersCreate(
  aqt_RenderStreamCreateParams *returnParams);

/// @brief Destroy a set of parameters created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] params Object that was created by aqt_RenderStreamCreateParametersCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersDestroy(
  aqt_RenderStreamCreateParams params);

/// @brief Set the API in which the aqt_RenderStream will be created.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] api API in which the stream will be created.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetAPI(
  aqt_RenderStreamCreateParams params,
  aqt_API api);

/// @brief Set the view state that will control the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] state View state to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetViewState(
  aqt_RenderStreamCreateParams params,
  aqt_RenderViewState state);

/// @brief Set the time state that will control the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] state Time state to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetTimeState(
  aqt_RenderStreamCreateParams params,
  aqt_RenderTimeState state);

/// @brief Set the image subset state that will control the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] state Image subset state to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetImageSubsetState(
  aqt_RenderStreamCreateParams params,
  aqt_RenderImageSubsetState state);

/// @brief Set the pose state that will control the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] state Pose state to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetPoseState(
  aqt_RenderStreamCreateParams params,
  aqt_RenderPoseState state);

/// @brief Set the stream properties that the aqt_RenderStream will have.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] properties Properties to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetStreamProperties(
  aqt_RenderStreamCreateParams params,
  aqt_StreamProperties properties);

/// @brief Set the name of the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] name Name for the stream.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetName(
  aqt_RenderStreamCreateParams params,
  const char *name);

/// @brief Set the projection type for the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] type Projection type to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetProjectionType(
  aqt_RenderStreamCreateParams params,
  aqt_RenderProjectionType type);

/// @brief Set the projection manifold for the aqt_RenderStream.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] manifold Projection manifold to be used.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetProjectionManifold(
  aqt_RenderStreamCreateParams params,
  aqt_RenderProjectionManifold manifold);

/// @brief Set the type of letterbox cropping to be done, if letterbox is enabled.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] approach Letter box approach to be used.
///             Default is aqt_LB_CHECK_8_POINTS_PER_MICROCAMERA.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetLetterBoxApproach(
  aqt_RenderStreamCreateParams params,
  aqt_LetterBoxApproaches approach);

/// @brief Enable or disable letterbox cropping.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] enabled True to turn letter-box cropping on, false to turn it off.
///             Default is on.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreateParametersSetLetterBoxEnabled(
  aqt_RenderStreamCreateParams params,
  bool enabled);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores a RenderStream description.
///
/// The Name in this structure is used to identify the RenderStream to other objects in the
/// system.
///
/// Use the aqt_APIRenderStreamGet* functions to read its values.

typedef struct aqt_APIRenderStreamInfo_ *aqt_APIRenderStreamInfo;

/// @brief Read the name of the RenderStream.
/// @param [in] info Structure to get the information from.
/// @param [out] returnName Pointer to location to store a pointer to the constant
///              null-terminated string holding the RenderStream name.  This pointer will
///              remain valid until the next call to aqt_RenderStreamGetInfo()
///              or until aqt_APIDestroy() is called, so it should be copied if it is to be
///              used after that.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_APIRenderStreamInfoGetName(
  aqt_APIRenderStreamInfo info, const char **returnName);

//----------------------------------------------------------------------------------------
/// @brief Type declaration for render-frame callback handler function.
///
/// Function declaration for the type of a callback handler that will be called
/// to handle a new frame.  This includes the frame data and a user-data pointer
/// that the caller passed in.
/// @param [in] frame The frame that has been received from the render stream.
///             The handler must call ReleaseData() on the image associated
///             with the frame when it is done with it.
/// @param [in] userData Pointer to the data that was passed into the userData
///             parameter for the aqt_RenderStreamSetStreamCallback function, handed
///             back here so that the client can tell itself how to behave.  This
///             is usually cast into a pointer to the actual object type.
typedef void(*aqt_RenderStreamCallback)(aqt_RenderFrame const frame, void *userData);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that represents a rendering stream.
typedef struct aqt_RenderStream_ *aqt_RenderStream;

/// @brief Construct a RenderStream object.
///
/// aqt_RenderStreamDestroy() should be called when the application is finished with the object
/// to avoid leaking resources.
/// @param [out] returnStream Pointer to location to store the result, not changed on error.
/// @param [in] params Parameters to use when constructing the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamCreate(aqt_RenderStream *returnStream,
  aqt_RenderStreamCreateParams params);

/// @brief Destroy a RenderStream object.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamDestroy(aqt_RenderStream stream);

/// @brief Add a camera to a RenderStream.  Must be done before any images will arrive.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] cameraName Name of the camera to add, which can be obtained by
///        calling aqt_APIGetAvailableCameraCount() and aqt_APIGetAvailableCameraInfo()
///        and then aqt_APICameraGetName() on the returned aqt_APICameraInfo.
/// @param [in] intrinsicIndex Index of the intrinsic information, which can be obtained by
///        calling aqt_APIGetAvailableCameraCount() and aqt_APIGetAvailableCameraInfo()
///        and then aqt_APICameraGetIntrinsicCount() on the returned aqt_APICameraInfo.
///        If you want to see the intrinsic information itself (which is not needed to
///        select one), you call aqt_APICameraGetIntrinsic() to retrieve it.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamAddCamera(aqt_RenderStream stream,
  const char *cameraName, uint32_t intrinsicIndex);

/// @brief Remove a camera to a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] cameraName Name of the camera to remove, which must have been previously
///             added with a call to aqt_RenderStreamAddCamera().
/// @param [in] intrinsicIndex Index of the intrinsic information, which must have been previously
///             added with a call to aqt_RenderStreamAddCamera().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamRemoveCamera(aqt_RenderStream stream,
  const char *cameraName, uint32_t intrinsicIndex);

/// @brief Set the streaming state for a RenderStream.  Must be set true to receive frames.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] running Set to true begin streaming, false to stop.  RenderStreams
///        start out not streaming.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamSetStreamingState(aqt_RenderStream stream,
  bool running);

/// @brief Set a callback function to be called by the receiving thread on each new frame.
///
/// Either aqt_RenderStreamSetStreamCallback() or aqt_RenderStreamGetNextFrame() should
/// be used to get frames from the RenderStream, but not both.  If the callback handler
/// is set, it will be called from a separate thread whenever a new frame is available.
/// If there is no callback handler set, frames will queue up in memory until the program calls
/// aqt_RenderStreamGetNextFrame().
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] handler Function to call from the receiving thread whenever a new frame
///        is received.  Set to NULL to disable.
/// @param [in] userData Pointer that is passed into the function whenever it is called.
///        Should point to a variable or structure or class object that has all of the state
///        that the function needs to process a frame.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamSetStreamCallback(aqt_RenderStream stream,
  aqt_RenderStreamCallback handler, void *userData);

/// @brief Get the next frame available from a render stream.
///
/// Either aqt_RenderStreamSetStreamCallback() or aqt_RenderStreamGetNextFrame() should
/// be used to get frames from the RenderStream, but not both.  If the callback handler
/// is set, it will be called from a separate thread whenever a new frame is available.
/// If there is no callback handler set, frames will queue up in memory until the program calls
/// aqt_RenderStreamGetNextFrame().
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] frame A pointer to the frame that has been received.  Note: The receiver
///        must call ReleaseData() on the frame when it is done with it and must
///        also destroy the frame by calling aqt_RenderFrameDestroy().
/// @param [in] timeout Specifies how long to busy-wait for a frame before returning.  If
///        set to 0, returns immediately whether or not there is a frame.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_TIMEOUT and a frame that has no data if there is not a frame available
///        within the specified time.
AQT_EXPORT aqt_Status aqt_RenderStreamGetNextFrame(aqt_RenderStream stream,
  aqt_RenderFrame *frame, struct timeval timeout);

/// @brief Get the range for a floating-point shader parameter from a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] which Value specifying which parameter's range is to be read.
/// @param [out] returnMin Minimum value for the range of this parameter.
/// @param [out] returnMax Maximum value for the range of this parameter.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamGetFloatShaderParameterRange(
  aqt_RenderStream stream,
  aqt_RenderFloatShaderParamType which, float *returnMin, float *returnMax);

/// @brief Get the current value of a floating-point shader parameter from a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] which Value specifying which parameter is to be read.
/// @param [out] returnVal Current value of this parameter.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamGetFloatShaderParameter(
  aqt_RenderStream stream, aqt_RenderFloatShaderParamType which, float *returnVal);

/// @brief Set the current value of a floating-point shader parameter from a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] which Value specifying which parameter is to be set.
/// @param [in] val New value for this parameter.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamSetFloatShaderParameter(
  aqt_RenderStream stream, aqt_RenderFloatShaderParamType which, float val);

/// @brief Get the current value of a Boolean shader parameter from a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] which Value specifying which parameter is to be read.
/// @param [out] returnVal Current value of this parameter.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamGetBoolShaderParameter(
  aqt_RenderStream stream, aqt_RenderBoolShaderParamType which, bool *returnVal);

/// @brief Set the current value of a Boolean shader parameter from a RenderStream.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] which Value specifying which parameter is to be set.
/// @param [in] val New value for this parameter.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamSetBoolShaderParameter(
  aqt_RenderStream stream, aqt_RenderBoolShaderParamType which, bool val);

/// @brief Refresh a RenderStream.
///
/// On a stream that has I frames and other frames, such as H.264 and H.265,
/// this requests the generation of an I frame as soon as reasonably possible
/// (buffering may prevent doing this on the immediately next frame).
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamRefresh(aqt_RenderStream stream);

/// @brief Set the relative position and zoom based on a rectangle in image space.
///
/// This changes the pan, tilt, and zoom based on a selected region on the image.
/// The region is specified in normalized coordinates (0-1 on each axis).  It takes into
/// account the projection manifold and projection type that is currently in use.
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [in] xCenter Center of the rectangle in X, 0 = image left, 1 = image right.
/// @param [in] yCenter Center of the rectangle in Y, 0 = image top, 1 = image bottom.
/// @param [in] halfWidth Size of the rectangle, 0.5 is same as original, 0.25 zooms in 2X.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamSetViewBasedOnRectangle(aqt_RenderStream stream,
  double xCenter, double yCenter, double halfWidth);

/// @brief Gets information (including the name) about the RenderStream.
///
/// @param [in] stream RenderStream created by calling aqt_RenderStreamCreate().
/// @param [out] returnInfo Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RenderStreamGetInfo(aqt_RenderStream stream,
  aqt_APIRenderStreamInfo *returnInfo);

//---------------------------------------------------------------------------
// Aqueti camera API class and its parameters and methods.

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to C structure that stores parameters to pass to aqt_CameraCreate.
typedef struct aqt_CameraCreateParams_ *aqt_CameraCreateParams;

/// @brief Construct a set of parameters that can be used to construct an aqt_Camera.
///
/// Constructs a set of parameters to be passed to aqt_CameraCreate().  The various
/// parameters should be set here before calling that routine.  Once the camera has been
/// created, call aqt_CameraCreateParametersDestroy() to free the resources associated
/// with this parameter set.
/// @param [out] returnParams Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraCreateParametersCreate(
  aqt_CameraCreateParams *returnParams);

/// @brief Destroy a set of parameters created by aqt_CameraCreateParametersCreate().
/// @param [in] params Object that was created by aqt_CameraCreateParametersCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraCreateParametersDestroy(
  aqt_CameraCreateParams params);

/// @brief Set the API in which the aqt_Camera will be opened.
/// @param [in] params Object that created by aqt_CameraCreateParametersCreate().
/// @param [in] api API in which the camera will be created.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraCreateParametersSetAPI(
  aqt_CameraCreateParams params,
  aqt_API api);

/// @brief Set the name of the aqt_Camera to be opened.
/// @param [in] params Object that created by aqt_CameraCreateParametersCreate().
/// @param [in] name The name of the camera to be opened.  May be found by calling
///        aqt_APIGetAvailableCameraCount() and aqt_APIGetAvailableCameraInfo()
///        and then aqt_APICameraGetName() on the returned aqt_APICameraInfo.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraCreateParametersSetName(
  aqt_CameraCreateParams params,
  const char *name);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that represents a camera.
typedef struct aqt_Camera_ *aqt_Camera;

/// @brief Construct a Camera object.
///
/// aqt_CameraDestroy() should be called when the application is finished with the object
/// to avoid leaking resources.
/// @param [out] returnCamera Pointer to location to store the result, not changed on error.
/// @param [in] params Parameters to use when constructing the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraCreate(aqt_Camera *returnCamera,
  aqt_CameraCreateParams params);

/// @brief Destroy a Camera object.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraDestroy(aqt_Camera camera);

/// @brief Get the recording state of a camera.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraGetIsRecording(aqt_Camera camera, bool *returnVal);

/// @brief Stop recording on the camera.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] policy Reservation policy to use for this recording.
///        This specifies when the recording can be deleted.
///        Use the constant value aqt_RESERVATION_POLICY_USE_SYSTEM_DEFAULT
///        to indicate that the system should use its current default policy for
///        this recording.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraStartRecording(aqt_Camera camera, aqt_ReservationPolicy policy);

/// @brief Stop recording on the camera.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraStopRecording(aqt_Camera camera);

/// @brief Latches the DataRouter name for a camera and returns length.
///
/// This function latches the DataRouter name for a camera  until the next call to this
/// function as well as returning the length of the name so that the caller
/// can allocate resources before calling aqt_CameraGetDataRouter().
/// This function must be called before aqt_CameraGetDataRouter() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_CameraGetDataRouterLength(aqt_Camera camera, uint32_t *returnVal);

/// @brief Reads name latched by aqt_CameraGetDataRouterLength().
///
/// The function aqt_CameraGetDataRouterLength() must be called to latch the
/// information before this function will return anything.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_CameraGetDataRouterLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraGetDataRouter(aqt_Camera camera, char *returnVal);

/// @brief Sets the DataRouter for the camera.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] dataRouterName Name of the DataRouter that the camera should use.
///        This can be determined by calling aqt_APIGetAvailableDataRouterCount()
///        and then aqt_APIGetAvailableDataRouterInfo() and then calling
///        aqt_APIDataRouterGetName() on the returned aqt_APIDataRouterInfo.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraSetDataRouter(aqt_Camera camera, const char *dataRouterName);

/// @brief Deprecated function; use aqt_CameraGetNumStoredDataRangesFiltered() instead.
///
/// This function calls aqt_CameraGetNumStoredDataRangesFiltered() with a default
/// filter set.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_CameraGetNumStoredDataRanges(aqt_Camera camera, uint32_t *returnVal);

/// @brief Opaque pointer to a C structure that stores parameters to pass to
/// aqt_CameraGetNumStoredDataRangesFiltered().
typedef struct aqt_DataRangeFilter_ *aqt_DataRangeFilter;

/// @brief Construct a structure that can be used to filter data sets.
///
/// Constructs a structure to be passed to aqt_CameraGetNumStoredDataRangesFiltered().
/// The various parameters in the filter should be set here before calling that routine.
/// Once the client is finished using the structure, call aqt_DataRangeFilterDestroy()
/// to free the resources associated with this structure.
/// @param [out] returnFilter Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_DataRangeFilterCreate(aqt_DataRangeFilter *returnFilter);

/// @brief Destroy a set of parameters created by aqt_DataRangeFilterCreate().
/// @param [in] filter Object that was created by aqt_DataRangeFilterCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_DataRangeFilterDestroy(aqt_DataRangeFilter filter);

/// @brief Get the value of EnableSubset.
/// @param [in] filter Object that was created by aqt_DataRangeFilterCreate().
/// @param [out] returnResult Pointer to location to store the result.
///        This result tells whether it is permitted
///        to return data ranges that are missing data for some parts of the camera
///        viewpoint.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_DataRangeFilterGetEnableSubset(
  aqt_DataRangeFilter filter,
  bool *returnResult);

/// @brief Set the value of EnableSubset.
/// @param [in] filter Object that was created by aqt_DataRangeFilterCreate().
/// @param [in] enable True to enable the return of data ranges that are missing
///        data for some parts of the camera viewpoint.  Defaults to false.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_DataRangeFilterSetEnableSubset(
  aqt_DataRangeFilter filter,
  bool enable);

/// @brief Latches the data ranges for a camera and returns how many there are.
///
/// This function latches the data ranges for a camera  until the next call to this
/// function as well as returning the number of them so that the caller
/// can retrieve all of them using aqt_CameraGetStoredDataRange().
/// The set of stored ranges returned can be filtered by modifying the filter
/// parameter.
/// This function must be called before aqt_CameraGetStoredDataRange() will return
/// non-empty results.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] filter Used to filter the potential data ranges to the subset
///        that is desired.
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_CameraGetNumStoredDataRangesFiltered(aqt_Camera camera,
  aqt_DataRangeFilter filter, uint32_t *returnVal);

/// @brief Reads a data range latched by aqt_CameraGetNumStoredDataRangesFiltered().
///
/// The function aqt_CameraGetNumStoredDataRangesFiltered() must be called to latch the
/// information before this function will return anything.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] which Which storage range to retrieve, 0 being the first one.  This
///        must be less than the value returned by aqt_CameraGetNumStoredDataRanges().
/// @param [out] returnVal Pointer to location to copy the result to.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraGetStoredDataRange(aqt_Camera camera, uint32_t which,
  aqt_Interval *returnVal);

/// @brief Reports whether a camera can stream data from the current time.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to copy the result to.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraGetCanStreamLiveNow(aqt_Camera camera, bool *returnVal);

/// @brief Latches the streaming modes description for a camera and returns its length.
///
/// This function latches the streaming modes description for a camera  until the next call to this
/// function as well as returning the length of the description so that the caller
/// can allocate resources before calling aqt_CameraGetStreamingModes().
/// This function must be called before aqt_CameraGetStreamingModes() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_CameraGetStreamingModesLength(aqt_Camera camera, uint32_t *returnVal);

/// @brief Reads description latched by aqt_CameraGetStreamingModesLength().
///
/// The function aqt_CameraGetStreamingModesLength() must be called to latch the
/// information before this function will return anything.  This function returns
/// a JSON string that contains an array with the descriptions of the streaming modes
/// for the camera (which streams come from which sources, their formats and rates).
/// Parsing this string to find the number of elements in the array tells how many
/// modes can be set by calling aqt_CameraSetStreamingMode().
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_CameraGetStreamingModesLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraGetStreamingModes(aqt_Camera camera, char *returnVal);

/// @brief Sets the streaming mode for the camera based on an index.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] val Index of the mode to use.  The number of available modes
///        can be found by calling aqt_CameraGetStreamingModes() and parsing its
///        JSON to find the number of elements in the array.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraSetStreamingMode(aqt_Camera camera, uint32_t val);

/// @brief Sets the streaming mode for the camera based on a description.
///
/// This function will not normally be called by a client application.  It is intended
/// for vendor-supplied diagnostic and configuration programs.  The format of the streaming
/// data is vendor- and camera-specific.
/// @param [in] camera Camera created by calling aqt_CameraCreate().
/// @param [in] val JSON description of the streaming modes.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraSetStreamingModeString(aqt_Camera camera, const char *val);

//---------------------------------------------------------------------------
// Aqueti software update API class and its parameters and methods.

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to C structure that stores parameters to pass to aqt_UpdateCreate.
typedef struct aqt_UpdateCreateParams_ *aqt_UpdateCreateParams;

/// @brief Construct a set of parameters that can be used to construct an aqt_Update.
///
/// Constructs a set of parameters to be passed to aqt_UpdateCreate().  The various
/// parameters should be set here before calling that routine.  Once the update object has been
/// created, call aqt_UpdateCreateParametersDestroy() to free the resources associated
/// with this parameter set.
/// @param [out] returnParams Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateCreateParametersCreate(
  aqt_UpdateCreateParams *returnParams);

/// @brief Destroy a set of parameters created by aqt_UpdateCreateParametersCreate().
/// @param [in] params Object that was created by aqt_UpdateCreateParametersCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateCreateParametersDestroy(
  aqt_UpdateCreateParams params);

/// @brief Set the API in which the aqt_Update will be opened.
/// @param [in] params Object that created by aqt_UpdateCreateParametersCreate().
/// @param [in] api API in which the camera will be created.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateCreateParametersSetAPI(
  aqt_UpdateCreateParams params, aqt_API api);

/// @brief Set the name of the aqt_Update to be opened.
/// @param [in] params Object that created by aqt_UpdateCreateParametersCreate().
/// @param [in] name The name of the entity to be opened.  May be found by calling
///        aqt_APIGetAvailable*Count() and aqt_APIGetAvailable*Info()
///        and then aqt_API*GetName() on the returned aqt_API*Info, where
///        * is one of Camera, Renderer, DataRouter.  It can also be obtained
///        from the vendor.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateCreateParametersSetName(
  aqt_UpdateCreateParams params, const char *name);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that represents an update object.
typedef struct aqt_Update_ *aqt_Update;

/// @brief Construct an aqt_Update object.
///
/// This object is intended to be used by vendor-supplied software and will not normally
/// be called by client code.
/// aqt_UpdateDestroy() should be called when the application is finished with the object
/// to avoid leaking resources.
/// @param [out] returnUpdate Pointer to location to store the result, not changed on error.
/// @param [in] params Parameters to use when constructing the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateCreate(aqt_Update *returnUpdate,
  aqt_UpdateCreateParams params);

/// @brief Destroy an aqt_Update object.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateDestroy(aqt_Update update);

/// @brief Latches the software version string for an entity and returns length.
///
/// This function latches the software version string for an entity until the next call to this
/// function as well as returning the length of the string so that the caller
/// can allocate resources before calling aqt_UpdateGetSoftwareVersion().
/// This function must be called before aqt_UpdateGetSoftwareVersion() will return
/// non-empty results.  This length includes the
/// terminating 0 character.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @param [out] returnVal Pointer to location to store the result.
/// @return Status of the API after attempting the operation, aqt_STATUS_OKAY on success.
AQT_EXPORT aqt_Status aqt_UpdateGetSoftwareVersionLength(aqt_Update update, uint32_t *returnVal);

/// @brief Reads string latched by aqt_UpdateGetSoftwareVersionLength().
///
/// The function aqt_UpdateGetSoftwareVersionLength() must be called to latch the
/// information before this function will return anything.
/// To get the software version for the Aqueti API itself, call this on the
/// entity named "/aqt".
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @param [out] returnVal Pointer to location to copy the result to.  It must be
///        large enough to hold the result, whose length will have been reported
///        by aqt_UpdateGetSoftwareVersionLength().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateGetSoftwareVersion(aqt_Update update, char *returnVal);

/// @brief Updates the software on an entity in the system from a buffer.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @param [in] data Pointer to the beginning of the byte data that
///        represents the new software to be installed.
/// @param [in] dataSize Size of the byte data.
/// @param [in] checksum String containing an encoding of the checksum on the data.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateInstall(aqt_Update update, const uint8_t *data,
  uint32_t dataSize, const char *checksum);

/// @brief Updates the software on an entity in the system from a URL.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @param [in] dataURL URL pointing to the location to load the data.
/// @param [in] checksumURL URL pointing to the location to load the checksum.
/// @param [in] update aqt_Update created by calling aqt_UpdateCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_UpdateInstallFromURL(aqt_Update update, const char *dataURL,
  const char *checksumURL);

//---------------------------------------------------------------------------
// Aqueti external analysis API and its parameters and methods.
/// External analysis happens on data stored in the database, as opposed to the
/// internal analysis routines that can run in Camera and RenderStream objects.
/// Before external analysis can be performed, the data (images and/or analysis
/// objects) must have been stored.

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_AnalysisInfo.
typedef struct aqt_AnalysisInfo_ *aqt_AnalysisInfo;

/// @brief Create an aqt_AnalysisInfo and initialize with default values.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoCreate(aqt_AnalysisInfo *returnObj);

/// @brief Create an aqt_AnalysisInfo and initialize with copies of values from another.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoCopy(aqt_AnalysisInfo *returnObj, aqt_AnalysisInfo objToCopy);

/// @brief Destroy an aqt_AnalysisInfo, freeing its resources.
///
/// Used to destroy aqt_AnalysisInfo obtained from
/// aqt_AnalysisInfoCreate() or aqt_AnalysisInfoCopy() or aqt_*GetInfo(),
/// where * is Rectangle, Point, FloatArray, U8Array, CameraModel, or Thumbnail.
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoDestroy(aqt_AnalysisInfo obj);

/// @brief Read the start time associated with the analysis info.
/// @param [in] obj Object to use.
/// @param [out] returnTime Pointer to the location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoGetTime(aqt_AnalysisInfo obj, struct timeval *returnTime);

/// @brief Set the start time associated with the analysis info.
/// @param [in] obj Object to use.
/// @param [in] time New value to set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoSetTime(aqt_AnalysisInfo obj, struct timeval time);

/// @brief Returns length of the name that will be returned by aqt_AnalysisInfoGetName().
///
/// This function returns the length of the name so that the caller can allocate
/// sufficient resources before calling aqt_AnalysisInfoGetName().  This length includes the
/// terminating 0 character.
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoGetNameLength(aqt_AnalysisInfo obj, uint32_t *returnVal);

/// @brief Returns the name of the object; its length is returned by aqt_AnalysisInfoGetNameLength().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoGetName(aqt_AnalysisInfo obj, char *returnVal);

/// @brief Set the name of the analysis info.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoSetName(aqt_AnalysisInfo obj, const char *val);

/// @brief Set the type of the analysis info.  Not normally called by cient code.
///
/// This routine is used internally by the various object constructors for metadata
/// objects (Point, Rectangle, etc.) to let the system know what kind of object this is.
/// It will not normally be called by client code.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_AnalysisInfoSetType(aqt_AnalysisInfo obj, const char *val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_Rectangle.
///
/// This is an external analysis object holds the description of a rectangle within an image
/// along with a name and associated user data.
typedef struct aqt_Rectangle_ *aqt_Rectangle;

/// @brief Create an aqt_Rectangle and initialize with default values.
///
/// The object should be destroyed by calling aqt_RectangleDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleCreate(aqt_Rectangle *returnObj);

/// @brief Create an aqt_Rectangle and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_RectangleDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleCopy(aqt_Rectangle *returnObj, aqt_Rectangle objToCopy);

/// @brief Destroy an aqt_Rectangle, freeing its resources.
///
/// Used to destroy aqt_Rectangle obtained from
/// aqt_RectangleCreate() or aqt_RectangleCopy() or aqt_ExternalAnalysisGetNextRectangle().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleDestroy(aqt_Rectangle obj);

/// @brief Read the analysis info associated with the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleGetInfo(aqt_Rectangle obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleSetInfo(aqt_Rectangle obj, aqt_AnalysisInfo val);

/// @brief Read the normalized center of the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [out] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [out] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleGetCenter(aqt_Rectangle obj, double *xNorm, double *yNorm);

/// @brief Set the normalized center of the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [in] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [in] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleSetCenter(aqt_Rectangle obj, double xNorm, double yNorm);

/// @brief Read the normalized size of the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [out] widthNorm Normalized X size, 1 being the total image width.
/// @param [out] heightNorm Normalized Y size, 1 being the total image height.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleGetSize(aqt_Rectangle obj, double *widthNorm, double *heightNorm);

/// @brief Set the normalized size of the aqt_Rectangle.
/// @param [in] obj Object to use.
/// @param [in] widthNorm Normalized X size, 1 being the total image width.
/// @param [in] heightNorm Normalized Y size, 1 being the total image height.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_RectangleSetSize(aqt_Rectangle obj, double widthNorm, double heightNorm);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_Point.
///
/// This is an external analysis object holds the description of a point in an image
/// along with a name, and associated user data.
typedef struct aqt_Point_ *aqt_Point;

/// @brief Create an aqt_Point and initialize with default values.
///
/// The object should be destroyed by calling aqt_PointDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointCreate(aqt_Point *returnObj);

/// @brief Create an aqt_Point and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_PointDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointCopy(aqt_Point *returnObj, aqt_Point objToCopy);

/// @brief Destroy an aqt_Point, freeing its resources.
///
/// Used to destroy aqt_Point obtained from
/// aqt_PointCreate() or aqt_PointCopy() or aqt_ExternalAnalysisGetNextPoint().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointDestroy(aqt_Point obj);

/// @brief Read the analysis info associated with the aqt_Point.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointGetInfo(aqt_Point obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_Point.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointSetInfo(aqt_Point obj, aqt_AnalysisInfo val);

/// @brief Read the normalized center of the aqt_Point.
/// @param [in] obj Object to use.
/// @param [out] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [out] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointGetCenter(aqt_Point obj, double *xNorm, double *yNorm);

/// @brief Set the normalized center of the aqt_Point.
/// @param [in] obj Object to use.
/// @param [in] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [in] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_PointSetCenter(aqt_Point obj, double xNorm, double yNorm);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_FloatArray.
///
/// This is an external analysis object that holds an array of floating-point values
/// along with a name and associated user data.
typedef struct aqt_FloatArray_ *aqt_FloatArray;

/// @brief Create an aqt_FloatArray and initialize with default values.
///
/// The object should be destroyed by calling aqt_FloatArrayDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayCreate(aqt_FloatArray *returnObj);

/// @brief Create an aqt_FloatArray and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_FloatArrayDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayCopy(aqt_FloatArray *returnObj, aqt_FloatArray objToCopy);

/// @brief Destroy an aqt_FloatArray, freeing its resources.
///
/// Used to destroy aqt_FloatArray obtained from
/// aqt_FloatArrayCreate() or aqt_FloatArrayCopy() or aqt_ExternalAnalysisGetNextFloatArray().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayDestroy(aqt_FloatArray obj);

/// @brief Read the analysis info associated with the aqt_FloatArray.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayGetInfo(aqt_FloatArray obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_FloatArray.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArraySetInfo(aqt_FloatArray obj, aqt_AnalysisInfo val);

/// @brief Returns length of the array that will be returned by aqt_FloatArrayGetArray().
///
/// This function returns the length of the array so that the caller can allocate
/// sufficient resources before calling aqt_FloatArrayGetArray().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayGetArrayLength(aqt_FloatArray obj, uint32_t *returnVal);

/// @brief Returns the array of values for the object; its length is returned by aqt_FloatArrayGetArrayLength().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArrayGetArray(aqt_FloatArray obj, float *returnVal);

/// @brief Set the array of values for the aqt_FloatArray, copying them in.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.  These are copied into the aqt_FloatArray.
/// @param [in] length Length of the array to be copied.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_FloatArraySetArray(aqt_FloatArray obj, const float *val, uint32_t length);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_U8Array.
///
/// This is an external analysis object that holds an arbitrary byte array
/// along with a name and associated user data.
typedef struct aqt_U8Array_ *aqt_U8Array;

/// @brief Create an aqt_U8Array and initialize with default values.
///
/// The object should be destroyed by calling aqt_U8ArrayDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayCreate(aqt_U8Array *returnObj);

/// @brief Create an aqt_U8Array and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_U8ArrayDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayCopy(aqt_U8Array *returnObj, aqt_U8Array objToCopy);

/// @brief Destroy an aqt_U8Array, freeing its resources.
///
/// Used to destroy aqt_U8Array obtained from
/// aqt_U8ArrayCreate() or aqt_U8ArrayCopy() or aqt_ExternalAnalysisGetNextU8Array().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayDestroy(aqt_U8Array obj);

/// @brief Read the analysis info associated with the aqt_U8Array.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayGetInfo(aqt_U8Array obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_U8Array.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArraySetInfo(aqt_U8Array obj, aqt_AnalysisInfo val);

/// @brief Returns length of the array that will be returned by aqt_U8ArrayGetArray().
///
/// This function returns the length of the array so that the caller can allocate
/// sufficient resources before calling aqt_U8ArrayGetArray().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayGetArrayLength(aqt_U8Array obj, uint32_t *returnVal);

/// @brief Returns the array of values for the object; its length is returned by aqt_U8ArrayGetArrayLength().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArrayGetArray(aqt_U8Array obj, uint8_t *returnVal);

/// @brief Set the array of values for the aqt_U8Array, copying them in.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.  These are copied into the aqt_U8Array.
/// @param [in] length Length of the array to be copied.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_U8ArraySetArray(aqt_U8Array obj, const uint8_t *val, uint32_t length);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_CameraModel.
///
/// This is an external analysis object holds the description of a camera model (which tells
/// about the arrangements of individual sources within a camera and is used to stitch images
/// from these sources into a single image)
/// along with a name and associated user data.  This is generated and used by
/// internal API functions but is exposed here to enable external stitching algorithms to be
/// developed.
typedef struct aqt_CameraModel_ *aqt_CameraModel;

/// @brief Create an aqt_CameraModel and initialize to empty.
///
/// The object should be destroyed by calling aqt_CameraModelDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelCreate(aqt_CameraModel *returnObj);

/// @brief Create an aqt_CameraModel and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_CameraModelDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelCopy(aqt_CameraModel *returnObj, aqt_CameraModel objToCopy);

/// @brief Destroy an aqt_CameraModel, freeing its resources.
///
/// Used to destroy aqt_CameraModel obtained from
/// aqt_CameraModeCreate() or aqt_CameraModeCopy() or aqt_ExternalAnalysisGetNextCameraModel().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelDestroy(aqt_CameraModel obj);

/// @brief Read the analysis info associated with the aqt_CameraModel.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelGetInfo(aqt_CameraModel obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_CameraModel.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelSetInfo(aqt_CameraModel obj, aqt_AnalysisInfo val);

/// @brief Returns length of the string that will be returned by aqt_CameraModelGetModel().
///
/// This function returns the length of the string so that the caller can allocate
/// sufficient resources before calling aqt_CameraModelGetModel().  This length includes the
/// terminating 0 character.
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelGetModelLength(aqt_CameraModel obj, uint32_t *returnVal);

/// @brief Returns the string model; its length is returned by aqt_CameraModelGetModelLength().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.  This is a JSON-formatted
///        string.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelGetModel(aqt_CameraModel obj, char *returnVal);

/// @brief Set the string model for the aqt_CameraModel.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.  This is a JSON-formatted string.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_CameraModelSetModel(aqt_CameraModel obj, const char *val);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores the properties of an aqt_Thumbnail.
///
/// This is an external analysis object holds a subset of an image
/// along with a name and associated user data.
typedef struct aqt_Thumbnail_ *aqt_Thumbnail;

/// @brief Create an aqt_Thumbnail and initialize with default values.
///
/// The object should be destroyed by calling aqt_ThumbnailDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailCreate(aqt_Thumbnail *returnObj);

/// @brief Create an aqt_Thumbnail and initialize with copies of values from another.
///
/// The object should be destroyed by calling aqt_ThumbnailDestroy() when done with it
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to be filled in to point to the constructed object.
/// @param [in] objToCopy The object to copy from.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailCopy(aqt_Thumbnail *returnObj, aqt_Thumbnail objToCopy);

/// @brief Destroy an aqt_Rectangle, freeing its resources.
///
/// Used to destroy aqt_Thumbnail obtained from
/// aqt_ThumbnailCreate() or aqt_ThumbnailCopy() or aqt_ExternalAnalysisGetNextThumbnail().
/// @param [in] obj Object to be destroyed.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailDestroy(aqt_Thumbnail obj);

/// @brief Read the analysis info associated with the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [out] val Pointer to the location to store the result.
///        This will return a copy of the information, so the caller must use
///        aqt_AnalysisInfoDestroy() on this object when it is done with it to
///        avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetInfo(aqt_Thumbnail obj, aqt_AnalysisInfo *val);

/// @brief Set the analysis info associated with the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [in] val Analysis information to be used by this object.  It is copied into the object,
///        so the code that created the information should call aqt_AnalysisInfoDestroy()
///        on its locally-allocated copy when it is done with it to avoid leaking resources.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailSetInfo(aqt_Thumbnail obj, aqt_AnalysisInfo val);

/// @brief Read the normalized center of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [out] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [out] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetCenter(aqt_Thumbnail obj, double *xNorm, double *yNorm);

/// @brief Set the normalized center of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [in] xNorm Normalized X coordinate of the center, with 0 at the left and 1 at the right.
/// @param [in] yNorm Normalized Y coordinate of the center, with 0 at the bottom and 1 at the top.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailSetCenter(aqt_Thumbnail obj, double xNorm, double yNorm);

/// @brief Read the normalized size of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [out] widthNorm Normalized X size, 1 being the total image width.
/// @param [out] heightNorm Normalized Y size, 1 being the total image height.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetSize(aqt_Thumbnail obj, double *widthNorm, double *heightNorm);

/// @brief Set the normalized size of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [in] widthNorm Normalized X size, 1 being the total image width.
/// @param [in] heightNorm Normalized Y size, 1 being the total image height.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailSetSize(aqt_Thumbnail obj, double widthNorm, double heightNorm);

/// @brief Read the type of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [out] returnVal Image type of the rectangle, describes how to interpret the data.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetThumbnailType(aqt_Thumbnail obj, aqt_ImageType *returnVal);

/// @brief Set the type of the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [in] val Image type of the rectangle, describes how to interpret the data.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailSetThumbnailType(aqt_Thumbnail obj, aqt_ImageType val);

/// @brief Returns length of the byte array that will be returned by aqt_ThumbnailGetThumbnailData().
///
/// This function returns the length of the byte array so that the caller can allocate
/// sufficient resources before calling aqt_ThumbnailGetThumbnailData().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetThumbnailDataLength(aqt_Thumbnail obj, uint32_t *returnVal);

/// @brief Returns the byte data for the object; its length is returned by aqt_ThumbnailGetThumbnailDataLength().
/// @param [in] obj Object to use.
/// @param [out] returnVal Pointer to location to store the result.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailGetThumbnailData(aqt_Thumbnail obj, uint8_t *returnVal);

/// @brief Set the byte data for the aqt_Thumbnail.
/// @param [in] obj Object to use.
/// @param [in] val New value to be set.  It is copied into the object.
/// @param [in] length Length of the data.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ThumbnailSetThumbnailData(aqt_Thumbnail obj, const uint8_t *val, uint32_t length);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that stores parameters to pass to aqt_ExternalAnalysisCreate().
typedef struct aqt_ExternalAnalysisCreateParams_ *aqt_ExternalAnalysisCreateParams;

/// @brief Construct a set of parameters that can be used to construct an external analysis API.
///
/// Constructs a set of parameters to be passed to aqt_ExternalAnalysisCreate().  The various
/// parameters should be set here before calling that routine.  Once the object has been
/// created, call aqt_ExternalAnalysisCreateParametersDestroy() to free the resources associated
/// with this parameter set.
/// @param [out] returnParams Pointer to location to store the result, not changed on error.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisCreateParametersCreate(
  aqt_ExternalAnalysisCreateParams *returnParams);

/// @brief Destroy a set of parameters created by aqt_ExternalAnalysisCreateParametersCreate().
/// @param [in] params Object that was created by aqt_ExternalAnalysisCreateParametersCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisCreateParametersDestroy(
  aqt_ExternalAnalysisCreateParams params);

/// @brief Set the API in which the aqt_ExternalAnalysis will be created.
/// @param [in] params Object that created by aqt_ExternalAnalysisCreateParametersCreate().
/// @param [in] api API in which the stream will be created.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisCreateParametersSetAPI(
  aqt_ExternalAnalysisCreateParams params,
  aqt_API api);

/// @brief Set the source name of the aqt_ExternalAnalysis.
/// @param [in] params Object that created by aqt_RenderStreamCreateParametersCreate().
/// @param [in] name Entity name of the data source that the analysis is associated with.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisCreateParametersSetSourceName(
  aqt_ExternalAnalysisCreateParams params,
  const char *name);

//----------------------------------------------------------------------------------------
/// @brief Opaque pointer to a C structure that represents an external analysis interface.
typedef struct aqt_ExternalAnalysis_ *aqt_ExternalAnalysis;

/// @brief Construct an aqt_ExternalAnalysis object.
///
/// aqt_ExternalAnalysisDestroy() should be called when the application is finished with the object
/// to avoid leaking resources.
/// @param [out] returnObj Pointer to location to store the result, not changed on error.
/// @param [in] params Parameters to use when constructing the object.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisCreate(aqt_ExternalAnalysis *returnObj,
  aqt_ExternalAnalysisCreateParams params);

/// @brief Destroy an aqt_ExternalAnalysis object.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisDestroy(aqt_ExternalAnalysis obj);

/// @brief Set the start time for an aqt_ExternalAnalysis.
///
/// Before getting items from an external analysis API, the start time must be set.
/// This specifies which items will be retrieved when calling
/// the various aqt_ExternalAnalysisGetNext*() functions.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val Sets the initial time for objects to be retrieved; defaults to {0,0}.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisSetStartTime(aqt_ExternalAnalysis obj,
  struct timeval val);

/// @brief Set the types of images that will be retrieved from an aqt_ExternalAnalysis.
///
/// This specifies which items will be retrieved when calling
/// the aqt_ExternalAnalysisGetNextImage() function.  If this is not called on
/// an object, the default is to return all image types.  This may be used to filter the
/// images returned to only those that can be handled.  The array is copied in so the
/// caller should take care of freeing any memory they allocated.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] types An array of types that may be returned.
/// @param [in] numTypes How many types are in the array.  Setting this to 0 provides the
///        default of "all types".
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisSetImageTypes(aqt_ExternalAnalysis obj,
  aqt_ImageType *types, uint32_t numTypes);

/// @brief Set the minimum size of images that will be retrieved from an aqt_ExternalAnalysis.
///
/// This specifies which items will be retrieved when calling
/// the aqt_ExternalAnalysisGetNextImage() function.  If this is not called on
/// an object, the default is to return all image sizes.  This may be used to filter the
/// images returned to only those that can be handled.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] width Specify the minimum image width to be returned (default 0).
/// @param [in] height Specify the minimum image height to be returned (default 0).
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisSetMinImageSize(aqt_ExternalAnalysis obj,
  uint32_t width, uint32_t height);

/// @brief Set the maximum size of images that will be retrieved from an aqt_ExternalAnalysis.
///
/// This specifies which items will be retrieved when calling
/// the aqt_ExternalAnalysisGetNextImage() function.  If this is not called on
/// an object, the default is to return all image sizes.  This may be used to filter the
/// images returned to only those that can be handled.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] width Specify the maximum image width to be returned (default uint32_max).
/// @param [in] height Specify the maximum image height to be returned (default uint32_max).
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisSetMaxImageSize(aqt_ExternalAnalysis obj,
  uint32_t width, uint32_t height);

/// @brief Get the next available image from an aqt_ExternalAnalysis.
///
/// This returns the next image whose criteria (time, minimum size, maximum size, and type)
/// match those specified by the various functions above.  The default is to return all images
/// starting at the beginning of time.  AS this function is called repeatedly, successive images
/// from the same time and then images with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal Pointer to point to the next image returned on success, not changed
///        if there is not another image.  On success, the caller must call
///        aqt_ImageReleaseData() on the image when it is done with it and must also destroy the image.
/// @return aqt_STATUS_OKAY on success, specific error code on failure. Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another image available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextImage(aqt_ExternalAnalysis obj,
  aqt_Image *retVal);

/// @brief Set the name for data types that will be retrieved from an aqt_ExternalAnalysis.
///
/// This specifies which items will be retrieved when calling
/// the various aqt_ExternalAnalysisGetNext*() functions.  If this is not called on
/// an object, the default is to return objects with any name.  This may be used to filter the
/// objects returned to only those that are of interest.  For example, if an image analysis
/// is being performed that returns thumbnails of faces and another is being run that returns
/// thumbnails of cars, these can be names "faces" and "cars" and then this field can be used
/// to return only the proper type of thumbnail.  The same can be done for points, rectangles,
/// and array objects.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val Specify a value for name that any retrieved objects must have.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisSetNameFilter(aqt_ExternalAnalysis obj,
  const char *val);

/// @brief Get the next available aqt_Rectangle from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_Rectangle whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_Rectangles
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_Rectangles
/// from the same time and then aqt_Rectangles with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_Rectangle that is to receive a copy
///        of the next-available aqt_Rectangle.  The caller must destroy the aqt_Rectangle
///        by calling aqt_RectangleDestroy() when done with it if a aqt_Rectangle was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_Rectangle available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextRectangle(aqt_ExternalAnalysis obj,
  aqt_Rectangle *retVal);

/// @brief Get the next available aqt_Point from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_Point whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_Points
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_Points
/// from the same time and then aqt_Points with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_Point that is to receive a copy
///        of the next-available aqt_Point.  The caller must destroy the aqt_Point
///        by calling aqt_PointDestroy() when done with it if a aqt_Point was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_Point available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextPoint(aqt_ExternalAnalysis obj,
  aqt_Point *retVal);

/// @brief Get the next available aqt_FloatArray from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_FloatArray whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_FloatArrays
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_FloatArrays
/// from the same time and then aqt_FloatArrays with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_FloatArray that is to receive a copy
///        of the next-available aqt_FloatArray.  The caller must destroy the aqt_FloatArray
///        by calling aqt_FloatArrayDestroy() when done with it if a aqt_FloatArray was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_FloatArray available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextFloatArray(aqt_ExternalAnalysis obj,
  aqt_FloatArray *retVal);

/// @brief Get the next available aqt_U8Array from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_U8Array whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_U8Arrays
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_U8Arrays
/// from the same time and then aqt_U8Arrays with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_U8Array that is to receive a copy
///        of the next-available aqt_U8Array.  The caller must destroy the aqt_U8Array
///        by calling aqt_U8ArrayDestroy() when done with it if a aqt_U8Array was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_U8Array available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextU8Array(aqt_ExternalAnalysis obj,
  aqt_U8Array *retVal);

/// @brief Get the next available aqt_CameraArray from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_CameraArray whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_CameraArrays
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_CameraArrays
/// from the same time and then aqt_CameraArrays with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_CameraArray that is to receive a copy
///        of the next-available aqt_CameraArray.  The caller must destroy the aqt_CameraArray
///        by calling aqt_CameraArrayDestroy() when done with it if a aqt_CameraArray was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_CameraArray available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextCameraModel(aqt_ExternalAnalysis obj,
  aqt_CameraModel *retVal);

/// @brief Get the next available aqt_Thumbnail from an aqt_ExternalAnalysis.
///
/// This returns the next aqt_Thumbnail whose criteria (time and name)
/// match those specified by the various functions above.  The default is to return all aqt_Thumbnails
/// starting at the beginning of time.  AS this function is called repeatedly, successive aqt_Thumbnails
/// from the same time and then aqt_Thumbnails with increasing times will be returned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [out] retVal This points to an aqt_Thumbnail that is to receive a copy
///        of the next-available aqt_Thumbnail.  The caller must destroy the aqt_Thumbnail
///        by calling aqt_ThumbnailDestroy() when done with it if a aqt_Thumbnail was returned.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.  Returns
///        aqt_STATUS_NO_NEXT_ELEMENT if there is not another aqt_Thumbnail available from this
///        source that matches the search criteria.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisGetNextThumbnail(aqt_ExternalAnalysis obj,
  aqt_Thumbnail *retVal);

/// @brief Add an aqt_Rectangle instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_Rectangle instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextRectangle() if the
/// appropriate time is scanned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertRectangle(aqt_ExternalAnalysis obj,
  aqt_Rectangle val);

/// @brief Add an aqt_Point instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_Point instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextPoint() if the
/// appropriate time is scanned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertPoint(aqt_ExternalAnalysis obj,
  aqt_Point val);

/// @brief Add an aqt_FloatArray instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_FloatArray instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextFloatArray() if the
/// appropriate time is scanned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertFloatArray(aqt_ExternalAnalysis obj,
  aqt_FloatArray val);

/// @brief Add an aqt_U8Array instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_U8Array instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextU8Array() if the
/// appropriate time is scanned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertU8Array(aqt_ExternalAnalysis obj,
  aqt_U8Array val);

/// @brief Add an aqt_CameraModel instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_CameraModel instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextCameraModel() if the
/// appropriate time is scanned.  It will also affect the display of the associated
/// camera if written to the source whose name matches the camera when the camera is
/// played past the start time for the model.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertCameraModel(aqt_ExternalAnalysis obj,
  aqt_CameraModel val);

/// @brief Add an aqt_Thumbnail instance to an aqt_ExternalAnalysis.
///
/// This adds an aqt_Thumbnail instance into the database stored from the source and
/// user specified in the associated aqt_AnalysisInfo.  It inserts a new analysis record
/// that can later be retrieved using aqt_ExternalAnalysisGetNextThumbnail() if the
/// appropriate time is scanned.
/// @param [in] obj aqt_ExternalAnalysis created by calling aqt_ExternalAnalysisCreate().
/// @param [in] val New object to be inserted.
/// @return aqt_STATUS_OKAY on success, specific error code on failure.
AQT_EXPORT aqt_Status aqt_ExternalAnalysisInsertThumbnail(aqt_ExternalAnalysis obj,
  aqt_Thumbnail val);

#ifdef __cplusplus
}
#endif
