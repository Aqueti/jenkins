/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_CameraModel_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class CameraModel::CameraModel_private {
    public:
      aqt_CameraModel CameraModel = nullptr;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    CameraModel::CameraModel()
    {
      m_private = new CameraModel_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "CameraModel");
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      aqt_CameraModel obj = nullptr;
      m_private->status = aqt_CameraModelCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_CameraModelSetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->CameraModel = obj;
    }

    CameraModel::CameraModel(aqt_CameraModel CameraModel)
    {
      m_private = new CameraModel_private;
      if (!CameraModel) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_CameraModelCopy(&m_private->CameraModel, CameraModel);
    }

    CameraModel::~CameraModel()
    {
      if (m_private) {
        if (m_private->CameraModel) {
          aqt_CameraModelDestroy(m_private->CameraModel);
        }
        delete m_private;
      }
    }

    CameraModel::CameraModel(const CameraModel &copy)
    {
      m_private = new CameraModel_private();
      m_private->status = aqt_CameraModelCopy(&m_private->CameraModel, copy.RawCameraModel());
    }

    CameraModel &CameraModel::operator = (const CameraModel &copy)
    {
      if (m_private) {
        if (m_private->CameraModel) {
          aqt_CameraModelDestroy(m_private->CameraModel);
          m_private->CameraModel = nullptr;
        }
        delete m_private;
        m_private = nullptr;
      }
      m_private = new CameraModel_private();
      m_private->status = aqt_CameraModelCopy(&m_private->CameraModel, copy.RawCameraModel());
      return *this;
    }

    aqt_Status CameraModel::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval CameraModel::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->CameraModel) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetInfo(m_private->CameraModel, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string CameraModel::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->CameraModel) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetInfo(m_private->CameraModel, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status CameraModel::Time(struct timeval val)
    {
      if (!m_private || !m_private->CameraModel) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetInfo(m_private->CameraModel, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status CameraModel::Name(::std::string val)
    {
      if (!m_private || !m_private->CameraModel) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetInfo(m_private->CameraModel, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    ::std::string CameraModel::Value() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->CameraModel) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetModelLength(m_private->CameraModel, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_CameraModelGetModel(m_private->CameraModel, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status CameraModel::Value(::std::string val)
    {
      if (!m_private || !m_private->CameraModel) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_CameraModelSetModel(m_private->CameraModel, val.c_str());
    }

    aqt_CameraModel const CameraModel::RawCameraModel() const
    {
      aqt_CameraModel ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->CameraModel) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->CameraModel;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

