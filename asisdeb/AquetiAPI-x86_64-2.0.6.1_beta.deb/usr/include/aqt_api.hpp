/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_api.hpp
* @brief Aqueti C++ API to its camera systems.
*
* This is the C++ wrapper for the API, which wraps the C API and handles the
* construction and destruction and copying of objects.  This file defines the interface
* both for the client applications and for the developer (who implements the classes
* and methods found herein).  For understanding the API, you should look at the
* aqt_api_defs.hpp file.
* @author Aqueti.
* @date February 2, 2018.
*/

#include "aqt_api_defs.hpp"
#include "aqt_RenderFrame_impl.hpp"
#include "aqt_Image_impl.hpp"
#include "aqt_Rectangle_impl.hpp"
#include "aqt_Point_impl.hpp"
#include "aqt_FloatArray_impl.hpp"
#include "aqt_U8Array_impl.hpp"
#include "aqt_CameraModel_impl.hpp"
#include "aqt_Thumbnail_impl.hpp"
#include "aqt_ReservationPolicy_impl.hpp"
#include "aqt_KeyValue_impl.hpp"
#include "aqt_ReservationInfo_impl.hpp"
#include "aqt_Message_impl.hpp"
#include <chrono>
#include <functional>

namespace aqt {

  //-----------------------------------------------------------------------
  class aqt::StreamProperties::StreamProperties_private {
  public:
    std::shared_ptr<aqt_StreamProperties_> m_state;
    aqt_Status m_status = aqt_STATUS_OKAY;
  };

  StreamProperties::StreamProperties()
  {
    // Create our private data object
    m_private.reset(new StreamProperties_private);
    aqt_StreamProperties ptr;
    m_private->m_status = aqt_StreamPropertiesCreate(&ptr);
    m_private->m_state.reset(ptr,
      [](aqt_StreamProperties_ *obj) {aqt_StreamPropertiesDestroy(obj); }
      );
  }

  StreamProperties::StreamProperties(const StreamProperties& copy)
  {
    m_private.reset(new StreamProperties_private());
    *m_private = *copy.m_private;
  }

  StreamProperties &StreamProperties::operator = (const StreamProperties &copy)
  {
    *m_private = *copy.m_private;
    return *this;
  }

  StreamProperties::~StreamProperties()
  {
    /* This deletion is all handled by the smart pointers.
    if (m_private) {
      if (m_private->m_state) {
        aqt_StreamPropertiesDestroy(m_private->m_state);
      }
      delete m_private;
    }
    */
  }

  std::shared_ptr<aqt_StreamProperties_> StreamProperties::GetRawProperties() const
  {
    if (!m_private) {
      return nullptr;
    }
    return m_private->m_state;
  }

  aqt_Status StreamProperties::GetStatus() const
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    aqt_Status ret = m_private->m_status;
    m_private->m_status = aqt_STATUS_OKAY;
    return ret;
  }

  aqt_StreamType StreamProperties::Type()
  {
    aqt_StreamType ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetType(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::Type(aqt_StreamType val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetType(m_private->m_state.get(), val);
  }

  uint32_t StreamProperties::Width()
  {
    uint32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetWidth(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::Width(uint32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetWidth(m_private->m_state.get(), val);
  }

  uint32_t StreamProperties::Height()
  {
    uint32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetHeight(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::Height(uint32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetHeight(m_private->m_state.get(), val);
  }

  double StreamProperties::FrameRate()
  {
    double ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetFrameRate(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::FrameRate(double val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetFrameRate(m_private->m_state.get(), val);
  }

  bool StreamProperties::CanSkip()
  {
    bool ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetCanSkip(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::CanSkip(bool val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetCanSkip(m_private->m_state.get(), val);
  }

  double StreamProperties::Quality()
  {
    double ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetQuality(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::Quality(double val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetQuality(m_private->m_state.get(), val);
  }

  uint32_t StreamProperties::IDRInterval()
  {
    uint32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetIDRInterval(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::IDRInterval(uint32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetIDRInterval(m_private->m_state.get(), val);
  }

  int32_t StreamProperties::WindowX()
  {
    int32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetWindowX(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::WindowX(int32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetWindowX(m_private->m_state.get(), val);
  }

  int32_t StreamProperties::WindowY()
  {
    int32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetWindowY(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::WindowY(int32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetWindowY(m_private->m_state.get(), val);
  }

  bool StreamProperties::FullScreen()
  {
    bool ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetFullScreen(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::FullScreen(bool val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetFullScreen(m_private->m_state.get(), val);
  }

  uint32_t StreamProperties::Display()
  {
    uint32_t ret;
    if (m_private) {
      m_private->m_status = aqt_StreamPropertiesGetDisplay(m_private->m_state.get(), &ret);
    }

    return ret;
  }

  aqt_Status StreamProperties::Display(uint32_t val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_StreamPropertiesSetDisplay(m_private->m_state.get(), val);
  }


  //-----------------------------------------------------------------------
  class AquetiAPI::AquetiAPI_private {
  public:
    aqt_API m_api = nullptr;
    aqt_Status m_status = aqt_STATUS_OKAY;

    // Information needed by our C callback handler to reformat the data
    // and call the C++ handler.
    LogMessageCallback m_cppHandler = nullptr;
    void *m_cppUserData = nullptr;
  };

  AquetiAPI::AquetiAPI(
    ::std::string user,
    ::std::vector<uint8_t> credentials,
    ::std::vector<::std::string> URLs)
  {
    // Create the private api pointer we're going to use.  Check for
    // exception when creating it, to avoid passing it up to the caller.
    try {
      m_private = new AquetiAPI_private();
    } catch (int) {
      m_private = nullptr;
      return;
    }

    // Create and fill in the parameters to the API creation routine
    aqt_APICreateParams params;
    m_private->m_status = aqt_APICreateParametersCreate(&params);
    if (m_private->m_status != aqt_STATUS_OKAY) {
      return;
    }
    m_private->m_status = aqt_APICreateParametersSetName(params, user.c_str());
    if (m_private->m_status != aqt_STATUS_OKAY) {
      return;
    }
    m_private->m_status = aqt_APICreateParametersSetCredentials(params,
      credentials.data(), static_cast<uint32_t>(credentials.size()));
    if (m_private->m_status != aqt_STATUS_OKAY) {
      return;
    }
    for (size_t i = 0; i < URLs.size(); i++) {
      m_private->m_status = aqt_APICreateParametersAddConnectionURL(params, URLs[i].c_str());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return;
      }
    }

    // Create the API object we're going to use.
    m_private->m_status = aqt_APICreate(&m_private->m_api, params);
    if (m_private->m_status != aqt_STATUS_OKAY) {
      aqt_APICreateParametersDestroy(params);
      m_private->m_api = nullptr;
      return;
    }

    // Destroy the parameter object we created above.
    m_private->m_status = aqt_APICreateParametersDestroy(params);
  }

  AquetiAPI::~AquetiAPI()
  {
    // Destroy any API object we created.
    if (m_private && m_private->m_api) {
      aqt_APIDestroy(m_private->m_api);
    }
    delete m_private;
  }

  aqt_Status AquetiAPI::GetStatus() const
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    aqt_Status ret = m_private->m_status;
    m_private->m_status = aqt_STATUS_OKAY;
    return ret;
  }

  ::std::vector<SingleCOPCameraDescription> AquetiAPI::GetAvailableCameras() const
  {
    ::std::vector<SingleCOPCameraDescription> ret;
    if (!m_private) {
      return ret;
    }

    // Find out how many cameras are in the system, which will also latch the data
    // on the cameras.
    uint32_t count;
    if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APIGetAvailableCameraCount(m_private->m_api, &count))) {
      return ret;
    }

    // Read each camera's information and fill it into information to be returned.
    for (uint32_t i = 0; i < count; i++) {
      SingleCOPCameraDescription cam;
      aqt_APICameraInfo camInfo;
      if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APIGetAvailableCameraInfo(m_private->m_api,
            i, &camInfo))) {
        ret.clear();
        return ret;
      }

      // Get and fill in the camera name.
      const char *name;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraGetName(camInfo, &name))) {
        ret.clear();
        return ret;
      }
      cam.Name(name);

      // Get and fill in the extrinsic camera info.
      aqt_APICameraExtrinsic extrinsic;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraGetExtrinsic(camInfo, &extrinsic))) {
        ret.clear();
        return ret;
      }

      ExtrinsicCalibration ext;
      double val;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetLatitude(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Latitude(val);
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetLongitude(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Longitude(val);
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetAltitude(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Altitude(val);
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetRoll(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Roll(val);
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetPitch(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Pitch(val);
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraExtrinsicGetYaw(extrinsic, &val))) {
        ret.clear();
        return ret;
      }
      ext.Yaw(val);
      cam.Extrinsic(ext);

      // Get and fill in each of the intrinsic models after finding out how many
      // there are.
      ::std::vector<IntrinsicCalibration> intrinsicVec;
      uint32_t intCount;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APICameraGetIntrinsicCount(camInfo, &intCount))) {
        ret.clear();
        return ret;
      }
      for (uint32_t j = 0; j < intCount; j++) {
        aqt_APICameraInstrinsic intrinsic;
        if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APICameraGetIntrinsic(camInfo, j, &intrinsic))) {
          ret.clear();
          return ret;
        }

        IntrinsicCalibration intCal;
        double val;
        if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APICameraInstrinsicGetWidthDegrees(intrinsic, &val))) {
          ret.clear();
          return ret;
        }
        intCal.WidthDegrees(val);
        if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APICameraInstrinsicGetHeightDegrees(intrinsic, &val))) {
          ret.clear();
          return ret;
        }
        intCal.HeightDegrees(val);
        if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APICameraInstrinsicGetPixelSizeDegrees(intrinsic, &val))) {
          ret.clear();
          return ret;
        }
        intCal.PixelSizeDegrees(val);

        intrinsicVec.push_back(intCal);
      }
      cam.Intrinsics(intrinsicVec);

      ret.push_back(cam);
    }

    return ret;
  }

  ::std::vector<RendererDescription> AquetiAPI::GetAvailableRenderers() const
  {
    ::std::vector<RendererDescription> ret;
    if (!m_private) {
      return ret;
    }

    // Find out how many renderers are in the system, which will also latch the data
    // on the cameras.
    uint32_t count;
    if (aqt_STATUS_OKAY !=
      (m_private->m_status = aqt_APIGetAvailableRendererCount(m_private->m_api, &count))) {
      return ret;
    }

    // Read each renderer's information and fill it into information to be returned.
    for (uint32_t i = 0; i < count; i++) {
      aqt_APIRendererInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APIGetAvailableRendererInfo(m_private->m_api,
          i, &info))) {
        ret.clear();
        return ret;
      }

      // Get and fill in the name.
      const char *name;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APIRendererGetName(info, &name))) {
        ret.clear();
        return ret;
      }

      RendererDescription ri;
      ri.Name(name);

      ret.push_back(ri);
    }

    return ret;
  }

  ::std::vector<DataRouterDescription> AquetiAPI::GetAvailableDataRouters() const
  {
    ::std::vector<DataRouterDescription> ret;
    if (!m_private) {
      return ret;
    }

    // Find out how many DataRouters are in the system, which will also latch the data
    // on the cameras.
    uint32_t count;
    if (aqt_STATUS_OKAY !=
      (m_private->m_status = aqt_APIGetAvailableDataRouterCount(m_private->m_api, &count))) {
      return ret;
    }

    // Read each DataRouter's information and fill it into information to be returned.
    for (uint32_t i = 0; i < count; i++) {
      DataRouterDescription cam;
      aqt_APIDataRouterInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APIGetAvailableDataRouterInfo(m_private->m_api,
          i, &info))) {
        ret.clear();
        return ret;
      }

      // Get and fill in the name.
      const char *name;
      if (aqt_STATUS_OKAY !=
        (m_private->m_status = aqt_APIDataRouterGetName(info, &name))) {
        ret.clear();
        return ret;
      }

      DataRouterDescription si;
      si.Name(name);

      ret.push_back(si);
    }

    return ret;
  }

  struct timeval AquetiAPI::GetCurrentSystemTime() const
  {
    struct timeval ret = { 0 , 0 };
    if (!m_private) {
      return ret;
    }

    m_private->m_status = aqt_APIGetCurrentSystemTime(m_private->m_api, &ret);
    return ret;
  }

  aqt_Status AquetiAPI::ExportStoredDataRange(::std::string outputURL, aqt_ExternalDataFormat format,
    ::std::string entityName, aqt::Interval interval,
    std::vector<aqt_DataType> types)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    aqt_Interval aVal = { interval.Start(), interval.End() };
    return m_private->m_status = aqt_APIExportStoredDataRange(m_private->m_api,
      outputURL.c_str(), format,
      entityName.c_str(), aVal, types.data(), static_cast<uint32_t>(types.size()));
  }

  aqt_Status AquetiAPI::ImportStoredDataRange(::std::string inputURL, aqt_ExternalDataFormat format,
    ::std::string entityName, aqt::Interval interval,
    std::vector<aqt_DataType> types)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    aqt_Interval aVal = { interval.Start(), interval.End() };
    return m_private->m_status = aqt_APIImportStoredDataRange(m_private->m_api,
      inputURL.c_str(), format,
      entityName.c_str(), aVal, types.data(), static_cast<uint32_t>(types.size()));
  }

  ::std::string AquetiAPI::GetDetailedStatus(::std::string entityName)
  {
    ::std::string ret;
    if (!m_private) {
      return ret;
    }

    m_private->m_status = aqt_STATUS_OKAY;

    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetDetailedStatusLength(
      m_private->m_api, entityName.c_str(), &count))) {
      return ret;
    }

    ::std::vector<char> value(count);
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetDetailedStatus(
      m_private->m_api, value.data()))) {
      return ret;
    }
    ret = value.data();

    return ret;
  }

  ::std::string AquetiAPI::GetParameters(::std::string entityName)
  {
    ::std::string ret;
    if (!m_private) {
      return ret;
    }

    m_private->m_status = aqt_STATUS_OKAY;

    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetParametersLength(
      m_private->m_api, entityName.c_str(), &count))) {
      return ret;
    }

    ::std::vector<char> value(count);
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetParameters(
      m_private->m_api, value.data()))) {
      return ret;
    }
    ret = value.data();

    return ret;
  }

  aqt_Status AquetiAPI::SetParameters(::std::string entityName, ::std::string val)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_APISetParameters(m_private->m_api, entityName.c_str(), val.c_str());
  }


  ::std::string AquetiAPI::ExternalNTPServerName()
  {
    ::std::string ret;
    if (!m_private) {
      return ret;
    }

    m_private->m_status = aqt_STATUS_OKAY;

    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetExternalNTPServerNameLength(
      m_private->m_api, &count))) {
      return ret;
    }

    ::std::vector<char> value(count);
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetExternalNTPServerName(
      m_private->m_api, value.data()))) {
      return ret;
    }
    ret = value.data();

    return ret;
  }

  aqt_Status AquetiAPI::ExternalNTPServerName(::std::string serverName)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_APISetExternalNTPServerName(m_private->m_api, serverName.c_str());
  }

  ::std::string AquetiAPI::UserData(::std::string baseName)
  {
    ::std::string ret;
    if (!m_private) {
      return ret;
    }

    m_private->m_status = aqt_STATUS_OKAY;

    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetUserDataLength(
      m_private->m_api, baseName.c_str(), &count))) {
      return ret;
    }

    ::std::vector<char> value(count);
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetUserData(
      m_private->m_api, baseName.c_str(), value.data()))) {
      return ret;
    }
    ret = value.data();

    return ret;
  }

  aqt_Status AquetiAPI::UserData(::std::string baseName, ::std::string userData)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_APISetUserData(m_private->m_api, baseName.c_str(), userData.c_str());
  }

  // Because we are wrapping a C+ callback handler around a C callback handler,
  // this function handles getting the data from the C function, reformatting it
  // to C++, and calling the handler that we have been asked to use.
  static void LogMessageCallbackHandler(aqt_Message const message, void *userData)
  {
    // Convert the userData into a pointer to the private data we need.
    AquetiAPI::AquetiAPI_private *info =
      static_cast<AquetiAPI::AquetiAPI_private*>(userData);

    // Reformat the image data into a C++ structure.
    // Call the callback handler with the data.
    if (info->m_cppHandler) {
      Message m(message);
      info->m_cppHandler(m, info->m_cppUserData);
    }

    // In the C API, we always have to destroy the frame that is handed
    // to us, so we do so here.  The RenderFrame above will have created
    // a copy and destroyed that copy, but here we destroy the one that
    // was passed to us.
    aqt_MessageDestroy(message);
  }

  aqt_Status AquetiAPI::SetLogMessageCallback(LogMessageCallback callback,
    void *userData)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    m_private->m_cppHandler = callback;
    m_private->m_cppUserData = userData;

    // If we are supposed to be calling a callback handler, then set our callback handler
    // as the intercept.  If not, then set it to nullptr so that no callbacks are called.
    if (callback) {
      m_private->m_status = aqt_APISetLogMessageCallback(m_private->m_api,
        LogMessageCallbackHandler, m_private);
    } else {
      m_private->m_status = aqt_APISetLogMessageCallback(m_private->m_api,
        nullptr, nullptr);
    }
    return m_private->m_status;
  }

  aqt_Status AquetiAPI::SetLogMessageStreamingState(bool running)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    m_private->m_status = aqt_APISetLogMessageStreamingState(m_private->m_api,
      running);
    return m_private->m_status;
  }

  std::vector<Message> AquetiAPI::GetPendingLogMessages(size_t maxNum)
  {
    std::vector<Message> ret;
    if (!m_private) {
      return ret;
    }

    // Keep getting messages until we either have enough or get a status other
    // than OKAY.  Push each onto the vector, then destroy it.
    m_private->m_status = aqt_STATUS_OKAY;
    while ((ret.size() < maxNum) || (maxNum == 0)) {
      aqt_Message m = nullptr;
      m_private->m_status = aqt_APIGetNextLogMessage(m_private->m_api, &m);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        aqt_MessageDestroy(m);
        if ((m_private->m_status == aqt_STATUS_TIMEOUT) &&
            (ret.size() > 0)) {
          // We got at least one message before timing out, so things are
          // okay.
          m_private->m_status = aqt_STATUS_OKAY;
        }
        return ret;
      }
      ret.push_back(m);
      aqt_MessageDestroy(m);
    }

    return ret;
  }

  aqt_Status AquetiAPI::SetLogMessageMinimumLevel(aqt_MessageLevel level)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    m_private->m_status = aqt_APISetLogMessageMinimumLevel(m_private->m_api,
      level);
    return m_private->m_status;
  }

  aqt_Status AquetiAPI::CreateIssueReport(const std::string &fileNameToWrite,
    const std::string &summary, const std::string &description)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    if (fileNameToWrite.size() == 0) {
      return m_private->m_status = aqt_STATUS_BAD_PARAMETER;
    }

    /// @todo Pass in the additional parameters to the issue-request function.

    return aqt_APICreateIssueReport(m_private->m_api, fileNameToWrite.c_str(),
      summary.c_str(), description.c_str());
  }

  std::string AquetiAPI::AddReservation(ReservationInfo reservation)
  {
    std::string ret = aqt_ReservationID_INVALID;
    if (!m_private) {
      return ret;
    }

    aqt_ReservationID id;
    m_private->m_status = aqt_APIAddReservation(m_private->m_api,
      reservation.RawReservationInfo(), &id);

    return id;
  }

  ::std::vector<std::string> AquetiAPI::GetReservationIDs(ReservationInfo searchParams)
  {
    ::std::vector<std::string> ret;
    if (!m_private) {
      return ret;
    }

    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetNumReservationIDs(m_private->m_api,
      searchParams.RawReservationInfo(), &count))) {
      return ret;
    }
    for (uint32_t i = 0; i < count; i++) {
      aqt_ReservationID ID;
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_APIGetReservationID(m_private->m_api,
        i, &ID))) {
        ret.clear();
        return ret;
      }
      ret.push_back(ID);
    }

    return ret;
  }

  ReservationInfo AquetiAPI::GetReservationInfo(std::string ID)
  {
    aqt_ReservationInfo ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (ID.size() + 1 > aqt_ReservationIDLength) {
      m_private->m_status = aqt_STATUS_BAD_PARAMETER;
      return ret;
    }
    aqt_ReservationID id;
    memcpy(id, ID.c_str(), ID.size() + 1);

    m_private->m_status = aqt_APIGetReservationInfo(m_private->m_api, id, &ret);
    return ret;
  }

  aqt_Status AquetiAPI::ReplaceReservation(std::string ID, ReservationInfo reservation)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }

    if (ID.size() + 1 > aqt_ReservationIDLength) {
      return aqt_STATUS_BAD_PARAMETER;
    }
    aqt_ReservationID id;
    memcpy(id, ID.c_str(), ID.size() + 1);
    return m_private->m_status = aqt_APIReplaceReservation(m_private->m_api, id,
      reservation.RawReservationInfo());
  }

  aqt_Status AquetiAPI::CancelReservation(std::string ID)
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }

    if (ID.size() + 1 > aqt_ReservationIDLength) {
      return aqt_STATUS_BAD_PARAMETER;
    }
    aqt_ReservationID id;
    memcpy(id, ID.c_str(), ID.size() + 1);
    return m_private->m_status = aqt_APICancelReservation(m_private->m_api, id);
  }

  aqt_API AquetiAPI::GetRawAPI() const
  {
    if (!m_private) {
      return nullptr;
    }
    return m_private->m_api;
  }


  namespace render {

    //-----------------------------------------------------------------------
    class aqt::render::TimeState::TimeState_private {
    public:
      aqt_RenderTimeState m_state = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    TimeState::TimeState(AquetiAPI &api, ::std::string name, bool alreadyExists)
    {
      // Create our private data object
      m_private = new TimeState_private;
      if (alreadyExists) {
        m_private->m_status = aqt_RenderTimeStateOpenExisting(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      } else {
        m_private->m_status = aqt_RenderTimeStateCreate(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      }
    }

    TimeState::~TimeState()
    {
      if (m_private && m_private->m_state) {
        aqt_RenderTimeStateDestroy(m_private->m_state);
      }
      delete m_private;
    }

    aqt_RenderTimeState TimeState::GetRawState()
    {
      if (!m_private) {
        return nullptr;
      }
      return m_private->m_state;
    }

    aqt_Status TimeState::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    struct timeval TimeState::Time()
    {
      struct timeval ret = {};
      if (m_private) {
        m_private->m_status = aqt_RenderTimeStateGetTime(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status TimeState::Time(struct timeval time)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderTimeStateSetTime(m_private->m_state, time);
    }

    double TimeState::PlaySpeed()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderTimeStateGetPlaySpeed(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status TimeState::PlaySpeed(double speed)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderTimeStateSetPlaySpeed(m_private->m_state, speed);
    }

    //-----------------------------------------------------------------------
    class aqt::render::ViewState::ViewState_private {
    public:
      aqt_RenderViewState m_state = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    ViewState::ViewState(AquetiAPI &api, ::std::string name, bool alreadyExists)
    {
      // Create our private data object
      m_private = new ViewState_private;
      if (!api.m_private) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return;
      }
      if (alreadyExists) {
        m_private->m_status = aqt_RenderViewStateOpenExisting(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      }
      else {
        m_private->m_status = aqt_RenderViewStateCreate(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      }
    }

    ViewState::~ViewState()
    {
      if (m_private && m_private->m_state) {
        aqt_RenderViewStateDestroy(m_private->m_state);
      }
      delete m_private;
    }

    aqt_RenderViewState ViewState::GetRawState()
    {
      if (!m_private) {
        return nullptr;
      }
      return m_private->m_state;
    }

    aqt_Status ViewState::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    double ViewState::PanDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetPanDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::PanDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetPanDegrees(m_private->m_state, val);
    }

    double ViewState::MinPanDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMinPanDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MinPanDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMinPanDegrees(m_private->m_state, val);
    }

    double ViewState::MaxPanDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMaxPanDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MaxPanDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMaxPanDegrees(m_private->m_state, val);
    }

    double ViewState::PanSpeedDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetPanSpeedDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::PanSpeedDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetPanSpeedDegrees(m_private->m_state, val);
    }

    double ViewState::TiltDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetTiltDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::TiltDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetTiltDegrees(m_private->m_state, val);
    }

    double ViewState::MinTiltDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMinTiltDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MinTiltDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMinTiltDegrees(m_private->m_state, val);
    }

    double ViewState::MaxTiltDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMaxTiltDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MaxTiltDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMaxTiltDegrees(m_private->m_state, val);
    }

    double ViewState::TiltSpeedDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetTiltSpeedDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::TiltSpeedDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetTiltSpeedDegrees(m_private->m_state, val);
    }

    double ViewState::Zoom()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetZoom(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::Zoom(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetZoom(m_private->m_state, val);
    }

    double ViewState::MinZoom()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMinZoom(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MinZoom(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMinZoom(m_private->m_state, val);
    }

    double ViewState::MaxZoom()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetMaxZoom(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::MaxZoom(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetMaxZoom(m_private->m_state, val);
    }

    double ViewState::ZoomSpeed()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetZoomSpeed(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::ZoomSpeed(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetZoomSpeed(m_private->m_state, val);
    }

    double ViewState::HorizontalFOVDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetHorizontalFOVDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::HorizontalFOVDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetHorizontalFOVDegrees(m_private->m_state, val);
    }

    double ViewState::VerticalFOVDegrees()
    {
      double ret;
      if (m_private) {
        m_private->m_status = aqt_RenderViewStateGetVerticalFOVDegrees(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status ViewState::VerticalFOVDegrees(double val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderViewStateSetVerticalFOVDegrees(m_private->m_state, val);
    }

    //-----------------------------------------------------------------------
    class aqt::render::PoseState::PoseState_private {
    public:
      aqt_RenderPoseState m_state = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    PoseState::PoseState(AquetiAPI &api, ::std::string name, bool alreadyExists)
    {
      // Create our private data object
      m_private = new PoseState_private;
      if (alreadyExists) {
        m_private->m_status = aqt_RenderPoseStateOpenExisting(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      }
      else {
        m_private->m_status = aqt_RenderPoseStateCreate(
          &m_private->m_state, api.GetRawAPI(), name.c_str());
      }
    }

    PoseState::~PoseState()
    {
      if (m_private && m_private->m_state) {
        aqt_RenderPoseStateDestroy(m_private->m_state);
      }
      delete m_private;
    }

    aqt_RenderPoseState PoseState::GetRawState()
    {
      if (!m_private) {
        return nullptr;
      }
      return m_private->m_state;
    }

    aqt_Status PoseState::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    double PoseState::Latitude()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetLatitude(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Latitude(double newVal)
    {
      return aqt_RenderPoseStateSetLatitude(m_private->m_state, newVal);
    }

    double PoseState::Longitude()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetLongitude(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Longitude(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderPoseStateSetLongitude(m_private->m_state, newVal);
    }

    double PoseState::Altitude()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetAltitude(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Altitude(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderPoseStateSetAltitude(m_private->m_state, newVal);
    }

    double PoseState::Roll()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetRoll(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Roll(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderPoseStateSetRoll(m_private->m_state, newVal);
    }

    double PoseState::Pitch()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetPitch(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Pitch(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderPoseStateSetPitch(m_private->m_state, newVal);
    }

    double PoseState::Yaw()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderPoseStateGetYaw(m_private->m_state, &ret);
      }

      return ret;
    }

    aqt_Status PoseState::Yaw(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderPoseStateSetYaw(m_private->m_state, newVal);
    }


    //-----------------------------------------------------------------------
    class aqt::render::ImageSubsetState::ImageSubsetState_private {
    public:
      std::shared_ptr<aqt_RenderImageSubsetState_> m_state;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    ImageSubsetState::ImageSubsetState(AquetiAPI &api, ::std::string name, bool alreadyExists)
    {
      // Create our private data object
      m_private.reset(new ImageSubsetState_private);
      if (!api.m_private) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return;
      }
      aqt_RenderImageSubsetState ptr;
      if (alreadyExists) {
        m_private->m_status = aqt_RenderImageSubsetStateOpenExisting(
          &ptr, api.GetRawAPI(), name.c_str());
      } else {
        m_private->m_status = aqt_RenderImageSubsetStateCreate(
          &ptr, api.GetRawAPI(), name.c_str());
      }
      m_private->m_state.reset(ptr,
        [](aqt_RenderImageSubsetState_*obj) {
        aqt_RenderImageSubsetStateDestroy(obj); });
    }

    ImageSubsetState::~ImageSubsetState()
    {
      /* Destruction of all this is now taken care of by the smart pointers.
      if (m_private && m_private->m_state) {
        aqt_RenderImageSubsetStateDestroy(m_private->m_state);
      }
      delete m_private;
      */
    }

    std::shared_ptr<aqt_RenderImageSubsetState_> ImageSubsetState::GetRawState()
    {
      if (!m_private) {
        return nullptr;
      }
      return m_private->m_state;
    }

    aqt_Status ImageSubsetState::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    double ImageSubsetState::MinX()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderImageSubsetStateGetMinX(m_private->m_state.get(), &ret);
      }

      return ret;
    }

    aqt_Status ImageSubsetState::MinX(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderImageSubsetStateSetMinX(m_private->m_state.get(), newVal);
    }

    double ImageSubsetState::MaxX()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderImageSubsetStateGetMaxX(m_private->m_state.get(), &ret);
      }

      return ret;
    }

    aqt_Status ImageSubsetState::MaxX(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderImageSubsetStateSetMaxX(m_private->m_state.get(), newVal);
    }

    double ImageSubsetState::MinY()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderImageSubsetStateGetMinY(m_private->m_state.get(), &ret);
      }

      return ret;
    }

    aqt_Status ImageSubsetState::MinY(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderImageSubsetStateSetMinY(m_private->m_state.get(), newVal);
    }

    double ImageSubsetState::MaxY()
    {
      double ret = 0;
      if (m_private) {
        m_private->m_status = aqt_RenderImageSubsetStateGetMaxY(m_private->m_state.get(), &ret);
      }

      return ret;
    }

    aqt_Status ImageSubsetState::MaxY(double newVal)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderImageSubsetStateSetMaxY(m_private->m_state.get(), newVal);
    }

    //-----------------------------------------------------------------------
    class RenderStream::RenderStream_private {
    public:
      aqt_RenderStream m_stream = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;

      // Information needed by our C callback handler to reformat the data
      // and call the C++ handler.
      StreamCallback m_cppHandler = nullptr;
      void *m_cppUserData = nullptr;
    };

    RenderStream::RenderStream(
      AquetiAPI &api,
      ViewState &viewState,
      TimeState &timeState,
      ImageSubsetState &imageSubsetState,
      PoseState &poseState,
      StreamProperties &props,
      ::std::string renderer,
      aqt_RenderProjectionType projectionType,
      aqt_RenderProjectionManifold projectionManifold,
      bool letterBoxEnabled,
      aqt_LetterBoxApproaches letterBoxApproach)
    {
      // Create the private api pointer we're going to use.  Check for
      // exception when creating it, to avoid passing it up to the caller.
      try {
        m_private = new RenderStream_private();
      } catch (int) {
        m_private = nullptr;
        return;
      }

      // Create and fill in the parameters to the stream creation routine
      aqt_RenderStreamCreateParams params;
      m_private->m_status = aqt_RenderStreamCreateParametersCreate(&params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetAPI(params, api.GetRawAPI());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetViewState(params, viewState.GetRawState());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetTimeState(params, timeState.GetRawState());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetImageSubsetState(params,
        imageSubsetState.GetRawState().get());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetPoseState(params, poseState.GetRawState());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetStreamProperties(params,
        props.GetRawProperties().get());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetName(params, renderer.c_str());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetProjectionType(params, projectionType);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetProjectionManifold(params, projectionManifold);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetLetterBoxApproach(params, letterBoxApproach);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_RenderStreamCreateParametersSetLetterBoxEnabled(params, letterBoxEnabled);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }

      m_private->m_status = aqt_RenderStreamCreate(&m_private->m_stream, params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
        return;
      }

      // Delete the structures we created along the way
      m_private->m_status = aqt_RenderStreamCreateParametersDestroy(params);
    }

    RenderStream::~RenderStream()
    {
      // Destroy any API object we created.
      if (m_private && m_private->m_stream) {
        aqt_RenderStreamDestroy(m_private->m_stream);
      }
      delete m_private;
    }

    aqt_Status RenderStream::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    aqt_Status RenderStream::AddCamera(::std::string cameraName, uint32_t intrinsicIndex)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_status = aqt_RenderStreamAddCamera(m_private->m_stream,
        cameraName.c_str(), intrinsicIndex);
      return m_private->m_status;
    }

    aqt_Status RenderStream::RemoveCamera(::std::string cameraName, uint32_t intrinsicIndex)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_status = aqt_RenderStreamRemoveCamera(m_private->m_stream,
        cameraName.c_str(), intrinsicIndex);
      return m_private->m_status;
    }

    aqt_Status RenderStream::SetStreamingState(bool running)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_status = aqt_RenderStreamSetStreamingState(m_private->m_stream,
        running);
      return m_private->m_status;
    }

    // Because we are wrapping a C+ callback handler around a C callback handler,
    // this function handles getting the data from the C function, reformatting it
    // to C++, and calling the handler that we have been asked to use.
    static void StreamCallbackHandler(aqt_RenderFrame const frame, void *userData)
    {
      // Convert the userData into a pointer to the private data we need.
      RenderStream::RenderStream_private *info =
        static_cast<RenderStream::RenderStream_private*>(userData);

      // Reformat the image data into a C++ structure.
      // Call the callback handler with the data.
      if (info->m_cppHandler) {
        RenderFrame f(frame);
        info->m_cppHandler(f, info->m_cppUserData);
      }

      // In the C API, we always have to destroy the frame that is handed
      // to us, so we do so here.  The RenderFrame above will have created
      // a copy and destroyed that copy, but here we destroy the one that
      // was passed to us.
      aqt_RenderFrameDestroy(frame);
    }

    aqt_Status RenderStream::SetStreamCallback(StreamCallback callback, void *userdata)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_cppHandler = callback;
      m_private->m_cppUserData = userdata;

      // If we are supposed to be calling a callback handler, then set our callback handler
      // as the intercept.  If not, then set it to nullptr so that no callbacks are called.
      if (callback) {
        m_private->m_status = aqt_RenderStreamSetStreamCallback(m_private->m_stream,
          StreamCallbackHandler, m_private);
      } else {
        m_private->m_status = aqt_RenderStreamSetStreamCallback(m_private->m_stream,
          nullptr, nullptr);
      }
      return m_private->m_status;
    }

    RenderFrame RenderStream::GetNextFrame(struct timeval timeout)
    {
      RenderFrame emptyRet;
      if (!m_private) {
        return emptyRet;
      }
      if (!m_private->m_stream) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return emptyRet;
      }
      aqt_RenderFrame frame = nullptr;
      m_private->m_status = aqt_RenderStreamGetNextFrame(m_private->m_stream, &frame, timeout);
      if (m_private->m_status == aqt_STATUS_TIMEOUT) {
        aqt_RenderFrameDestroy(frame);
        return emptyRet;
      }
      RenderFrame ret(frame);
      aqt_RenderFrameDestroy(frame);
      return ret;
    }

    aqt_Status RenderStream::GetFloatParameterRange(aqt_RenderFloatShaderParamType which,
      FloatParameterRange &range)
    {
      if (!m_private || !m_private->m_stream) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_RenderStreamGetFloatShaderParameterRange(
        m_private->m_stream, which, &range.minVal, &range.maxVal);
    }

    float RenderStream::FloatParameter(aqt_RenderFloatShaderParamType which)
    {
      float val = 0;
      if (m_private && m_private->m_stream) {
        m_private->m_status = aqt_RenderStreamGetFloatShaderParameter(
          m_private->m_stream, which, &val);
      }
      return val;
    }

    aqt_Status RenderStream::FloatParameter(aqt_RenderFloatShaderParamType which, float newVal)
    {
      if (!m_private || !m_private->m_stream) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderStreamSetFloatShaderParameter(m_private->m_stream, which, newVal);
    }

    bool RenderStream::BoolParameter(aqt_RenderBoolShaderParamType which)
    {
      bool val = false;
      if (m_private && m_private->m_stream) {
        m_private->m_status = aqt_RenderStreamGetBoolShaderParameter(
          m_private->m_stream, which, &val);
      }
      return val;
    }

    aqt_Status RenderStream::BoolParameter(aqt_RenderBoolShaderParamType which, bool newVal)
    {
      if (!m_private || !m_private->m_stream) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_RenderStreamSetBoolShaderParameter(m_private->m_stream, which, newVal);
    }

    aqt_Status RenderStream::Refresh()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_status = aqt_RenderStreamRefresh(m_private->m_stream);
      return m_private->m_status;
    }

    aqt_Status RenderStream::SetViewBasedOnRectangle(double xCenter, double yCenter,
      double halfWidth)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      m_private->m_status = aqt_RenderStreamSetViewBasedOnRectangle(m_private->m_stream,
        xCenter, yCenter, halfWidth);
      return m_private->m_status;
    }

    RenderStreamDescription RenderStream::GetInfo()
    {
      RenderStreamDescription ret;
      if (m_private && m_private->m_stream) {

        aqt_APIRenderStreamInfo info;
        if (aqt_STATUS_OKAY !=
            (m_private->m_status = aqt_RenderStreamGetInfo(m_private->m_stream, &info))) {
          return RenderStreamDescription();
        }

        // Get and fill in the name.
        const char *name;
        if (aqt_STATUS_OKAY !=
          (m_private->m_status = aqt_APIRenderStreamInfoGetName(info, &name))) {
          return RenderStreamDescription();
        }
        ret.Name(name);
      }
      return ret;
    }

  } // End namespace render

  namespace camera {

    //-----------------------------------------------------------------------
    class Camera::Camera_private {
    public:
      aqt_Camera m_camera = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    Camera::Camera(AquetiAPI &api, ::std::string name)
    {
      // Create the private api pointer we're going to use.  Check for
      // exception when creating it, to avoid passing it up to the caller.
      try {
        m_private = new Camera_private();
      } catch (int) {
        m_private = nullptr;
        return;
      }

      // Create and fill in the parameters to the stream creation routine
      aqt_CameraCreateParams params;
      m_private->m_status = aqt_CameraCreateParametersCreate(&params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->m_status = aqt_CameraCreateParametersSetAPI(params, api.GetRawAPI());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_CameraCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_CameraCreateParametersSetName(params, name.c_str());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_CameraCreateParametersDestroy(params);
        return;
      }

      m_private->m_status = aqt_CameraCreate(&m_private->m_camera, params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_CameraCreateParametersDestroy(params);
        return;
      }

      // Delete the structures we created along the way
      m_private->m_status = aqt_CameraCreateParametersDestroy(params);
    }

    Camera::~Camera()
    {
      // Destroy any API object we created.
      if (m_private && m_private->m_camera) {
        aqt_CameraDestroy(m_private->m_camera);
      }
      delete m_private;
    }

    aqt_Status Camera::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    bool Camera::IsRecording()
    {
      bool ret;
      if (m_private) {
        m_private->m_status = aqt_CameraGetIsRecording(m_private->m_camera, &ret);
      }

      return ret;
    }

    aqt_Status Camera::StartRecording(ReservationPolicy policy)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }

      return aqt_CameraStartRecording(m_private->m_camera, policy.RawReservationPolicy());
    }


    aqt_Status Camera::StopRecording()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }

      return aqt_CameraStopRecording(m_private->m_camera);
    }

    ::std::string Camera::GetDataRouter()
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      m_private->m_status = aqt_STATUS_OKAY;

      uint32_t count;
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetDataRouterLength(
        m_private->m_camera, &count))) {
        return ret;
      }

      ::std::vector<char> value(count);
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetDataRouter(
        m_private->m_camera, value.data()))) {
        return ret;
      }
      ret = value.data();

      return ret;
    }

    aqt_Status Camera::SetDataRouter(::std::string dataRouterName)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_CameraSetDataRouter(m_private->m_camera,
        dataRouterName.c_str());
    }

    bool Camera::GetCanStreamLiveNow()
    {
      bool ret;
      if (m_private) {
        m_private->m_status = aqt_CameraGetCanStreamLiveNow(m_private->m_camera, &ret);
      }

      return ret;
    }

    ::std::vector<aqt::Interval> Camera::GetStoredDataRanges(bool enableSubset)
    {
      ::std::vector<aqt::Interval> ret;
      if (!m_private) {
        return ret;
      }
      m_private->m_status = aqt_STATUS_OKAY;

      aqt_DataRangeFilter filter;
      m_private->m_status = aqt_DataRangeFilterCreate(&filter);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return ret;
      }
      m_private->m_status = aqt_DataRangeFilterSetEnableSubset(filter, enableSubset);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return ret;
      }

      uint32_t count;
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetNumStoredDataRangesFiltered(
          m_private->m_camera, filter, &count))) {
        // We already have an error condition, so we ignore the result here so
        // that will can pass back the original error value.
        aqt_DataRangeFilterDestroy(filter);
        return ret;
      }
      m_private->m_status = aqt_DataRangeFilterDestroy(filter);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return ret;
      }

      aqt_Interval interval;
      for (uint32_t i = 0; i < count; i++) {
        if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetStoredDataRange(
            m_private->m_camera, i, &interval))) {
          ret.clear();
          return ret;
        }
        ret.push_back(interval);
      }

      return ret;
    }

    ::std::string Camera::GetStreamingModes()
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }

      m_private->m_status = aqt_STATUS_OKAY;

      uint32_t count;
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetStreamingModesLength(
        m_private->m_camera, &count))) {
        return ret;
      }

      ::std::vector<char> value(count);
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_CameraGetStreamingModes(
          m_private->m_camera, value.data()))) {
        return ret;
      }
      ret = value.data();

      return ret;
    }

    aqt_Status Camera::SetStreamingMode(uint32_t mode)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_CameraSetStreamingMode(m_private->m_camera,
        mode);
    }

    aqt_Status Camera::SetStreamingMode(::std::string JSONConfiguration)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_CameraSetStreamingModeString(m_private->m_camera,
        JSONConfiguration.c_str());
    }

  } // End namespace camera

  namespace update {

    //-----------------------------------------------------------------------
    class Update::Update_private {
    public:
      aqt_Update m_update = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    Update::Update(AquetiAPI &api, ::std::string entityName)
    {
      // Create the private api pointer we're going to use.  Check for
      // exception when creating it, to avoid passing it up to the caller.
      try {
        m_private = new Update_private();
      } catch (int) {
        m_private = nullptr;
        return;
      }

      // Create and fill in the parameters to the stream creation routine
      aqt_UpdateCreateParams params;
      m_private->m_status = aqt_UpdateCreateParametersCreate(&params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->m_status = aqt_UpdateCreateParametersSetAPI(params, api.GetRawAPI());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_UpdateCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_UpdateCreateParametersSetName(params, entityName.c_str());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_UpdateCreateParametersDestroy(params);
        return;
      }

      m_private->m_status = aqt_UpdateCreate(&m_private->m_update, params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_UpdateCreateParametersDestroy(params);
        return;
      }

      // Delete the structures we created along the way
      m_private->m_status = aqt_UpdateCreateParametersDestroy(params);
    }

    Update::~Update()
    {
      // Destroy any API object we created.
      if (m_private && m_private->m_update) {
        aqt_UpdateDestroy(m_private->m_update);
      }
      delete m_private;
    }

    aqt_Status Update::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    ::std::string Update::GetSoftwareVersion()
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }

      m_private->m_status = aqt_STATUS_OKAY;

      uint32_t count;
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_UpdateGetSoftwareVersionLength(
        m_private->m_update, &count))) {
        return ret;
      }

      ::std::vector<char> value(count);
      if (aqt_STATUS_OKAY != (m_private->m_status = aqt_UpdateGetSoftwareVersion(
        m_private->m_update, value.data()))) {
        return ret;
      }
      ret = value.data();

      return ret;
    }

    aqt_Status Update::Install(std::vector<uint8_t> data, std::string checksum)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_UpdateInstall(m_private->m_update,
        data.data(), static_cast<uint32_t>(data.size()),
        checksum.data());
    }

    aqt_Status Update::InstallFromURL(std::string dataURL, std::string checksumURL)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_UpdateInstallFromURL(m_private->m_update,
        dataURL.data(), checksumURL.data());
    }

  } // End namespace update

  namespace externalAnalysis {

    //-----------------------------------------------------------------------
    class ExternalAnalysis::ExternalAnalysis_private {
    public:
      aqt_ExternalAnalysis m_analysis = nullptr;
      aqt_Status m_status = aqt_STATUS_OKAY;
    };

    ExternalAnalysis::ExternalAnalysis(
      AquetiAPI &api,
      ::std::string sourceName)
    {
      // Create the private api pointer we're going to use.  Check for
      // exception when creating it, to avoid passing it up to the caller.
      try {
        m_private = new ExternalAnalysis_private();
      } catch (int) {
        m_private = nullptr;
        return;
      }

      // Create and fill in the parameters to the stream creation routine
      aqt_ExternalAnalysisCreateParams params;
      m_private->m_status = aqt_ExternalAnalysisCreateParametersCreate(&params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->m_status = aqt_ExternalAnalysisCreateParametersSetAPI(params, api.GetRawAPI());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_ExternalAnalysisCreateParametersDestroy(params);
        return;
      }
      m_private->m_status = aqt_ExternalAnalysisCreateParametersSetSourceName(params, sourceName.c_str());
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_ExternalAnalysisCreateParametersDestroy(params);
        return;
      }

      m_private->m_status = aqt_ExternalAnalysisCreate(&m_private->m_analysis, params);
      if (m_private->m_status != aqt_STATUS_OKAY) {
        m_private->m_status = aqt_ExternalAnalysisCreateParametersDestroy(params);
        return;
      }

      // Delete the structures we created along the way
      m_private->m_status = aqt_ExternalAnalysisCreateParametersDestroy(params);
    }

    ExternalAnalysis::~ExternalAnalysis()
    {
      // Destroy any API object we created.
      if (m_private && m_private->m_analysis) {
        aqt_ExternalAnalysisDestroy(m_private->m_analysis);
      }
      delete m_private;
    }

    aqt_Status ExternalAnalysis::GetStatus() const
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_Status ret = m_private->m_status;
      m_private->m_status = aqt_STATUS_OKAY;
      return ret;
    }

    aqt_Status ExternalAnalysis::SetStartTime(struct timeval val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisSetStartTime(m_private->m_analysis,
        val);
    }

    aqt_Status ExternalAnalysis::SetImageTypes(::std::vector<aqt_ImageType> val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisSetImageTypes(m_private->m_analysis,
        val.data(), static_cast<uint32_t>(val.size()));
    }

    aqt_Status ExternalAnalysis::SetMinImageSize(uint32_t width, uint32_t height)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisSetMinImageSize(m_private->m_analysis,
        width, height);
    }

    aqt_Status ExternalAnalysis::SetMaxImageSize(uint32_t width, uint32_t height)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisSetMaxImageSize(m_private->m_analysis,
        width, height);
    }

    Image ExternalAnalysis::GetNextImage()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_Image image = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextImage(m_private->m_analysis, &image);
      Image ret(image);
      aqt_ImageDestroy(image);
      return ret;
    }

    aqt_Status ExternalAnalysis::SetNameFilter(::std::string val)
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisSetNameFilter(m_private->m_analysis,
        val.c_str());
    }

    Rectangle ExternalAnalysis::GetNextRectangle()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_Rectangle obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextRectangle(m_private->m_analysis, &obj);
      /// @todo Figure out how to avoid this copy, and those for similar objects below.
      Rectangle ret(obj);
      aqt_RectangleDestroy(obj);
      return ret;
    }

    Point ExternalAnalysis::GetNextPoint()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_Point obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextPoint(m_private->m_analysis, &obj);
      Point ret(obj);
      aqt_PointDestroy(obj);
      return ret;
    }

    FloatArray ExternalAnalysis::GetNextFloatArray()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_FloatArray obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextFloatArray(m_private->m_analysis, &obj);
      FloatArray ret(obj);
      aqt_FloatArrayDestroy(obj);
      return ret;
    }

    U8Array ExternalAnalysis::GetNextU8Array()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_U8Array obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextU8Array(m_private->m_analysis, &obj);
      U8Array ret(obj);
      aqt_U8ArrayDestroy(obj);
      return ret;
    }

    CameraModel ExternalAnalysis::GetNextCameraModel()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_CameraModel obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextCameraModel(m_private->m_analysis, &obj);
      CameraModel ret(obj);
      aqt_CameraModelDestroy(obj);
      return ret;
    }

    Thumbnail ExternalAnalysis::GetNextThumbnail()
    {
      if (!m_private) {
        return nullptr;
      }
      if (!m_private->m_analysis) {
        m_private->m_status = aqt_STATUS_NULL_OBJECT_POINTER;
        return nullptr;
      }
      aqt_Thumbnail obj = nullptr;
      m_private->m_status = aqt_ExternalAnalysisGetNextThumbnail(m_private->m_analysis, &obj);
      Thumbnail ret(obj);
      aqt_ThumbnailDestroy(obj);
      return ret;
    }

    aqt_Status ExternalAnalysis::InsertRectangle(const Rectangle &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertRectangle(m_private->m_analysis,
        val.RawRectangle());
    }

    aqt_Status ExternalAnalysis::InsertPoint(const Point &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertPoint(m_private->m_analysis,
        val.RawPoint());
    }

    aqt_Status ExternalAnalysis::InsertFloatArray(const FloatArray &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertFloatArray(m_private->m_analysis,
        val.RawFloatArray());
    }

    aqt_Status ExternalAnalysis::InsertU8Array(const U8Array &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertU8Array(m_private->m_analysis,
        val.RawU8Array());
    }

    aqt_Status ExternalAnalysis::InsertCameraModel(const CameraModel &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertCameraModel(m_private->m_analysis,
        val.RawCameraModel());
    }

    aqt_Status ExternalAnalysis::InsertThumbnail(const Thumbnail &val)
    {
      if (!m_private || !m_private->m_analysis) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->m_status = aqt_ExternalAnalysisInsertThumbnail(m_private->m_analysis,
        val.RawThumbnail());
    }

  } // End namespace externalAnalysis

} // End namespace aqt
