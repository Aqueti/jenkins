/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_Image_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

#include <string.h>

namespace aqt {

  class Image::Image_private {
  public:
    aqt_Image image;
    aqt_Status status = aqt_STATUS_OKAY;
  };

  Image::Image(aqt_Image image)
  {
    m_private = new Image_private;
    if (!image) {
      m_private->status = aqt_STATUS_BAD_PARAMETER;
      return;
    }
    m_private->image = image;
    m_private->status = aqt_ImageCopy(&m_private->image, image);
  }

  Image::~Image()
  {
    if (m_private) {
      aqt_ImageDestroy(m_private->image);
      delete m_private;
    }
  }

  Image::Image(const Image &copy)
  {
    m_private = new Image_private();
    m_private->status = aqt_ImageCopy(&m_private->image, copy.RawImage());
  }

  Image &Image::operator = (const Image &copy)
  {
    if (m_private) {
      aqt_ImageDestroy(m_private->image);
      delete m_private;
    }
    m_private = new Image_private();
    m_private->status = aqt_ImageCopy(&m_private->image, copy.RawImage());
    return *this;
  }

  aqt_Status Image::GetStatus()
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return m_private->status;
  }

  struct timeval Image::Time() const
  {
    struct timeval ret = {};
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    if (aqt_STATUS_OKAY !=
      (m_private->status = aqt_ImageGetTime(m_private->image, &ret))) {
      return ret;
    }
    return ret;
  }

  uint32_t Image::Width() const
  {
    uint32_t ret = {};
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    if (aqt_STATUS_OKAY !=
      (m_private->status = aqt_ImageGetWidth(m_private->image, &ret))) {
      return ret;
    }
    return ret;
  }

  uint32_t Image::Height() const
  {
    uint32_t ret = {};
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    if (aqt_STATUS_OKAY !=
      (m_private->status = aqt_ImageGetHeight(m_private->image, &ret))) {
      return ret;
    }
    return ret;
  }

  aqt_ImageType Image::Type() const
  {
    aqt_ImageType ret = {};
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    if (aqt_STATUS_OKAY !=
      (m_private->status = aqt_ImageGetType(m_private->image, &ret))) {
      return ret;
    }
    return ret;
  }

  const uint8_t *Image::Data() const
  {
    const uint8_t *ret = nullptr;
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    uint32_t size;
    m_private->status = aqt_ImageGetData(m_private->image, &ret, &size);
    return ret;
  }

  uint32_t Image::Size() const
  {
    uint32_t ret = 0;
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const uint8_t *data;
    m_private->status = aqt_ImageGetData(m_private->image, &data, &ret);
    return ret;
  }

  void Image::ReleaseData()
  {
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return;
    }
    m_private->status = aqt_ImageReleaseData(m_private->image);
    return;
  }

  aqt_Image const Image::RawImage() const
  {
    aqt_Image ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (!m_private->image) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_STATUS_OKAY;
    return m_private->image;
  }

} // End namespace aqt

