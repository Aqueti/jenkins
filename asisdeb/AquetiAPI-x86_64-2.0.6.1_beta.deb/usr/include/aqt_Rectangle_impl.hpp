/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_Rectangle_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class Rectangle::Rectangle_private {
    public:
      aqt_Rectangle rectangle;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    Rectangle::Rectangle()
    {
      m_private = new Rectangle_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "Rectangle");
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      aqt_Rectangle obj = nullptr;
      m_private->status = aqt_RectangleCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_RectangleSetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->rectangle = obj;
    }

    Rectangle::Rectangle(aqt_Rectangle rectangle)
    {
      m_private = new Rectangle_private;
      if (!rectangle) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_RectangleCopy(&m_private->rectangle, rectangle);
    }

    Rectangle::~Rectangle()
    {
      if (m_private) {
        if (m_private->rectangle) {
          aqt_RectangleDestroy(m_private->rectangle);
        }
        delete m_private;
      }
    }

    Rectangle::Rectangle(const Rectangle &copy)
    {
      m_private = new Rectangle_private();
      m_private->status = aqt_RectangleCopy(&m_private->rectangle, copy.RawRectangle());
    }

    Rectangle &Rectangle::operator = (const Rectangle &copy)
    {
      if (m_private) {
        if (m_private->rectangle) {
          aqt_RectangleDestroy(m_private->rectangle);
        }
        delete m_private;
      }
      m_private = new Rectangle_private();
      m_private->status = aqt_RectangleCopy(&m_private->rectangle, copy.RawRectangle());
      return *this;
    }

    aqt_Status Rectangle::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval Rectangle::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RectangleGetInfo(m_private->rectangle, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string Rectangle::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RectangleGetInfo(m_private->rectangle, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status Rectangle::Time(struct timeval val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RectangleGetInfo(m_private->rectangle, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status Rectangle::Name(::std::string val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RectangleGetInfo(m_private->rectangle, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    double Rectangle::XNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_RectangleGetCenter(m_private->rectangle, &x, &y);
      ret = x;
      return ret;
    }

    double Rectangle::YNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_RectangleGetCenter(m_private->rectangle, &x, &y);
      ret = y;
      return ret;
    }

    double Rectangle::WidthNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double width, height;
      m_private->status = aqt_RectangleGetSize(m_private->rectangle, &width, &height);
      ret = width;
      return ret;
    }

    double Rectangle::HeightNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double width, height;
      m_private->status = aqt_RectangleGetSize(m_private->rectangle, &width, &height);
      ret = height;
      return ret;
    }

    aqt_Status Rectangle::XNorm(double val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_RectangleGetCenter(m_private->rectangle, &x, &y);
      x = val;
      return aqt_RectangleSetCenter(m_private->rectangle, x, y);
    }

    aqt_Status Rectangle::YNorm(double val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_RectangleGetCenter(m_private->rectangle, &x, &y);
      y = val;
      return aqt_RectangleSetCenter(m_private->rectangle, x, y);
    }

    aqt_Status Rectangle::WidthNorm(double val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double width, height;
      m_private->status = aqt_RectangleGetSize(m_private->rectangle, &width, &height);
      width = val;
      return aqt_RectangleSetSize(m_private->rectangle, width, height);
    }

    aqt_Status Rectangle::HeightNorm(double val)
    {
      if (!m_private || !m_private->rectangle) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double width, height;
      m_private->status = aqt_RectangleGetSize(m_private->rectangle, &width, &height);
      height = val;
      return aqt_RectangleSetSize(m_private->rectangle, width, height);
    }

    aqt_Rectangle const Rectangle::RawRectangle() const
    {
      aqt_Rectangle ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->rectangle) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->rectangle;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

