
#ifndef AQT_EXPORT_H
#define AQT_EXPORT_H

#ifdef AQT_STATIC_DEFINE
#  define AQT_EXPORT
#  define AQT_NO_EXPORT
#else
#  ifndef AQT_EXPORT
#    ifdef AQT_EXPORTS
        /* We are building this library */
#      define AQT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AQT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AQT_NO_EXPORT
#    define AQT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AQT_DEPRECATED
#  define AQT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AQT_DEPRECATED_EXPORT
#  define AQT_DEPRECATED_EXPORT AQT_EXPORT AQT_DEPRECATED
#endif

#ifndef AQT_DEPRECATED_NO_EXPORT
#  define AQT_DEPRECATED_NO_EXPORT AQT_NO_EXPORT AQT_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define AQT_NO_DEPRECATED
#endif

#endif
