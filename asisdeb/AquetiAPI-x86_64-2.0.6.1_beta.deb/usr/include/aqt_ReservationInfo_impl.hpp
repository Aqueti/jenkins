/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_ReservationInfo_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  class ReservationInfo::ReservationInfo_private {
  public:
    aqt_ReservationInfo ReservationInfo = nullptr;
    aqt_Status status = aqt_STATUS_OKAY;
  };

  ReservationInfo::ReservationInfo()
  {
    m_private = new ReservationInfo_private;
    aqt_ReservationInfo obj = nullptr;
    m_private->status = aqt_ReservationInfoCreate(&obj);
    m_private->ReservationInfo = obj;
  }

  ReservationInfo::ReservationInfo(aqt_ReservationInfo ReservationInfo)
  {
    m_private = new ReservationInfo_private;
    if (!ReservationInfo) {
      m_private->status = aqt_STATUS_BAD_PARAMETER;
      return;
    }
    m_private->ReservationInfo = ReservationInfo;
    m_private->status = aqt_STATUS_OKAY;
  }

  ReservationInfo::~ReservationInfo()
  {
    if (m_private) {
      if (m_private->ReservationInfo) {
        aqt_ReservationInfoDestroy(m_private->ReservationInfo);
      }
      delete m_private;
    }
  }

  ReservationInfo::ReservationInfo(const ReservationInfo &copy)
  {
    m_private = new ReservationInfo_private();
    m_private->status = aqt_ReservationInfoCopy(&m_private->ReservationInfo, copy.RawReservationInfo());
  }

  ReservationInfo &ReservationInfo::operator = (const ReservationInfo &copy)
  {
    if (m_private) {
      if (m_private->ReservationInfo) {
        aqt_ReservationInfoDestroy(m_private->ReservationInfo);
      }
      delete m_private;
    }
    m_private = new ReservationInfo_private();
    m_private->status = aqt_ReservationInfoCopy(&m_private->ReservationInfo, copy.RawReservationInfo());
    return *this;
  }

  aqt_Status ReservationInfo::GetStatus()
  {
    if (!m_private) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return m_private->status;
  }

  ::std::string ReservationInfo::EntityName() const
  {
    ::std::string ret;
    if (!m_private || !m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *name;
    if (aqt_STATUS_OKAY != (m_private->status =
        aqt_ReservationInfoGetEntityName(m_private->ReservationInfo, &name))) {
      return ret;
    }
    ret = name;
    return ret;
  }

  aqt_Status ReservationInfo::EntityName(::std::string val)
  {
    if (!m_private || !m_private->ReservationInfo) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_ReservationInfoSetEntityName(m_private->ReservationInfo, val.c_str());
  }

  aqt::Interval ReservationInfo::Interval() const
  {
    aqt_Interval ret = { { 0,0 }, aqt_Interval_UNDEFINED_END };
    if (!m_private || !m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_ReservationInfoGetInterval(m_private->ReservationInfo, &ret);
    return ret;
  }

  aqt_Status ReservationInfo::Interval(aqt::Interval val)
  {
    if (!m_private || !m_private->ReservationInfo) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    aqt_Interval aVal = { val.Start(), val.End() };
    return aqt_ReservationInfoSetInterval(m_private->ReservationInfo, aVal);
  }

  aqt::ReservationPolicy ReservationInfo::ReservationPolicy() const
  {
    aqt_ReservationPolicy ret = nullptr;
    if (!m_private || !m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_ReservationInfoGetReservationPolicy(m_private->ReservationInfo, &ret);
    return ret;
  }

  aqt_Status ReservationInfo::ReservationPolicy(aqt::ReservationPolicy val)
  {
    if (!m_private || !m_private->ReservationInfo) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_ReservationInfoSetReservationPolicy(m_private->ReservationInfo,
      val.RawReservationPolicy());
  }

  ::std::string ReservationInfo::UserName() const
  {
    ::std::string ret;
    if (!m_private || !m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    const char *name;
    if (aqt_STATUS_OKAY != (m_private->status =
      aqt_ReservationInfoGetUserName(m_private->ReservationInfo, &name))) {
      return ret;
    }
    ret = name;
    return ret;
  }

  aqt_Status ReservationInfo::UserName(::std::string val)
  {
    if (!m_private || !m_private->ReservationInfo) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    return aqt_ReservationInfoSetUserName(m_private->ReservationInfo, val.c_str());
  }

  ::std::vector<aqt::KeyValue> ReservationInfo::MetaData() const
  {
    ::std::vector<aqt::KeyValue> ret;
    if (!m_private || !m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    uint32_t count;
    if (aqt_STATUS_OKAY != (m_private->status =
      aqt_ReservationInfoGetNumMetaData(m_private->ReservationInfo, &count))) {
      return ret;
    }
    for (uint32_t i = 0; i < count; i++) {
      aqt_KeyValue kv;
      if (aqt_STATUS_OKAY != (m_private->status =
        aqt_ReservationInfoGetMetaData(m_private->ReservationInfo, i, &kv))) {
        return ret;
      }
      // Push back a copy of the data
      ret.push_back(kv);
    }
    return ret;
  }

  aqt_Status ReservationInfo::MetaData(::std::vector<aqt::KeyValue> data)
  {
    if (!m_private || !m_private->ReservationInfo) {
      return aqt_STATUS_NULL_OBJECT_POINTER;
    }
    // The set function will copy the data, so we just pass it a set of pointers to the
    // existing objects to copy.
    std::vector<aqt_KeyValue> kvs;
    for (size_t i = 0; i < data.size(); i++) {
      kvs.push_back(data[i].RawKeyValue());
    }
    return aqt_ReservationInfoSetMetaData(m_private->ReservationInfo,
      kvs.data(), static_cast<uint32_t>(kvs.size()));
  }
  
  aqt_ReservationInfo const ReservationInfo::RawReservationInfo() const
  {
    aqt_ReservationInfo ret = nullptr;
    if (!m_private) {
      return ret;
    }
    if (!m_private->ReservationInfo) {
      m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
      return ret;
    }
    m_private->status = aqt_STATUS_OKAY;
    return m_private->ReservationInfo;
  }

} // End namespace aqt
