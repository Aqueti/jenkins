/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_U8Array_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class U8Array::U8Array_private {
    public:
      aqt_U8Array U8Array;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    U8Array::U8Array()
    {
      m_private = new U8Array_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "U8Array");
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      aqt_U8Array obj = nullptr;
      m_private->status = aqt_U8ArrayCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_U8ArraySetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->U8Array = obj;
    }

    U8Array::U8Array(aqt_U8Array U8Array)
    {
      m_private = new U8Array_private;
      if (!U8Array) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_U8ArrayCopy(&m_private->U8Array, U8Array);
    }

    U8Array::~U8Array()
    {
      if (m_private) {
        if (m_private->U8Array) {
          aqt_U8ArrayDestroy(m_private->U8Array);
        }
        delete m_private;
      }
    }

    U8Array::U8Array(const U8Array &copy)
    {
      m_private = new U8Array_private();
      m_private->status = aqt_U8ArrayCopy(&m_private->U8Array, copy.RawU8Array());
    }

    U8Array &U8Array::operator = (const U8Array &copy)
    {
      if (m_private) {
        if (m_private->U8Array) {
          aqt_U8ArrayDestroy(m_private->U8Array);
        }
        delete m_private;
      }
      m_private = new U8Array_private();
      m_private->status = aqt_U8ArrayCopy(&m_private->U8Array, copy.RawU8Array());
      return *this;
    }

    aqt_Status U8Array::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval U8Array::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->U8Array) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetInfo(m_private->U8Array, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string U8Array::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->U8Array) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetInfo(m_private->U8Array, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status U8Array::Time(struct timeval val)
    {
      if (!m_private || !m_private->U8Array) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetInfo(m_private->U8Array, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status U8Array::Name(::std::string val)
    {
      if (!m_private || !m_private->U8Array) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetInfo(m_private->U8Array, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    ::std::vector<uint8_t> U8Array::Value() const
    {
      ::std::vector<uint8_t> ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->U8Array) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetArrayLength(m_private->U8Array, &count))) {
        return ret;
      }
      ret.resize(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_U8ArrayGetArray(m_private->U8Array, ret.data()))) {
        ret.clear();
        return ret;
      }
      return ret;
    }

    aqt_Status U8Array::Value(::std::vector<uint8_t> val)
    {
      if (!m_private || !m_private->U8Array) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_U8ArraySetArray(m_private->U8Array, val.data(),
        static_cast<uint32_t>(val.size()));
    }

    aqt_U8Array const U8Array::RawU8Array() const
    {
      aqt_U8Array ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->U8Array) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->U8Array;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

