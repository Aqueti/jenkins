/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_FloatArray_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class FloatArray::FloatArray_private {
    public:
      aqt_FloatArray floatArray;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    FloatArray::FloatArray()
    {
      m_private = new FloatArray_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "FloatArray");
      aqt_FloatArray obj = nullptr;
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_FloatArrayCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_FloatArraySetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->floatArray = obj;
    }

    FloatArray::FloatArray(aqt_FloatArray floatArray)
    {
      m_private = new FloatArray_private;
      if (!floatArray) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_FloatArrayCopy(&m_private->floatArray, floatArray);
    }

    FloatArray::~FloatArray()
    {
      if (m_private) {
        if (m_private->floatArray) {
          aqt_FloatArrayDestroy(m_private->floatArray);
        }
        delete m_private;
      }
    }

    FloatArray::FloatArray(const FloatArray &copy)
    {
      m_private = new FloatArray_private();
      m_private->status = aqt_FloatArrayCopy(&m_private->floatArray, copy.RawFloatArray());
    }

    FloatArray &FloatArray::operator = (const FloatArray &copy)
    {
      if (m_private) {
        if (m_private->floatArray) {
          aqt_FloatArrayDestroy(m_private->floatArray);
        }
        delete m_private;
      }
      m_private = new FloatArray_private();
      m_private->status = aqt_FloatArrayCopy(&m_private->floatArray, copy.RawFloatArray());
      return *this;
    }

    aqt_Status FloatArray::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval FloatArray::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->floatArray) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetInfo(m_private->floatArray, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string FloatArray::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->floatArray) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetInfo(m_private->floatArray, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status FloatArray::Time(struct timeval val)
    {
      if (!m_private || !m_private->floatArray) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetInfo(m_private->floatArray, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status FloatArray::Name(::std::string val)
    {
      if (!m_private || !m_private->floatArray) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetInfo(m_private->floatArray, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    ::std::vector<float> FloatArray::Value() const
    {
      ::std::vector<float> ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->floatArray) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetArrayLength(m_private->floatArray, &count))) {
        return ret;
      }
      ret.resize(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_FloatArrayGetArray(m_private->floatArray, ret.data()))) {
        ret.clear();
        return ret;
      }
      return ret;
    }

    aqt_Status FloatArray::Value(::std::vector<float> val)
    {
      if (!m_private || !m_private->floatArray) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return aqt_FloatArraySetArray(m_private->floatArray, val.data(),
        static_cast<uint32_t>(val.size()));
    }

    aqt_FloatArray const FloatArray::RawFloatArray() const
    {
      aqt_FloatArray ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->floatArray) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->floatArray;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

