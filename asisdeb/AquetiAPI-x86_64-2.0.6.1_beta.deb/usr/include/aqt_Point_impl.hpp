/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_Point_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

namespace aqt {

  namespace externalAnalysis {

    class Point::Point_private {
    public:
      aqt_Point point;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    Point::Point()
    {
      m_private = new Point_private;
      aqt_AnalysisInfo info = nullptr;
      m_private->status = aqt_AnalysisInfoCreate(&info);
      if (m_private->status != aqt_STATUS_OKAY) {
        return;
      }
      m_private->status = aqt_AnalysisInfoSetType(info, "Point");
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      aqt_Point obj = nullptr;
      m_private->status = aqt_PointCreate(&obj);
      if (m_private->status != aqt_STATUS_OKAY) {
        aqt_AnalysisInfoDestroy(info);
        return;
      }
      m_private->status = aqt_PointSetInfo(obj, info);
      aqt_AnalysisInfoDestroy(info);
      m_private->point = obj;
    }

    Point::Point(aqt_Point point)
    {
      m_private = new Point_private;
      if (!point) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_PointCopy(&m_private->point, point);
    }

    Point::~Point()
    {
      if (m_private) {
        if (m_private->point) {
          aqt_PointDestroy(m_private->point);
        }
        delete m_private;
      }
    }

    Point::Point(const Point &copy)
    {
      m_private = new Point_private();
      m_private->status = aqt_PointCopy(&m_private->point, copy.RawPoint());
    }

    Point &Point::operator = (const Point &copy)
    {
      if (m_private) {
        if (m_private->point) {
          aqt_PointDestroy(m_private->point);
        }
        delete m_private;
      }
      m_private = new Point_private();
      m_private->status = aqt_PointCopy(&m_private->point, copy.RawPoint());
      return *this;
    }

    aqt_Status Point::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    struct timeval Point::Time() const
    {
      struct timeval ret = {};
      if (!m_private) {
        return ret;
      }
      if (!m_private->point) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_PointGetInfo(m_private->point, &info))) {
        return ret;
      }
      m_private->status = aqt_AnalysisInfoGetTime(info, &ret);
      return ret;
    }

    ::std::string Point::Name() const
    {
      ::std::string ret;
      if (!m_private) {
        return ret;
      }
      if (!m_private->point) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_PointGetInfo(m_private->point, &info))) {
        return ret;
      }
      uint32_t count;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetNameLength(info, &count))) {
        return ret;
      }
      ::std::vector<char> retVec(count);
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_AnalysisInfoGetName(info, retVec.data()))) {
        return ret;
      }
      ret = ::std::string(retVec.data(), retVec.size());
      return ret;
    }

    aqt_Status Point::Time(struct timeval val)
    {
      if (!m_private || !m_private->point) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_PointGetInfo(m_private->point, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetTime(info, val);
    }

    aqt_Status Point::Name(::std::string val)
    {
      if (!m_private || !m_private->point) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      aqt_AnalysisInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_PointGetInfo(m_private->point, &info))) {
        return m_private->status;
      }
      return aqt_AnalysisInfoSetName(info, val.c_str());
    }

    double Point::XNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->point) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_PointGetCenter(m_private->point, &x, &y);
      ret = x;
      return ret;
    }

    double Point::YNorm() const
    {
      double ret = 0;
      if (!m_private) {
        return ret;
      }
      if (!m_private->point) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      double x, y;
      m_private->status = aqt_PointGetCenter(m_private->point, &x, &y);
      ret = y;
      return ret;
    }

    aqt_Status Point::XNorm(double val)
    {
      if (!m_private || !m_private->point) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_PointGetCenter(m_private->point, &x, &y);
      x = val;
      return aqt_PointSetCenter(m_private->point, x, y);
    }

    aqt_Status Point::YNorm(double val)
    {
      if (!m_private || !m_private->point) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      double x, y;
      m_private->status = aqt_PointGetCenter(m_private->point, &x, &y);
      y = val;
      return aqt_PointSetCenter(m_private->point, x, y);
    }

    aqt_Point const Point::RawPoint() const
    {
      aqt_Point ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->point) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->point;
    }

  } // End namespace externalAnalysis

} // End namespace aqt

