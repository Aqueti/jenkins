/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/**
* @file aqt_api_defs.hpp
* @brief Aqueti C++ API to its camera systems.
*
* This is the C++ wrapper for the API, which wraps the C API and handles the
* construction and destruction and copying of objects.  This file declares the interface
* both for the client applications and for the developer (who implements the classes
* and methods found herein).  This C++ API is wrapped using SWIG into Python.
* To make use of this file, you should include aqt_api.hpp in a client source file;
* that file includes the definitions of the methods declared here for the upper
* half of the wrapping (hourglass design).
* @author Aqueti.
* @date February 2, 2018.
*/

// Include the C header file to get access to the definitions for the types and
// functions.
#include "aqt_api.h"

#include <string>
#include <vector>
#include <memory>

// Everything defined here lives in the aqt namespace.
namespace aqt {

  // Forward declare classes that we will befriend in namespaces we will use
  namespace render {
    class TimeState;
    class ViewState;
    class PoseState;
    class ImageSubsetState;
    class RenderStream;
  };
  namespace camera { class Camera; };
  namespace update { class Update; }
  namespace externalAnalysis { class ExternalAnalysis; }

  // Data classes used by the API classes.

  /// @brief C++ wrapper around the aqt_Interval class.
  ///
  /// At least when converted to Python, we get into trouble when we
  /// return an aqt_Interval struct from a method because the caller can do something
  /// like start = reservationInfo.Interval().start, at which point Python
  /// sees no further reference to the object returned by Interval() and
  /// deletes it.  Later references to start then point to memory that has
  /// been de-allocated, which eventually fail.
  /// To avoid this, we hide the data members to SWIG and replace them
  /// with inline methods to get the data.
  /// Time interval is >= Start() and < End().  For an interval that is
  /// not yet completed (currently recording), End() will be
  /// aqt_Interval_UNDEFINED_END.
  class Interval {
  public:
    /// @brief Constructs an Interval given a start and end time.
    /// @param [in] startParam Sets the start time.
    /// @param [in] endParam Sets the end time.
    Interval(struct timeval startParam, struct timeval endParam) {
      m_start = startParam;
      m_end = endParam;
    }
    /// @brief Constructs an Interval given another Interval.
    /// @param [in] i Interval to copy start and end time from.
    Interval(aqt_Interval const &i) {
      m_start = i.start;
      m_end = i.end;
    }
    /// @brief Constructs a default Interval from 0 to aqt_Interval_UNDEFINED_END
    Interval() { };
    /// @brief Return the start time for an Interval.
    struct timeval Start() { return m_start; }
    /// @brief Return the end time for an Interval.
    struct timeval End() { return m_end; }

  private:
    struct timeval m_start = {};
    struct timeval m_end = aqt_Interval_UNDEFINED_END;
  };


  /// @brief Stores the properties of a stream.
  ///
  /// This class stores the properties of a RenderStream and it used to describe
  /// the desired properties when a RenderStream is created.  It wraps an
  /// aqt_StreamProperties C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class StreamProperties {
  public:

    /// @brief Construct properties with default values for all items.
    StreamProperties();

    /// @brief Destroys the properties.
    ~StreamProperties();

    /// @brief Construct one StreamProperties by copying an existing one.
    /// @param [in] copy StreamProperties to copy from.
    StreamProperties(const StreamProperties& copy);

    /// @brief Set the values of a StreamProperties to match another.
    /// @param [in] copy StreamProperties to copy from.
    StreamProperties &operator = (const StreamProperties &copy);

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of a StreamProperties and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the StreamProperties itself is broken.
    aqt_Status GetStatus() const;

    /// @brief Read the stream type.
    /// @return Stream type.
    aqt_StreamType Type();
    /// @brief Set the stream type.
    /// @param [in] type Its default value is aqt_STREAM_TYPE_H264.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Type(aqt_StreamType type);

    /// @brief Read the width of all images in the stream.
    /// @return Width of the image stream.
    uint32_t Width();
    /// @brief Set the width of all images in the stream.
    /// @param [in] width Its default value is 1920.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Width(uint32_t width);

    /// @brief Read the height of all images in the stream.
    /// @return Height of the image stream.
    uint32_t Height();
    /// @brief Set the height of all images in the stream.
    /// @param [in] height Its default value is 1080.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Height(uint32_t height);

    /// @brief Read the frames/second for the stream.
    /// @return Frame rate of the image stream.
    double FrameRate();
    /// @brief Set the frames/second for the stream.
    /// @param [in] rate Its default value is 30.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status FrameRate(double rate);

    /// @brief Read the value of the can-skip parameter.
    /// @return When can-skip is true, the stream will perform best-effort display
    ///         of each frame but may display stale data from time to time as the system
    ///         becomes overloaded.  When can-skip is true, the system waits as long as
    ///         necessary to decompress and display all available frames for an image even
    ///         if this makes it render much more slowly than the specified frame rate.
    bool CanSkip();
    /// @brief Set the value of the can-skip parameter.
    /// @param [in] can When can-skip is true, the stream will perform best-effort display
    ///         of each frame but may display stale data from time to time as the system
    ///         becomes overloaded.  When can-skip is true, the system waits as long as
    ///         necessary to decompress and display all available frames for an image even
    ///         if this makes it render much more slowly than the specified frame rate.
    ///         Its default value is true.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status CanSkip(bool can);

    /// @brief Read the value of the quality parameter.
    /// @return For streams that involve compression, the Quality parameter determines
    ///       the level of compression, from 0 (most compressed, lowest bit rate) to
    ///       1 (least compressed, highest bit rate).
    double Quality();
    /// @brief Set the value of the quality parameter.
    /// @param [in] quality For streams that involve compression, the Quality parameter determines
    ///       the level of compression, from 0 (most compressed, lowest bit rate) to
    ///       1 (least compressed, highest bit rate).  The default value is 0.8.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Quality(double quality);

    /// @brief Read the value of the IDR Interval parameter.
    /// @return For streams that involve compression with multiple frame types, the
    ///       IDRInterval parameter determines how many prediction (P) frames come
    ///       between Image frames.  An IDR frame guarantees that no images following
    ///       it depend on any images from before it.  A value of 1 will make every
    ///       frame an IDR frame.
    uint32_t IDRInterval();
    /// @brief Set the value of the IDR Interval parameter.
    /// @param [in] IDRInterval For streams that involve compression with multiple frame types, the
    ///       IDRInterval parameter determines how many prediction (P) frames come
    ///       between Image frames.  An IDR frame guarantees that no images following
    ///       it depend on any images from before it.  A value of 1 will make every
    ///       frame an IDR frame.  The default value is 30.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status IDRInterval(uint32_t IDRInterval);

    /// @brief Read the value of the window X position parameter.
    /// @return For streams that involve direct display to a monitor, the
    ///       WindowX parameter describes where the screen will be placed on the
    ///       operating system's display.
    int32_t WindowX();
    /// @brief Set the value of the window X position parameter.
    /// @param [in] windowX For streams that involve direct display to a monitor, the
    ///       WindowX parameter describes where the screen will be placed on the
    ///       operating system's display.  The default value is 0.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status WindowX(int32_t windowX);

    /// @brief Read the value of the window Y position parameter.
    /// @return For streams that involve direct display to a monitor, the
    ///       WindowX parameter describes where the screen will be placed on the
    ///       operating system's display.
    int32_t WindowY();
    /// @brief Set the value of the window Y position parameter.
    /// @param [in] windowY For streams that involve direct display to a monitor, the
    ///       WindowY parameter describes where the screen will be placed on the
    ///       operating system's display.  The default value is 0.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status WindowY(int32_t windowY);

    /// @brief Read the value of the FullScreen parameter.
    /// @return For streams that involve direct display to a monitor, the
    ///       FullScreen parameter determines whether the stream will be shown in
    ///       a window (false) or on the entire display (true).  This can cause the
    ///       resolution to not exactly match what was requested.
    bool FullScreen();
    /// @brief Set the value of the FullScreen parameter.
    /// @param [in] fs For streams that involve direct display to a monitor, the
    ///       FullScreen parameter determines whether the stream will be shown in
    ///       a window (false) or on the entire display (true).  This can cause the
    ///       resolution to not exactly match what was requested.  The default is true.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status FullScreen(bool fs);

    /// @brief Read the value of the Display parameter.
    /// @return For streams that involve direct display to a monitor, the Display
    ///       parameter determines which
    ///       of the attached displays will be used for the full-screen display.
    ///       Display mapping is operating-system dependent and can also depend on
    ///       the order in which displays are discovered.
    uint32_t Display();
    /// @brief Set the value of the Display parameter.
    /// @param [in] display For streams that involve direct display to a monitor,
    ///       the Display parameter determines which
    ///       of the attached displays will be used for the full-screen display.
    ///       Display mapping is operating-system dependent and can also depend on
    ///       the order in which displays are discovered.  The default is 0.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Display(uint32_t display);

    /// @brief Private class declared for definition and use by the API implementation.
    class StreamProperties_private;

  protected:
    /// @brief Protected method for use by the API implementation.
    std::shared_ptr<aqt_StreamProperties_> GetRawProperties() const;
    /// @cond INTERNAL
    friend render::RenderStream;
    /// @endcond

  private:
    std::shared_ptr<StreamProperties_private> m_private;
  };

  /// @brief Stores the properties of an intrinsic camera calibration.
  ///
  /// This class stores the properties of an intrinsic camera calibration.  It is a
  /// C++ analog of the aqt_APICameraInstrinsic C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  /// A vector of this class is part of a SingleCOPCameraDescription.  There can be
  /// multiple such instances for a single camera, with different minimum-pixel sizes.
  /// An application should select the one that has the desired resolution.
  /// Check whether the result is equal to UNDEFINED_INTRINSIC to test whether there
  /// is a valid calibration for this camera.

  class IntrinsicCalibration {
  public:
    /// @brief Construct an IntrinsicCalibration with default values.
    IntrinsicCalibration() {};
    /// @brief Destroy an IntrinsicCalibration.
    ~IntrinsicCalibration() {};

    /// @brief Read the width of the viewpoint in degrees.
    double WidthDegrees() const { return m_widthDegrees; }
    /// @brief Set the width of the viewpoint in degrees (set in struct, not in camera).
    void WidthDegrees(double val) { m_widthDegrees = val; }

    /// @brief Read the height of the viewpoint in degrees.
    double HeightDegrees() const { return m_heightDegrees; }
    /// @brief Set the height of the viewpoint in degrees (set in struct, not in camera).
    void HeightDegrees(double val) { m_heightDegrees = val; }

    /// @brief Read the maximum dimension of minimum-sized pixel in degrees.
    double PixelSizeDegrees() const { return m_pixelSizeDegrees; }
    /// @brief Set the maximum dimension of minimum-sized pixel in degrees (set in struct, not in camera).
    void PixelSizeDegrees(double val) { m_pixelSizeDegrees = val; }

    /// @brief Check two IntrinsicCalibration for equality.
    bool operator == (IntrinsicCalibration const &o) const {
      return (o.m_widthDegrees == m_widthDegrees) && (o.m_heightDegrees == m_heightDegrees) &&
        (o.m_pixelSizeDegrees == m_pixelSizeDegrees);
    }
    /// @brief Check two IntrinsicCalibration for inequality.
    bool operator != (IntrinsicCalibration const &o) {
      return !(o == *this);
    }

  private:
    double m_widthDegrees = -1;          ///< Frustum width
    double m_heightDegrees = -1;         ///< Frustum height
    double m_pixelSizeDegrees = -1;      ///< Maximum dimension of minimum-sized pixel
  };

  /// @brief The instrinsic calibration of an uncalibrated camera.
  static IntrinsicCalibration UNDEFINED_INTRINSIC;

  /// @brief Stores the properties of an extrinsic camera calibration.
  ///
  /// This class stores the properties of an extrinsic camera calibration.  It is a
  /// C++ analog of the aqt_APICameraExtrinsic C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  /// An instance of this class is part of a SingleCOPCameraDescription.
  ///
  /// This reports the position and orientation of the camera.  The position is stored
  /// in longitude (fractional degrees), latitude (fractional degrees) and altitude
  /// above sea level (meters).  The orientation is the yaw (rotation about Z, applied
  /// first), pitch (rotation about Y, applied second), and roll (rotation about X,
  /// applied last) with respect to a right-handed coordinate system describing a
  /// camera whose principal ray is pointing up along -Z and whose X axis (towards the
  /// right in the image) is pointing East, and whose Y axis (from the bottom of the
  /// image towards the top) is pointing North; the Yaw, Pitch, and Roll describe how
  /// to rotate this canonical camera to point in the direction of the actual camera.
  ///
  /// Check whether the result is equal to UNDEFINED_EXTRINSIC to test whether there
  /// is a valid calibration for this camera.

  class ExtrinsicCalibration {
  public:
    /// @brief Construct an ExtrinsicCalibration with default values.
    ExtrinsicCalibration() { }
    /// @brief Destroy an ExtrinsicCalibration.
    ~ExtrinsicCalibration() { }

    /// @brief Read the latitude of the camera location in degrees.
    double Latitude() const { return m_latitude; }
    /// @brief Set the latitude of the camera location in degrees (set in struct, not in camera).
    void Latitude(double val) { m_latitude = val; }

    /// @brief Set the longitude of the camera location in degrees.
    double Longitude() const { return m_longitude; }
    /// @brief Set the longitude of the camera location in degrees (set in struct, not in camera).
    void Longitude(double val) { m_longitude = val; }

    /// @brief Read the altitude above sea level of the camera location in meters.
    double Altitude() const { return m_altitude; }
    /// @brief Set the altitude of the camera location in meters (set in struct, not in camera).
    void Altitude(double val) { m_altitude = val; }

    /// @brief Read the pitch of the camera orientation in degrees.
    double Pitch() const { return m_pitch; }
    /// @brief Set the pitch of the camera orientation in degrees (set in struct, not in camera).
    void Pitch(double val) { m_pitch = val; }

    /// @brief Read the roll of the camera orientation in degrees.
    double Roll() const { return m_roll; }
    /// @brief Set the roll of the camera orientation in degrees (set in struct, not in camera).
    void Roll(double val) { m_roll = val; }

    /// @brief Read the yaw of the camera orientation in degrees.
    double Yaw() const { return m_yaw; }
    /// @brief Set the yaw of the camera orientation in degrees (set in struct, not in camera).
    void Yaw(double val) { m_yaw = val; }

    /// @brief Check two ExtrinsicCalibration for equality.
    bool operator == (ExtrinsicCalibration const &o) const {
      return (o.m_latitude == m_latitude) && (o.m_longitude == m_longitude) &&
        (o.m_altitude == m_altitude) && (o.m_pitch == m_pitch) &&
        (o.m_roll == m_roll) && (o.m_yaw == m_yaw);
    }
    /// @brief Check two ExtrinsicCalibration for inequality.
    bool operator != (ExtrinsicCalibration const &o) {
      return !(o == *this);
    }

  private:
    double m_latitude = 0;        ///< Location on the Earth, latitude
    double m_longitude = 0;       ///< Location on the Earth, longitude
    double m_altitude = -1e10;    ///< Height relative to Sea Level

    double m_roll = 0;            ///< Orientation relative to -Z points North, Y points Up
    double m_pitch = 0;           ///< Orientation relative to -Z points North, Y points Up
    double m_yaw = 0;             ///< Orientation relative to -Z points North, Y points Up
  };

  /// @brief The extrinsic calibration of an uncalibrated camera.
  static ExtrinsicCalibration UNDEFINED_EXTRINSIC;

  /// @brief Stores the description of a single-center-of-projection camera.
  ///
  /// This class stores the description of a single-center-of-projection camera.  It is a
  /// C++ analog of the aqt_APICameraInfo C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  ///
  /// The Name in this structure is used to identify the camera to other objects in the
  /// system.  Its intrinsic and extrinsic parameters can be used to determine which
  /// cameras to use.
  ///
  /// This is returned by aqt::AquetiAPI::GetAvailableCameras().

  class SingleCOPCameraDescription {
  public:
    SingleCOPCameraDescription() {};
    ~SingleCOPCameraDescription() {};

    /// @brief Read the name of the camera.
    ::std::string Name() const { return m_name; };
    /// @brief Set the name of the camera (set in struct, not in camera).
    void Name(const ::std::string name) { m_name = name; };

    /// @brief Read the vector of intrinsic calibrations for the camera.
    ::std::vector<IntrinsicCalibration> Intrinsics() const
      { return m_intrinsic; };
    /// @brief Set the vector of intrinsic calibrations for the camera (set in struct, not in camera).
    void Intrinsics( const ::std::vector<IntrinsicCalibration> cal)
      { m_intrinsic = cal; };

    /// @brief Read the extrinsic calibration for the camera.
    ExtrinsicCalibration Extrinsic() const { return m_extrinsic; };
    /// @brief Set the extrinsic calibratrion for the camera (set in struct, not in camera).
    void Extrinsic(const ExtrinsicCalibration &cal) { m_extrinsic = cal; };

  private:
    ::std::string m_name;
    ::std::vector<IntrinsicCalibration> m_intrinsic;
    ExtrinsicCalibration m_extrinsic;
  };

  /// @brief Stores the description of a renderer.
  ///
  /// This class stores the description of a renderer.  It is a
  /// C++ analog of the aqt_APIRendererInfo C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  ///
  /// The Name in this structure is used to identify the renderer to other objects in the
  /// system.
  ///
  /// This is returned by aqt::AquetiAPI::GetAvailableRenderers().

  class RendererDescription {
  public:
    RendererDescription() {};
    ~RendererDescription() {};

    /// @brief Read the name of the renderer.
    ::std::string Name() const { return m_name; };
    /// @brief Set the name of the renderer (set in struct, not in renderer).
    void Name(const ::std::string name) { m_name = name; };

  private:
    ::std::string m_name;
  };

  /// @brief Stores the description of a DataRouter.
  ///
  /// This class stores the description of a DataRouter.  It is a
  /// C++ analog of the aqt_APIDataRouterInfo C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  ///
  /// The Name in this structure is used to identify the DataRouter to other objects in the
  /// system.
  ///
  /// This is returned by aqt::AquetiAPI::GetAvailableDataRouters().

  class DataRouterDescription {
  public:
    DataRouterDescription() {};
    ~DataRouterDescription() {};

    /// @brief Read the name of the DataRouter.
    ::std::string Name() const { return m_name; };
    /// @brief Set the name of the DataRouter (set in struct, not in storage).
    void Name(const ::std::string name) { m_name = name; };

  private:
    ::std::string m_name;
  };

  /// @brief Stores the description of a RenderStream.
  ///
  /// This class stores the description of a RenderStream.  It is a
  /// C++ analog of the aqt_APIRenderStreamInfo C structure.  It is a data-only
  /// structure and is fully implemented in the header file.  Coupling between this
  /// and the C structure is done inside the implementation.
  ///
  /// The Name in this structure is used to identify the RenderStream to other objects in the
  /// system.
  ///
  /// This is returned by aqt::RenderStream::GetInfo().

  class RenderStreamDescription {
  public:
    RenderStreamDescription() {};
    ~RenderStreamDescription() {};

    /// @brief Read the name of the RenderStream.
    ::std::string Name() const { return m_name; };
    /// @brief Set the name of the RenderStream (set in struct, not in storage).
    void Name(const ::std::string name) { m_name = name; };

  private:
    ::std::string m_name;
  };

  /// @brief Holds the data for a logging or issue Message.
  ///
  /// This class controls and reports a Message.  It wraps an
  /// aqt_Message C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class Message {
  public:
	  /// @brief Creates a Message.
	  Message();

	  /// @brief Creates a Message and sets its entries.  Not used by client code.
	  Message(::std::string deviceID, ::std::string objectID,
		  ::std::string className, ::std::string functionName,
		  ::std::string value, struct timeval time,
		  aqt_MessageLevel level);

	  /// @brief Creates a Message from an aqt_Message.
	  /// @param [in] Message The aqt_Message to refer to when calling this
	  ///             object's methods.  It is copied on construction and
	  ///             destroyed in ~Message().
	  Message(aqt_Message Message);

	  /// @brief Destroys a Message.
	  ~Message();

	  /// @brief Copy constructor for a Message, not usually needed by client code.
	  /// @param [in] copy Message to copy.  This performs a deep copy of the the
	  ///        Message to avoid double deletion.
	  Message(const Message& copy);

	  /// @brief Assignment for a Message, not usually needed by client code.
	  /// @param [in] copy Frame to copy.  This performs a deep copy of the
	  ///        Message to avoid double deletion.
	  Message &operator = (const Message &copy);

	  /// @brief Returns the status of the most-recent operation and clears error/warnings.
	  ///
	  /// This should be called after the construction of a Message and after each method
	  /// call that does not itself return an aqt_Status to ensure that the operation
	  /// completed.
	  /// @return aqt_Status returned by the most-recent operation on the wrapped
	  ///         class, or other errors in case the Image itself is broken.
	  aqt_Status GetStatus();

	  /// @brief Get the device ID.
	  ::std::string DeviceID() const;

	  /// @brief Set the DeviceID.
	  /// @param [in] id DeviceID to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status DeviceID(::std::string id);

	  /// @brief Get the object ID.
	  ::std::string ObjectID() const;

	  /// @brief Set the ObjectID.
	  /// @param [in] id ObjectID to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status ObjectID(::std::string id);

	  /// @brief Get the class name.
	  ::std::string ClassName() const;

	  /// @brief Set the class name.
	  /// @param [in] className Class Name to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status ClassName(::std::string className);

	  /// @brief Get the function name.
	  ::std::string FunctionName() const;

	  /// @brief Set the function name.
	  /// @param [in] functionName function name to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status FunctionName(::std::string functionName);

	  /// @brief Get the value of the message.
	  ::std::string Value() const;

	  /// @brief Set the value of the message.
	  /// @param [in] value Value to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status Value(::std::string value);

	  /// @brief Get the timestamp of the message.
	  struct timeval TimeStamp() const;

	  /// @brief Set the timestamp of the message.
	  /// @param [in] value Value to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status TimeStamp(struct timeval value);

	  /// @brief Get the level of the message.
	  aqt_MessageLevel Level() const;

	  /// @brief Set the level of the message.
	  /// @param [in] value Value to set.
          /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
          ///         GetStatus() does not need to be called after this method because it
          ///         is returned here.
          aqt_Status Level(aqt_MessageLevel value);

	  /// @brief Accessor for the passed-in information during construction, not used by client code.
	  aqt_Message const RawMessage() const;

	  /// @brief Private class declared for definition and use by the API implementation.
	  class Message_private;

  private:
	  Message_private * m_private = nullptr;
  };

  /// @brief Holds the data for a reservation policy.
  ///
  /// This class controls and reports a reservation policy.  It wraps an
  /// aqt_ReservationPolicy C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class ReservationPolicy {
  public:
    /// @brief Creates a ReservationPolicy.
    ReservationPolicy();

    /// @brief Creates a ReservationPolicy from an aqt_ReservationPolicy.
    /// @param [in] ReservationPolicy The aqt_ReservationPolicy to refer to when calling this
    ///             object's methods.  It is not copied on construction, but it
    ///             is destroyed in ~ReservationPolicy() -- ReservationPolicy is taking ownership
    ///             of it at construction.
    ReservationPolicy(aqt_ReservationPolicy ReservationPolicy);

    /// @brief Destroys a ReservationPolicy.
    ~ReservationPolicy();

    /// @brief Copy constructor for a ReservationPolicy, not usually needed by client code.
    /// @param [in] copy ReservationPolicy to copy.  This performs a deep copy of the the
    ///        ReservationPolicy to avoid double deletion.
    ReservationPolicy(const ReservationPolicy& copy);

    /// @brief Assignment for a ReservationPolicy, not usually needed by client code.
    /// @param [in] copy Frame to copy.  This performs a deep copy of the
    ///        ReservationPolicy to avoid double deletion.
    ReservationPolicy &operator = (const ReservationPolicy &copy);

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of a ReservationPolicy and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the Image itself is broken.
    aqt_Status GetStatus();

    /// @brief Get the KeepUntil time.
    struct timeval KeepUntil() const;

    /// @brief Set the KeepUntil time.
    /// @param [in] val KeepUntil time to set.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status KeepUntil(struct timeval val);

    /// @brief Accessor for the passed-in information during construction, not used by client code.
    aqt_ReservationPolicy const RawReservationPolicy() const;

    /// @brief Private class declared for definition and use by the API implementation.
    class ReservationPolicy_private;

  private:
    ReservationPolicy_private *m_private = nullptr;
  };

  /// @brief Holds the data for a key/value pair.
  ///
  /// This class controls and reports a KeyValue.  It wraps an
  /// aqt_KeyValue C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class KeyValue {
  public:
    /// @brief Creates a KeyValue.
    KeyValue();

    /// @brief Creates a KeyValue and sets its key and value.
    KeyValue(::std::string key, ::std::string value);

    /// @brief Creates a KeyValue from an aqt_KeyValue.
    /// @param [in] KeyValue The aqt_KeyValue to refer to when calling this
    ///             object's methods.  It is not copied on construction, but it
    ///             is destroyed in ~KeyValue() -- KeyValue is taking ownership
    ///             of it at construction.
    KeyValue(aqt_KeyValue KeyValue);

    /// @brief Destroys a KeyValue.
    ~KeyValue();

    /// @brief Copy constructor for a KeyValue, not usually needed by client code.
    /// @param [in] copy KeyValue to copy.  This performs a deep copy of the the
    ///        KeyValue to avoid double deletion.
    KeyValue(const KeyValue& copy);

    /// @brief Assignment for a KeyValue, not usually needed by client code.
    /// @param [in] copy Frame to copy.  This performs a deep copy of the
    ///        KeyValue to avoid double deletion.
    KeyValue &operator = (const KeyValue &copy);

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of a KeyValue and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the Image itself is broken.
    aqt_Status GetStatus();

    /// @brief Get the Key.
    ::std::string Key() const;

    /// @brief Set the Key.
    /// @param [in] key Key to set.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Key(::std::string key);

    /// @brief Get the Value.
    ::std::string Value() const;

    /// @brief Set the Value.
    /// @param [in] val Value to set.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Value(::std::string val);

    /// @brief Accessor for the passed-in information during construction, not used by client code.
    aqt_KeyValue const RawKeyValue() const;

    /// @brief Private class declared for definition and use by the API implementation.
    class KeyValue_private;

  private:
    KeyValue_private *m_private = nullptr;
  };

  /// @brief Holds the data for a reservation Info.
  ///
  /// This class controls and reports a reservation Info.  It wraps an
  /// aqt_ReservationInfo C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class ReservationInfo {
  public:
    /// @brief Creates a ReservationInfo.
    ReservationInfo();

    /// @brief Creates a ReservationInfo from an aqt_ReservationInfo.
    /// @param [in] ReservationInfo The aqt_ReservationInfo to refer to when calling this
    ///             object's methods.  It is not copied on construction, but it
    ///             is destroyed in ~ReservationInfo() -- ReservationInfo is taking ownership
    ///             of it at construction.
    ReservationInfo(aqt_ReservationInfo ReservationInfo);

    /// @brief Destroys a ReservationInfo.
    ~ReservationInfo();

    /// @brief Copy constructor for a ReservationInfo, not usually needed by client code.
    /// @param [in] copy ReservationInfo to copy.  This performs a deep copy of the the
    ///        ReservationInfo to avoid double deletion.
    ReservationInfo(const ReservationInfo& copy);

    /// @brief Assignment for a ReservationInfo, not usually needed by client code.
    /// @param [in] copy Frame to copy.  This performs a deep copy of the
    ///        ReservationInfo to avoid double deletion.
    ReservationInfo &operator = (const ReservationInfo &copy);

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of a ReservationInfo and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the Image itself is broken.
    aqt_Status GetStatus();

    /// @brief Get the entity name of the ReservationInfo.
    ::std::string EntityName() const;

    /// @brief Set the entity name for the ReservationInfo.
    /// @param [in] val Entity name for the ReservationInfo.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status EntityName(::std::string val);

    /// @brief Get the interval of the ReservationInfo.
    aqt::Interval Interval() const;

    /// @brief Set the interval for the ReservationInfo.
    /// @param [in] val Interval for the ReservationInfo.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status Interval(aqt::Interval val);

    /// @brief Get the ReservationPolicy of the ReservationInfo.
    aqt::ReservationPolicy ReservationPolicy() const;

    /// @brief Set the ReservationPolicy for the ReservationInfo.
    /// @param [in] val ReservationPolicy for the ReservationInfo.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status ReservationPolicy(aqt::ReservationPolicy val);

    /// @brief Get the user name of the ReservationInfo.
    ::std::string UserName() const;

    /// @brief Set the user name for the ReservationInfo.
    /// @param [in] val User name for the ReservationInfo.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status UserName(::std::string val);

    /// @brief Get the MetaData for the reservation
    ::std::vector<aqt::KeyValue> MetaData() const;

    /// @brief Set the MetaData for the reservation
    /// @param [in] data The vector of KeyValue pairs to set.
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status MetaData(::std::vector<aqt::KeyValue> data);

    /// @brief Accessor for the passed-in information during construction, not used by client code.
    aqt_ReservationInfo const RawReservationInfo() const;

    /// @brief Private class declared for definition and use by the API implementation.
    class ReservationInfo_private;

  private:
    ReservationInfo_private *m_private = nullptr;
  };

  /// @brief Holds the data for an image returned by external analysis.
  ///
  /// This class stores and provides access to an image.  It wraps an
  /// aqt_Image C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.
  ///
  /// The client code must call ReleaseData() at least once to avoid
  /// leaking the image memory.  It must not attempt to access the pointer
  /// returned by Data() once ReleaseData() has been called.  Destroying the
  /// object does not release the underlying data.
  ///
  /// This is returned by aqt::externalAnalysis::ExternalAnalysis::GetNextImage().

  class Image {
  public:
    /// @brief Used internally to construct based on an aqt_Image.
    ///
    /// Makes a copy of the aqt_Image and destroys the copy during the
    /// deconstruction.  Does not call ReleaseData() upon destruction -- the
    /// client is responsible for doing this.
    /// @param [in] image aqt_Image that is copied to construct this class.
    Image(aqt_Image image);
    /// @brief Destroy the image object.  Does not release image data.
    ~Image();

    /// @brief Constructs by copying the Image passed in.
    Image(const Image& copy);
    /// @brief Destroys any previous image and copies from the specified image.
    /// @return Reference to the Image.
    Image &operator = (const Image &copy);

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of an Image and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the Image itself is broken.
    aqt_Status GetStatus();

    /// @brief Read the width of the image.
    uint32_t Width() const;
    /// @brief Read the height of the image.
    uint32_t Height() const;
    /// @brief Read the type of the image.
    aqt_ImageType Type() const;
    /// @brief Read the time of the image (when it was taken) converted to struct timeval.
    struct timeval Time() const;

    /// @brief Const pointer to the binary image data.
    ///
    /// This pointer remains valid until the client code calls ReleaseData() on any
    /// of the copies of this Image or on the underlying C struct.
    const uint8_t *Data() const;
    /// @brief Size of the binary image data.
    uint32_t Size() const;

    /// @brief Release the underlying image data associated with this image.
    ///
    /// Images are large enough that copying their data can cause significant
    /// performance issues, so the API passes pointers to data that is allocated
    /// when the image is received rather than copying the data.  Calling
    /// ReleaseData() passed through the API and does the appropriate deletion
    /// for this memory.  This must be done explicitly by the client code to avoid
    /// leaking memory.  Once this has been done, the pointer returned by Data()
    /// becomes invalid and must not be accessed.
    void ReleaseData();

    /// @brief Used internally to get access to the harnessed C struct.
    aqt_Image const RawImage() const;

    /// @brief Private class declared for definition and use by the API implementation.
    class Image_private;

  private:
    Image_private *m_private = nullptr;
  };

  //----------------------------------------------------
  // Constants defined for use below.

  /// @brief Default user value, indicating no user.
  static ::std::string ANONYMOUS_USER;
  /// @brief Default credentials value, indicating no credentials supplied.
  static ::std::vector<uint8_t> NO_CREDENTIALS;
  /// @brief Default vector of API server URLs; causes it to only autodiscover.
  static ::std::vector<::std::string> AUTODISCOVER_API;
  /// @brief Default renderer name, indicating "any renderer".
  static ::std::string ANY_RENDERER;
  /// @brief Default vector of data types, indicating all data types.
  static ::std::vector<aqt_DataType> ALL_DATA_TYPES;
  /// @brief Default vector of image types, indicating all image types.
  static ::std::vector<aqt_ImageType> ALL_IMAGE_TYPES;
  /// @brief Default external-analysis name, indicating all names.
  static ::std::string ALL_NAMES;

  /// @brief Implements the root-level Aqueti API.
  ///
  /// This class provides access to the top-level Aqueti API.  It wraps an
  /// aqt_API C structure and provides a C++ interface for it.
  /// The GetStatus() method should be called after each method (including
  /// the constructor) to make sure that the operation was a success.

  class AquetiAPI {
  public:
    /// @brief Connect to a root level Aqueti API object.
    ///
    /// Makes a connection to a root-level Aqueti API object.
    /// @param [in] user Name of the user who is requesting access.
    ///             Will use ANONYMOUS_USER if this is not specified.
    /// @param [in] credentials Binary credentials object for this user.
    ///             This is used to verify the user and provide appropriate access.
    ///             Will use NO_CREDENTIALS if this is not specified.
    /// @param [in] URLs A vector of Universal Resource Locators to try to locate
    ///             an API server.  Each is tried in turn and the first one that
    ///             points to a valid server will be used.  If the vector is empty,
    ///             the system will use autodetection to connect to the server.
    AquetiAPI(
      ::std::string user = ANONYMOUS_USER,
      ::std::vector<uint8_t> credentials = NO_CREDENTIALS,
      ::std::vector<::std::string> URLs = AUTODISCOVER_API);
    /// @brief Destroy the object, closing all API objects obtained from it.
    ~AquetiAPI();

    /// @brief Returns the status of the most-recent operation and clears error/warnings.
    ///
    /// This should be called after the construction of an AquetiAPI and after each method
    /// call that does not itself return an aqt_Status to ensure that the operation
    /// completed.
    /// @return aqt_Status returned by the most-recent operation on the wrapped
    ///         class, or other errors in case the Image itself is broken.
    aqt_Status GetStatus() const;

    /// @brief Return a vector of descriptions of available cameras.
    ::std::vector<SingleCOPCameraDescription> GetAvailableCameras() const;

    /// @brief Return a vector of descriptions of available renderers.
    ::std::vector<RendererDescription> GetAvailableRenderers() const;

    /// @brief Return a vector of descriptions of available DataRouters.
    ::std::vector<DataRouterDescription> GetAvailableDataRouters() const;

    /// @brief Return the current system time translated to local time.
    struct timeval GetCurrentSystemTime() const;

    /// @brief Exports the specified range of the specified data from the specified entity.
    /// @param outputURL Description of the file or other location to store the exported data to.
    /// @param format External format to use when storing the data.
    /// @param entityName Name of the entity whose data is to be exported.  Can be obtained with
    ///         aqt::AquetiAPI::GetAvailableCameras().  The character '*'
    ///         can be used to specify "any" for a portion of the name; just the name * will export
    ///         all entities to the file.
    /// @param [in] interval Range of time over which data should be exported.  To
    ///         export all time, set the start to 0 and the end to aqt_Interval_UNDEFINED_END.
    /// @param [in] types Vector of data types to be exported, or ALL_DATA_TYPES to
    ///         export all data types.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status ExportStoredDataRange(::std::string outputURL, aqt_ExternalDataFormat format,
      ::std::string entityName, aqt::Interval interval,
      std::vector<aqt_DataType> types = ALL_DATA_TYPES);

    /// @brief Imports the specified range of the specified data from the specified entity.
    /// @param inputURL Description of the file or other location to read the imported data from.
    /// @param format External format to use when storing the data.
    /// @param entityName Name of the entity whose data is to be imported.  The character '*'
    ///         can be used to specify "any" for a portion of the name; just the name * will import
    ///         all entities from the file.
    /// @param [in] interval Range of time over which data should be imported.  To
    ///         import all time, set the start to 0 and the end to aqt_Interval_UNDEFINED_END.
    /// @param [in] types Vector of data types to be imported, or ALL_DATA_TYPES to
    ///         import all data types.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status ImportStoredDataRange(::std::string inputURL, aqt_ExternalDataFormat format,
      ::std::string entityName, aqt::Interval interval,
      std::vector<aqt_DataType> types = ALL_DATA_TYPES);

    /// @brief Return detailed status on a system entity.
    /// @param [in] entityName String name of an entity in the system.  This can
    ///        be obtained using the Name() method on SingleCOPCameraDescription or
    ///        RendererDescription or DataRouterDescription objects, or from
    ///        aqt::render::RenderStream::GetSourcesPotentiallyVisibleAtLocation()
    ///        or potentially from detailed status on another entity.  The name
    ///        "/aqt" will return the name and status of the server itself.
    /// @return JSON-formatted detailed status information on the entity whose name is passed in.
    /// This may be a camera, renderer, DataRouter, or other system entity.
    ::std::string GetDetailedStatus(::std::string entityName);

    /// @brief Return the current parameter settings for a system entity.
    /// @param [in] entityName String name of an entity in the system.  This can
    ///        be obtained using the Name() method on SingleCOPCameraDescription or
    ///        RendererDescription or DataRouterDescription objects, or from
    ///        aqt::render::RenderStream::GetSourcesPotentiallyVisibleAtLocation()
    ///        or potentially from detailed status on another entity.  The name
    ///        "/aqt" will return the name and parameters of the server itself.
    /// @return JSON-formatted parameter settings for the entity whose name is passed in.
    /// This may be a camera, renderer, DataRouter, or other system entity.
    ::std::string GetParameters(::std::string entityName);

    /// @brief Set parameters on a system entity.
    /// @param [in] entityName String name of an entity in the system.  This can
    ///        be obtained using the Name() method on SingleCOPCameraDescription or
    ///        RendererDescription or DataRouterDescription objects, or from
    ///        aqt::render::RenderStream::GetSourcesPotentiallyVisibleAtLocation()
    ///        or potentially from detailed status on another entity.  The name
    ///        "/aqt" will return the name and parameters of the server itself.
    /// @param [in] JSONParameters JSON-format description of the parameters to set
    ///        on an entity and their new values.  A list of available parameters can
    ///        be obtained by calling GetParameters() on the same entity.  The parameters
    ///        being set can be a subset of those that could be set; others are left
    ///        unchanged unless those set adjust others as a side effect.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status SetParameters(::std::string entityName, ::std::string JSONParameters);

    /// @brief Get the external Network Time Protocol server for the system.
    /// @return URL for the NTP server currently being used.
    ::std::string ExternalNTPServerName();
    /// @brief Set the external Network Time Protocol server for the system.
    /// @param [in] serverName URL for the NTP server to use.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status ExternalNTPServerName(::std::string serverName);

    /// @brief Get string associated with a user-defined string.
    ///
    /// The API provides an internal database that maps user-supplied strings
    /// to other user-supplied strings.  This can be used to provide "nicknames"
    /// or aliases to devices in the system, which can help a user interface
    /// provide short, memorable names for them.  For example, by mapping the
    /// camera name returned by GetAvailableCameras()[0].Name() to "Front door",
    /// the system can provide a user-meaningful name.
    ///
    /// The UserData() method with a second argument will associated an alias
    /// which the UserData() method without a second argument will later
    /// return.
    /// @param [in] baseName The base name whose alias should be returned.
    /// @return The string associated with the specified base name, or an empty
    ///         string if no association has been made.  If there is no association,
    ///         GetStatus() after this call will report an error, but if there is
    ///         an empty string association it will return aqt_STATUS_OKAY.
    ::std::string UserData(::std::string baseName);

    /// @brief Set string associated with a user-defined string.
    ///
    /// The API provides an internal database that maps user-supplied strings
    /// to other user-supplied strings.  This can be used to provide "nicknames"
    /// or aliases to devices in the system, which can help a user interface
    /// provide short, memorable names for them.  For example, by mapping the
    /// camera name returned by GetAvailableCameras()[0].Name() to "Front door",
    /// the system can provide a user-meaningful name.
    ///
    /// The UserData() method with a second argument will associated an alias
    /// which the UserData() method without a second argument will later
    /// return.
    /// @param [in] baseName Base name whose alias should be set.
    /// @param [in] userData The string to be associated or an empty string to
    ///        remove any association.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status UserData(::std::string baseName, ::std::string userData);

    /// @brief Adds a data reservation to the system.
    ///
    /// This adds a new reservation to the system, which describes how long to keep data
    /// in a specified range from a specified entity.  It also associates a user and other
    /// data with the reservation.
    /// @param [in] reservation Information about the reservation to add.
    /// @return The ID of the reservation on success, aqt_ReservationID_INVALID on failure.
    std::string AddReservation(ReservationInfo reservation);

    /// @brief Retrieves the IDs for data reservations in the system.
    /// @param [in] searchParams Parameters used to restrict the search results to a desired
    ///        subset of the reservations.  Fill in non-default entries for each field in the
    ///        structure passed on to restrict to reservations with that value.  Any field that
    ///        is left at the default value will not restrict the search.  An unrestricted search
    ///        will result in all reservations in the system being returned.
    /// @return A vector of IDs, one for each reservation that is found.
    ::std::vector<std::string> GetReservationIDs(ReservationInfo searchParams =
      ReservationInfo());

    /// @brief Retrieves reservation information associated with the specified ID.
    ///
    /// This uses a reservation ID obtained either by AddReservation() or
    /// by GetReservationIDs() to find the associated ReservationInfo.
    /// @param [in] ID Identifier to look up.
    /// @return The information associated with that ID on success, undefined on
    ///        failure.
    ReservationInfo GetReservationInfo(std::string ID);

    /// @brief Replaces a data reservation to the system.
    ///
    /// This replaces an existing reservation to the system, which describes how long to keep data
    /// in a specified range from a specified entity.  It also associates new user and other
    /// data with the reservation.
    /// @param [in] ID Identifier of the reservation to replace.
    /// @param [in] reservation Information about the reservation to add.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status ReplaceReservation(std::string ID, ReservationInfo reservation);

    /// @brief Cancel the reservation associated with the specified ID.
    ///
    /// This uses a reservation ID obtained either by APIAddReservation() or
    /// by APIGetReservationIDs() to find the associated reservation, which
    /// is then removed from the system.  This reduces the reference count on any
    /// reserved data, possibly making it available for deletion.
    /// @param [in] ID Identifier of the reservation to cancel.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status CancelReservation(std::string ID);

    /// @todo Implement the methods declared below here that are in comments.
    // aqt_Status Restart(::std::string entityName);

    // aqt_Status GetLog(std::string &ReturnString, ::std::string entityName, bool clear = false);

    // SingleCOPCameraDescription CreateNewCamera(const std::string &JSONInfo);

    // RendererDescription CreateNewRenderer(const std::string &JSONInfo);

    /// @todo This will probably not be implemented as a general "run this task"
    /// interface.  We'd either have specific calls that can be parameterized or
    /// else a general API for running your own tasks inside the system, like
    /// the aqt_Embed library.
    // aqt_Status SetScheduledTaskPeriod(ScheduledTask task, struct timeval first_time,
    //    struct timeval period, std::vector<::std::string> cameraNames);

    // Send this generic parameters, with the intrinsic and extrinsic bool being the
    // first two.  The string of cameras is so that you can build an extrinsic model
    // across all of them.
    // aqt_status GenerateModel(std::vector<::std::string> cameras,
    //    bool intrinsic = true, bool extrinsic = false);

    /// @brief Callback handler type declaration for returning log messages.
    typedef void(*LogMessageCallback)(Message &message, void *userData);

    /// @brief Sets up a handler to be called as log messages come in when enabled.
    ///
    /// This method should be called before SetLogMessageStreamingState() is called to start streaming.
    /// Either this method or GetPendingLogMessages() should be used to retrieve messages; if this
    /// method is used, GetPendingLogMessages() will always return nothing.
    /// @param [in] callback Function pointer to the function that is to be called to
    ///        handle each message as it comes in when streaming is started.  Set to nullptr
    ///        to disable handling streaming messages.  The function must be able to handle
    ///        messages at full rate to avoid filling up memory as un-handled messages queue.
    /// @param [in] userData Pointer that will be passed into the callback handler along with
    ///        each message.  Often type-cast into a class or structure pointer to let the
    ///        handler know what it should do with each frame.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status SetLogMessageCallback(LogMessageCallback callback,
        void *userData = nullptr);

    /// @brief Turns delivery of log messages on or off.
    ///
    /// The API is not initially sending messages.  Call this
    /// function with true to turn on delivery.
    /// @param [in] running Set to true to start streaming, false to stop streaming.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status SetLogMessageStreamingState(bool running = true);

    /// @brief Reads the next-available log message queued by streaming.
    ///
    /// This method should be called after SetLogMessageStreamingState() is called to start streaming.
    /// Either this method or SetLogMessageCallback() should be used to retrieve messages; if
    /// SetLogMessageCallback() method is used, GetPendingLogMessages() will always return nothing.
    /// @param maxNum Maximum number of messages to return, default is 0 for unlimited.
    /// @return Retrieves all currently available queued messages or an empty vector
    ///         if none are available.
    std::vector<Message> GetPendingLogMessages(size_t maxNum = 0);

    /// @brief Sets the range of message levels to be returned.
    ///
    /// This method filters log messages so that only those of sufficient urgency
    /// are returned.  It should be called before streaming is enabled.
    /// @param level Minimum level to be returned, defaults to aqt_MESSAGE_MINIMUM_INFO.
    /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
    ///         GetStatus() should not be called after this method, since it is returned here.
    aqt_Status SetLogMessageMinimumLevel(aqt_MessageLevel level);

    /// @brief Creates a file containing an issue report including system state.
    ///
    /// This will create a file containing a complete description of the state
    /// of every device in the system along with a user-supplied summary and
    /// user-supplied description.  This file is intended to be sent to Aqueti
    /// as an error report, with the information aiding in the debugging of the
    /// problem.  **This function may take a long time to complete.**
    /// Optional arguments enable specifying a subset of the available
    /// information.
    /// @param [in] fileNameToWrite Path and name to the file to write the
    ///        information to.  This should be a name on the client computer.
    /// @param [in] summary Summary information to be included in the report.
    /// @param [in] description Detailed description of the issue to be included
    ///        in the report.
    /// @cond IGNORE_FOR_NOW
    /// @param [in] entityName Name of the entity for which logs should be retrieved;
    ///        defaults to all entities in the system.
    /// @param [in] messageLevel Minimum level of the message that will be reported.
    /// @param [in] interval Pointer to an interval of time whose messages will be
    ///        included.  Defaults to recent messages in the system, where the duration
    ///        of recent is determined by the system.
    /// @endcond IGNORE_FOR_NOW
    /// @return Returns aqt_STATUS_OKAY on success and a specific code on failure.
    ///         GetStatus() does not need to be called after this method because it
    ///         is returned here.
    aqt_Status CreateIssueReport(const std::string &fileNameToWrite,
       const std::string &summary, const std::string &description
      //, const std::string entityName = "", aqt_MessageLevel messageLevel = aqt_MESSAGE_MINIMUM_INFO,
      // aqt::Interval *interval = nullptr
    );

    /// @brief Private class declared for definition and use by the API implementation.
    class AquetiAPI_private;

  protected:
    /// @brief Protected method for use by the API implementation.
    aqt_API GetRawAPI() const;

    // Share our protected information with classes that make use of us.
    /// @cond INTERNAL
    friend render::RenderStream;
    friend render::TimeState;
    friend render::ViewState;
    friend render::PoseState;
    friend render::ImageSubsetState;
    friend camera::Camera;
    friend update::Update;
    friend externalAnalysis::ExternalAnalysis;
    /// @endcond

  private:
    AquetiAPI_private *m_private = nullptr;
  };

  // aqt::render namespace.
  namespace render {

    // Constants used below.
    static ::std::string NOT_SHARED;  ///< Object is not shared between programs

    /// @brief Holds the data for a viewing state, which drives a virtual camera.
    ///
    /// This class controls and reports a viewing state.  It wraps an
    /// aqt_RenderViewState C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// A viewing state stores the pan, tilt and zoom of the camera, along with
    /// the rate of change of each of these over time.  It also includes maximum
    /// ranges for these (which clamp the the parameters) and holds the horizontal
    /// and vertical fields of view of a virtual camera.

    class ViewState {
    public:

      /// @brief Creates a ViewState object or looks up an existing one.
      ///
      /// The default field of view for the camera is 90 horizontal and 50 vertical.
      /// The default pan and tilt are 0, with the default zoom being 1.
      /// If the ViewState is to be shared between objects, it must be given the same
      /// (non-empty) name by each.  The first object must create it by setting
      /// alreadyExists to false and the second and later must retrieve it by setting
      /// alreadyExists() to true.
      /// @param [in] api AquetiAPI object that the ViewState lives inside.
      /// @param [in] name NOT_SHARED if there is to be only one user, an non-empty
      ///        string if it is to be shared.
      /// @param [in] alreadyExists Set to true if the ViewState has already been created by
      ///        another object and we want a reference to it.
      ViewState(AquetiAPI &api, ::std::string name = NOT_SHARED, bool alreadyExists = false);

      /// @brief Destroys a ViewState object or a reference to a shared object.
      ~ViewState();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a ViewState and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Get the pan for the virtual camera at the present time.
      ///
      /// Pan of 0 is straight ahead, with positive pans towards the right.
      double PanDegrees();
      /// @brief Set the current pan.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status PanDegrees(double newVal);
      /// @brief Return the minimum pan in degrees, where 0 is facing forward and positive
      ///        values go to the right.
      double MinPanDegrees();
      /// @brief Set the minimum pan.  Setting min and max to -180 and 180 allows all pans.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MinPanDegrees(double newVal);
      /// @brief Return the maximum pan in degrees, where 0 is facing forward and positive
      ///        values go up.
      double MaxPanDegrees();
      /// @brief Set the maximum pan.  Setting min and max to -180 and 180 allows all pans.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MaxPanDegrees(double newVal);
      /// @brief Get the pan speed for the virtual camera in degrees/second.
      double PanSpeedDegrees();
      /// @brief Set the pan speed for the virtual camera in degrees/second.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status PanSpeedDegrees(double newVal);

      /// @brief Get the tilt for the virtual camera at the present time.
      ///
      /// Tilt of 0 is straight ahead, with positive tilts up.
      double TiltDegrees();
      /// @brief Set the current tilt.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status TiltDegrees(double newVal);
      /// @brief Return the minimum tilt in degrees, where 0 is facing forward and positive
      ///        values go up.
      double MinTiltDegrees();
      /// @brief Set the minimum tilt.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MinTiltDegrees(double newVal);
      /// @brief Return the maximum tilt in degrees, where 0 is facing forward and positive
      ///        values go up.
      double MaxTiltDegrees();
      /// @brief Set the maximum tilt.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MaxTiltDegrees(double newVal);
      /// @brief Get the tilt speed for the virtual camera in degrees/second.
      double TiltSpeedDegrees();
      /// @brief Set the tilt speed for the virtual camera in degrees/second.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status TiltSpeedDegrees(double newVal);

      /// @brief Get the zoom for the virtual camera at the present time.
      ///
      /// Zoom of 1 is the default zoom, with higher zooms making pixels in the
      /// image appear larger and smaller zooms making them appear smaller.  For
      /// perspective planar projections, the pixel size is the specified multiple of
      /// the original (zoom=1) size.  Other projection models have different results.
      double Zoom();
      /// @brief Set the current zoom.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Zoom(double newVal);
      /// @brief Return the minimum zoom factor.
      double MinZoom();
      /// @brief Set the maximum zoom.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MinZoom(double newVal);
      /// @brief Return the maximum zoom factor.
      double MaxZoom();
      /// @brief Set the maximum zoom.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MaxZoom(double newVal);
      /// @brief Get the zoom speed for the virtual camera in factors/second.
      double ZoomSpeed();
      /// @brief Set the zoom speed for the virtual camera in factors/second.
      /// @param newVal Factor to change by each second; a value of 2 doubles the
      ///        image size each second, a factor of 0.5 halves it each second, and
      ///        a value of 1 leaves it the same.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status ZoomSpeed(double newVal);

      /// @brief Get the horizontal field of view in degrees for the virtual camera.
      double HorizontalFOVDegrees();
      /// @brief Set the horizontal field of view in degrees for the virtual camera.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status HorizontalFOVDegrees(double newVal);

      /// @brief Get the vertical field of view in degrees for the virtual camera.
      double VerticalFOVDegrees();
      /// @brief Set the vertical field of view in degrees for the virtual camera.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status VerticalFOVDegrees(double newVal);

      /// @brief Private class declared for definition and use by the API implementation.
      class ViewState_private;

    protected:
      /// @brief Protected method for use by the API implementation.
      aqt_RenderViewState GetRawState();
      /// @cond INTERNAL
      friend RenderStream;
      /// @endcond

    private:
      ViewState_private *m_private = nullptr;
    };

    /// @brief Holds the data for a time state, which drives a virtual camera.
    ///
    /// This class controls and reports a time state.  It wraps an
    /// aqt_RenderTimeState C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// A time state stores the time and play speed of the camera.

    class TimeState {
    public:

      /// @brief Creates a TimeState object or looks up an existing one.
      ///
      /// The default time for the camera is 1 second behind the current time
      /// and the default play rate is 1 (plays forward at 1x real time).
      /// If the TimeState is to be shared between objects, it must be given the same
      /// (non-empty) name by each.  The first object must create it by setting
      /// alreadyExists to false and the second and later must retrieve it by setting
      /// alreadyExists() to true.
      /// @param [in] api AquetiAPI object that the TimeState lives inside.
      /// @param [in] name NOT_SHARED if there is to be only one user, an non-empty
      ///        string if it is to be shared.
      /// @param [in] alreadyExists Set to true if the TimeState has already been created by
      ///        another object and we want a reference to it.
      TimeState(AquetiAPI &api, ::std::string name = NOT_SHARED, bool alreadyExists = false);

      /// @brief Destroys a TimeState object or a reference to a shared object.
      ~TimeState();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a TimeState and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Get the time being shown by the virtual camera at the present time.
      struct timeval Time();

      /// @brief Set the time being shown by the virtual camera at the present time.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval time);

      /// @brief Get the play rate for the virtual camera at the present time.
      /// The default is 1.  2x playback is 2, half-speed playback is 0.5.
      double PlaySpeed();

      /// @brief Set the play rate for the virtual camera at the present time.
      /// The default is 1.  2x playback is 2, half-speed playback is 0.5.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status PlaySpeed(double speed);

      /// @brief Private class declared for definition and use by the API implementation.
      class TimeState_private;

    protected:
      /// @brief Protected method for use by the API implementation.
      aqt_RenderTimeState GetRawState();
      /// @cond INTERNAL
      friend RenderStream;
      /// @endcond

    private:
      TimeState_private *m_private = nullptr;
    };

    /// @brief Holds the data for a pose state, which drives a virtual camera.
    ///
    /// This class controls and reports a pose state.  It wraps an
    /// aqt_RenderPoseState C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// A pose state stores the location and orientation of the virtual camera in a
    /// planet-centered coordinate system. The position is stored as latitude (fractional
    /// degrees), longitude (fractional degrees), and altitude (meters above sea level).
    /// The orientation is the yaw (rotation about Z, applied
    /// first), pitch (rotation about Y, applied second), and roll (rotation about X,
    /// applied last) with respect to a right-handed coordinate system describing a
    /// camera whose principal ray is pointing up along -Z and whose X axis (towards the
    /// right in the image) is pointing East, and whose Y axis (from the bottom of the
    /// image towards the top) is pointing North; the Yaw, Pitch, and Roll describe how
    /// to rotate this canonical camera to point in the direction of the actual camera.

    class PoseState {
    public:

      /// @brief Creates a PoseState object or looks up an existing one.
      ///
      /// The default pose is located at (0,0,0) with orientation (0,0,0).
      /// If the PoseState is to be shared between objects, it must be given the same
      /// (non-empty) name by each.  The first object must create it by setting
      /// alreadyExists to false and the second and later must retrieve it by setting
      /// alreadyExists() to true.
      /// @param [in] api AquetiAPI object that the PoseState lives inside.
      /// @param [in] name NOT_SHARED if there is to be only one user, an non-empty
      ///        string if it is to be shared.
      /// @param [in] alreadyExists Set to true if the PoseState has already been created by
      ///        another object and we want a reference to it.
      PoseState(AquetiAPI &api, ::std::string name = NOT_SHARED, bool alreadyExists = false);

      /// @brief Destroys a PoseState object or a reference to a shared object.
      ~PoseState();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a PoseState and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Get the latitude for the virtual camera at the present time.
      double Latitude();
      /// @brief Set the current latitude in fractional degrees.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Latitude(double val);

      /// @brief Get the longitude for the virtual camera at the present time.
      double Longitude();
      /// @brief Set the current longitude in fractional degrees.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Longitude(double val);

      /// @brief Get the altitude for the virtual camera at the present time.
      double Altitude();
      /// @brief Set the current altitude in meters above sea level.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Altitude(double val);

      /// @brief Get the roll for the virtual camera at the present time.
      double Roll();
      /// @brief Set the current roll (rotation about X, applied last).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Roll(double val);

      /// @brief Get the pitch for the virtual camera at the present time.
      double Pitch();
      /// @brief Set the current pitch (rotation about Y, applied second).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Pitch(double val);

      /// @brief Get the yaw for the virtual camera at the present time.
      double Yaw();
      /// @brief Set the current yaw (rotation about Z, applied first).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Yaw(double val);

      /// @brief Private class declared for definition and use by the API implementation.
      class PoseState_private;

    protected:
      /// @brief Protected method for use by the API implementation.
      aqt_RenderPoseState GetRawState();
      /// @cond INTERNAL
      friend RenderStream;
      /// @endcond

    private:
      PoseState_private *m_private = nullptr;
    };

    /// @brief Holds the data for an image subset state, which drives a virtual camera.
    ///
    /// This class controls and reports an image subset state.  It wraps an
    /// aqt_RenderImageSubsetState C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// An image subset state stores the fraction of the total view frustum that is
    /// being rendered.  It is used to support tiled rendering, where different render
    /// streams provide the outputs for a set of tiled displays but they are all
    /// controlled by the same view and time states.  The subset is a fraction of the
    /// total frustum, which can be used to skip spaces taken up by monitor frames to
    /// provide gaps in the overall view that matches the gaps caused by the frames.
    /// The range in X goes from 0 at the left side of the frustum to 1 at the right.
    /// The range in Y goes from 0 at the top of the frustum to 1 at the bottom.
    /// The default range in both X and Y goes from 0 to 1.

    class ImageSubsetState {
    public:

      /// @brief Creates an ImageSubsetState object or looks up an existing one.
      ///
      /// The default subset is the full frustum: (0,1) in both X and Y.
      /// If the ImageSubsetState is to be shared between objects, it must be given the same
      /// (non-empty) name by each.  The first object must create it by setting
      /// alreadyExists to false and the second and later must retrieve it by setting
      /// alreadyExists() to true.
      /// @param [in] api AquetiAPI object that the ImageSubsetState lives inside.
      /// @param [in] name NOT_SHARED if there is to be only one user, an non-empty
      ///        string if it is to be shared.
      /// @param [in] alreadyExists Set to true if the ImageSubsetState has already been created by
      ///        another object and we want a reference to it.
      ImageSubsetState(AquetiAPI &api, ::std::string name = NOT_SHARED, bool alreadyExists = false);

      /// @brief Destroys an ImageSubsetState object or a reference to a shared object.
      ~ImageSubsetState();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of an ImageSubsetState and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Get the minimum X for the virtual camera (0 = left, 1 = right).
      double MinX();
      /// @brief Set the minimum X for the virtual camera (0 = left, 1 = right).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MinX(double val);
      /// @brief Get the maximum X for the virtual camera (0 = left, 1 = right).
      double MaxX();
      /// @brief Set the maximum X for the virtual camera (0 = left, 1 = right).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MaxX(double val);
      /// @brief Get the minimum Y for the virtual camera (0 = top, 1 = bottom).
      double MinY();
      /// @brief Set the minimum Y for the virtual camera (0 = top, 1 = bottom).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MinY(double val);
      /// @brief Get the maximum Y for the virtual camera (0 = top, 1 = bottom).
      double MaxY();
      /// @brief Set the maximum Y for the virtual camera (0 = top, 1 = bottom).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status MaxY(double val);

      /// @brief Private class declared for definition and use by the API implementation.
      class ImageSubsetState_private;

    protected:
      /// @brief Protected method for use by the API implementation.
      std::shared_ptr<aqt_RenderImageSubsetState_> GetRawState();
      /// @cond INTERNAL
      friend RenderStream;
      /// @endcond

    private:
      std::shared_ptr<ImageSubsetState_private> m_private;
    };

    /// @brief Holds the data for a rendered frame, which comes from a RenderStream.
    ///
    /// This class holds information about a rendered frame.  It wraps an
    /// aqt_RenderFrame C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// A render frame holds frame metadata (width, height, type, and time)
    /// along with accessors to retrieve and release the actual data.  It also
    /// provides access to the state of the virtual camera at the time the
    /// image was taken (pan, tilt, zoom, HFOV, VFOV, and image-subset MinX,
    /// MaxX, MinY and MaxY)

    class RenderFrame {
    public:
      /// @brief Default constructor for a RenderFrame, not usually needed by client code.
      RenderFrame();
      /// @brief Copy constructor for a RenderFrame, not usually needed by client code.
      /// @param [in] frame Frame to reference.  This performs a deep copy of the frame, but
      ///        not of the data that the frame references.  This is done to avoid
      ///        double deletion.
      RenderFrame(aqt_RenderFrame frame);
      /// @brief Destructor for a RenderFrame, which does not release the data.
      ///
      /// ReleaseData() must be called at least once on each frame returned from a
      /// RenderStream to avoid leaking memory.  The destructor does not call it, to
      /// avoid prematurely releasing the memory during assignment and construction.
      ~RenderFrame();

      /// @brief Copy constructor for a RenderFrame, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the frame, but
      ///        not of the data that the frame references.  This is done to avoid
      ///        double deletion.
      RenderFrame(const RenderFrame& copy);
      /// @brief Assignment for a RenderFrame, not usually needed by client code.
      /// @param [in] copy RenderFrame to copy.  This performs a deep copy of the frame, but
      ///        not of the data that the frame references.  This is done to avoid
      ///        double deletion.
      RenderFrame &operator = (const RenderFrame &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a RenderFrame and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the width in pixels of the frame.
      uint32_t Width() const;
      /// @brief Get the height in pixels of the frame.
      uint32_t Height() const;
      /// @brief Get the type of the frame.
      aqt_ImageType Type() const;

      /// @brief Get the time associated with the data used to render the frame.
      ///
      /// The Time() method returns the "camera time" of the image, what time the
      /// frames were aquired that were used to render; this tells when the video
      /// frame was acquired.  The RenderStartTime() method returns the wall-clock
      /// time that the renderer started to do the actual rendering; it can be used
      /// to decide how fast to play back frames.
      struct timeval Time() const;

      /// @brief Pointer to the data for the frame.
      ///
      /// The data is valid only until ReleaseData() has been called for the first time
      /// on a given frame.
      const uint8_t *Data() const;
      /// @brief Size of the data for the frame.
      uint32_t Size() const;

      /// @brief Release the data associated with a frame.
      ///
      /// This calls the underlying API callback function to free the data pointed
      /// to by a frame.  If copies are made of a RenderFrame, they all point to
      /// the same underlying data.  If ReleaseData() is called on one of them, the
      /// data is released for all of them and continued access produces undefined
      /// results (which may include crashing).  This method must be called at least
      /// once on each frame that is returned from a RenderStream to avoid leaking
      /// memory.  It is not called in the destructor.
      void ReleaseData();

      /// @brief Get the pan value for the virtual camera at the time the frame was rendered.
      double Pan() const;
      /// @brief Get the tilt value for the virtual camera at the time the frame was rendered.
      double Tilt() const;
      /// @brief Get the zoom value for the virtual camera at the time the frame was rendered.
      double Zoom() const;
      /// @brief Get the horizontal field of view at the time the frame was rendered.
      double HFOV() const;
      /// @brief Get the vertical field of view at the time the frame was rendered.
      double VFOV() const;
      /// @brief Get the image subset MinX for the virtual camera at the time the frame was rendered.
      double SubsetMinX() const;
      /// @brief Get the image subset MaxX for the virtual camera at the time the frame was rendered.
      double SubsetMaxX() const;
      /// @brief Get the image subset MinY for the virtual camera at the time the frame was rendered.
      double SubsetMinY() const;
      /// @brief Get the image subset MaxY for the virtual camera at the time the frame was rendered.
      double SubsetMaxY() const;
      
      /// @brief Get the time that the virtual camera rendered the frame.
      ///
      /// The Time() method returns the "camera time" of the image, what time the
      /// frames were aquired that were used to render; this tells when the video
      /// frame was acquired.  The RenderStartTime() method returns the wall-clock
      /// time that the renderer started to do the actual rendering; it can be used
      /// to decide how fast to play back frames.
      struct timeval RenderStartTime() const;

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_RenderFrame const RawFrame() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class RenderFrame_private;

    private:
      RenderFrame_private *m_private = nullptr;
    };

    /// @brief Stores the valid range for a floating-point parameter in a RenderStream.
    class FloatParameterRange {
    public:
      float minVal; ///< Minimum value of the parameter.
      float maxVal; ///< Maximum value of the parameter.
    };

    /// @brief Callback handler type declaration for returning RenderFrames from a RenderStream.
    ///
    /// The callback handler must call ReleaseData() on each frame it receives to avoid
    /// leaking memory.  It can queue frames for processing by other threads, but then these
    /// threads must call ReleaseData() on one of the copies of the frames.
    typedef void (*StreamCallback)(RenderFrame &frame, void *userData);

    /// @brief Holds the data and methods for controlling a RenderStream.
    ///
    /// This class controls and reports a render stream.  It wraps an
    /// aqt_RenderStream C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// The RenderStream class controls the playback of video streams from
    /// one or more aqt::camera::Camera objects.  The playback is controlled
    /// by ViewState, TimeState, ImageSubsetState, and PoseState objects that
    /// are separately constructed and which can be shared between streams
    /// (for example, to do tiled displays or to synchronize times between a
    /// number of independent views).
    class RenderStream {
    public:

      /// @brief Creates a RenderStream object and specifies its characteristics and controls.
      ///
      /// The default stream starts with no cameras defined and with streaming turned off.
      /// Call SetStreamCallback() to point to a function to handle incoming frames before
      /// turning streaming on, or else call GetNextFrame() repeatedly after streaming has
      /// been turned on to retrieve the frames.
      /// Call AddCamera() and then SetStreamingState() to begin getting frames.
      /// @param [in] api AquetiAPI object that the RenderStream lives inside.
      /// @param [in] viewState Used to control the field of view and viewing direction.
      ///        This object may unique to this stream or may be shared between multiple
      ///        RenderStream objects to coordinate them.
      /// @param [in] timeState Used to control the time and rate of playback (pause, play, etc.).
      ///        This object may unique to this stream or may be shared between multiple
      ///        RenderStream objects to coordinate them.
      /// @param [in] imageSubsetState Used to control the fraction of the view frustum.
      ///        This object may unique to this stream or may be shared between multiple
      ///        RenderStream objects to coordinate them.
      /// @param [in] poseState Used to control the extrinsic location and orientation of the camera.
      ///        This object may unique to this stream or may be shared between multiple
      ///        RenderStream objects to coordinate them.
      /// @param [in] props Used to control the stream properties (width and height, encoding
      ///        type, frame rate, encoding quality, etc.
      /// @param [in] renderer Entity name of the Renderer (available by calling
      ///        aqt::AquetiAPI::GetAvailableRenderers(); defaults to any available renderer.
      ///        This should be specified for tiled displays but not for standard streams.
      /// @param [in] projectionType Specifies the type of projection, aqt_RPT_PERSPECTIVE
      ///        by default or aqt_RPT_ORTHOGRAPHIC.
      /// @param [in] projectionManifold Describes the surface on which the projection happens.
      ///        Default is aqt_RPM_CYLINDER (best for wide-field-of-view cameras) with
      ///        aqt_RPM_PLANE as an option that reduces cropping on narrow-FOV cameras.
      /// @param [in] letterBoxEnabled Enable (if true) or disable (if false) letter-box
      ///        cropping of the window so that only a rectangular region is shown and that
      ///        rectangular region is within the ones where high-resolution data is available.
      ///        Default is true.
      /// @param [in] letterBoxApproach If letterBoxEnabled is true, selects which approach is
      ///        chosen to do cropping.  Default is aqt_LB_CHECK_8_POINTS_PER_MICROCAMERA.
      RenderStream(
        AquetiAPI &api,
        ViewState &viewState,
        TimeState &timeState,
        ImageSubsetState &imageSubsetState,
        PoseState &poseState,
        StreamProperties &props,
        ::std::string renderer = ANY_RENDERER,
        aqt_RenderProjectionType projectionType = aqt_RPT_PERSPECTIVE,
        aqt_RenderProjectionManifold projectionManifold = aqt_RPM_CYLINDER,
        bool letterBoxEnabled = true,
        aqt_LetterBoxApproaches letterBoxApproach = aqt_LB_CHECK_8_POINTS_PER_MICROCAMERA
      );

      /// @brief Destroys a RenderStream, also removes all remaining cameras and clears callback.
      ~RenderStream();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a RenderStream and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Adds a camera to those potentially visible in the RenderStream.
      ///
      /// This must be called before anything will be visible in the stream, and it
      /// should be called before SetStreamingState() is called to start streaming.
      /// When the default pose is used, it will usually be the case that only a single
      /// camera is added; providing a pose and using cameras that have extrinsic
      /// parameters will enable flying around in a 3D scene with multiple cameras.
      /// @param [in] cameraName Name of the camera to add (can be obtained by calling
      ///        aqt::AquetiAPI::GetAvailableCameras()).
      /// @param [in] intrinsicIndex Index of the set of intrinsic parameters to use
      ///        for the camera, by default 0 (the first one).  This can be used to
      ///        select views that are restricted to the high-resolution region of the
      ///        camera or views that can see all of the available pixels in the
      ///        wide-field-of-view cameras.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status AddCamera(::std::string cameraName, uint32_t intrinsicIndex = 0);

      /// @brief Removes a camera to those potentially visible in the RenderStream.
      /// @param [in] cameraName Name of the camera to remove (must match one that has
      ///        previously been added).
      /// @param [in] intrinsicIndex Index of the set of intrinsic parameters to use
      ///        for the camera, must match one that has previously been added).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status RemoveCamera(::std::string cameraName, uint32_t intrinsicIndex = 0);

      /// @brief Sets up a handler to be called as frames come in once streaming.
      ///
      /// This method should be called before SetStreamingState() is called to start streaming.
      /// Either this method or GetNextFrame() should be used to retrieve images; if this
      /// method is used, GetNextFrame() will always return empty frames.
      /// @param [in] callback Function pointer to the function that is to be called to
      ///        handle each frame as it comes in when streaming is started.  Set to nullptr
      ///        to disable handling streaming images.  The function must be able to handle
      ///        frames at full rate to avoid filling up memory as un-handled frames queue.
      ///        The callback handler must call ReleaseData() on each frame it receives to avoid
      ///        leaking memory.  It can queue frames for processing by other threads, but then these
      ///        threads must call ReleaseData() on one of the copies of the frames.
      /// @param [in] userData Pointer that will be passed into the callback handler along with
      ///        each frame.  Often type-cast into a class or structure pointer to let the
      ///        handler know what it should do with each frame.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetStreamCallback(StreamCallback callback, void *userData = nullptr);

      /// @brief Turns streaming on or off.
      ///
      /// The stream is not initially sending frames.  After AddCamera() has been called
      /// (and after a streaming callback has been added, if one is to be used), call this
      /// function with true to turn on streaming.
      /// @param [in] running Set to true to start streaming, false to stop streaming.
      ///       Note that pausing the video playback can be handled by setting the
      ///       TimeState play rate to 0, which will continue to stream frames but they will
      ///       all be from the same camera time (as if in super slow motion).  Pausing can also
      ///       be handled by calling SetStreamingState(false), but this will not change the
      ///       TimeState so the actual replay will resume at a different time.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetStreamingState(bool running = true);

      /// @brief Reads the next-available frame queued by streaming.
      ///
      /// This method should be called after SetStreamingState() is called to start streaming.
      /// Either this method or SetStreamCallback() should be used to retrieve images; if
      /// SetStreamCallback() method is used, GetNextFrame() will always return empty frames.
      /// @param [in] timeout How long to wait for a new frame, default returns immediately
      ///         if no frame is available.
      /// @return Retrieves the next available queued frame on the stream, or a frame
      ///         with empty data if none is available.  The receiver must call ReleaseData()
      ///         on any non-empty frame when it is done with it to avoid leaking memory.
      RenderFrame GetNextFrame(struct timeval timeout = {});

      /// @brief Determines the range of a floating-point shader parameter.
      ///
      /// Several floating-point parameters are used to control the visual properties
      /// of the rendered view (gain, offset, gamma, denoise pixel blur, and denoise
      /// brightness blur).  This method determines the allowed ranges for one of these
      /// parameters, to help user interfaces decide what ranges to display.
      /// @param [in] which Index of the parameter whose range is to be read.
      /// @param [out] range On success, filled in with the range for the parameter.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status GetFloatParameterRange(aqt_RenderFloatShaderParamType which,
        FloatParameterRange &range);

      /// @brief Reads current value of a floating-point shader parameter.
      ///
      /// Several floating-point parameters are used to control the visual properties
      /// of the rendered view (gain, offset, gamma, denoise pixel blur, and denoise
      /// brightness blur).  This method determines the current value for one of them.
      /// @param [in] which Index of the parameter whose value is to be read.
      /// @return On success, value of the parameter being read.
      float FloatParameter(aqt_RenderFloatShaderParamType which);

      /// @brief Sets current value of a floating-point shader parameter.
      ///
      /// Several floating-point parameters are used to control the visual properties
      /// of the rendered view (gain, offset, gamma, denoise pixel blur, and denoise
      /// brightness blur).  This method sets the current value for one of them.
      /// @param [in] which Index of the parameter whose range is to be read.
      /// @param [in] newVal New value to set the parameter to.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status FloatParameter(aqt_RenderFloatShaderParamType which, float newVal);

      /// @brief Reads current value of a Boolean shader parameter.
      ///
      /// A Boolean parameter controls rendering denoising, others may be added later.
      /// This method determines the current value for one of them.
      /// @param [in] which Index of the parameter whose value is to be read.
      /// @return On success, value of the parameter being read.
      bool BoolParameter(aqt_RenderBoolShaderParamType which);

      /// @brief Reads current value of a Boolean shader parameter.
      ///
      /// A Boolean parameter controls rendering denoising, others may be added later.
      /// This method sets the current value for one of them.
      /// @param [in] which Index of the parameter whose value is to be read.
      /// @param [in] newVal New value to set the parameter to.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status BoolParameter(aqt_RenderBoolShaderParamType which, bool newVal);

      /// @brief Restarts rendering after packet loss or other issue.
      ///
      /// This refreshes the rendering for the stream.  On H.264 and H.265 streams,
      /// this requests that the stream render an I frame as soon as possible (buffering
      /// may cause a several-frame delay).  On other streams, this currently has no effect.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Refresh();

      /// @brief Set the relative position and zoom based on a rectangle in image space.
      ///
      /// This changes the pan, tilt, and zoom based on a selected region on the image.
      /// The region is specified in normalized coordinates (0-1 on each axis).  It takes into
      /// account the projection manifold and projection type that is currently in use.
      /// @param [in] xCenter Center of the rectangle in X, 0 = image left, 1 = image right.
      /// @param [in] yCenter Center of the rectangle in Y, 0 = image top, 1 = image bottom.
      /// @param [in] halfWidth Size of the rectangle, 0.5 is same as original, 0.25 zooms in 2X.
      /// @return aqt_STATUS_OKAY on success, specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetViewBasedOnRectangle(double xCenter, double yCenter, double halfWidth);

      /// @brief Get the description (including the name) about the RenderStream.
      ///
      /// This returns the information needed to refer to the RenderStream in
      /// low-level API functions, such as GetDetailedStatus() and SetDetailedStatus().
      /// @return Structure containing the name and other information about the
      ///         RenderStream on success, default-constructed structure on failure.
      RenderStreamDescription GetInfo();

      /* // Render an overlay of some type (string, rectangle, triangle, circle, etc.)
      aqt_Status ConfigureOverlayDisplay(aqt_DataType dataType, bool enabled = true,
        ::std::string type = "*", std::string name = "*",
        aqt::OverlayParameters params = aqt::OverlayParameters());
        */

      /*
      ::std::vector<::std::string> GetSourcesPotentiallyVisibleAtLocation(
        float fracScreenX, float fracScreenY, const ViewState &view, const PoseState &pose);
        */

      /*
      aqt_Status AutoFocusAtLocation(
        float fracScreenX, float fracScreenY, const ViewState &view, const PoseState &pose);
        */

      /*
      aqt_Status ChangeFocusAtLocation(
        float fracScreenX, float fracScreenY, const ViewState &view, const PoseState &pose,
        double deltaFocus);
        */

      /// @brief Private class declared for definition and use by the API implementation.
      class RenderStream_private;

    private:
      RenderStream_private *m_private = nullptr;
    };

    //::std::vector<RenderStreamDescription> GetRenderStreams();
    //RenderStream *DuplicateRenderStream(const RenderStreamDescription &description);

    //aqt_Status SaveFrame(const RenderFrame &frame, ::std::string fileName);

  } // End render namespace

  // aqt::camera namespace.
  namespace camera {

    /// @brief Holds the data and methods for controlling a Camera.
    ///
    /// This class controls and reports a camera.  It wraps an
    /// aqt_Camera C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// Provides control over recording state, DataRouter used, and streaming
    /// mode for a camera.  Reports the available stored data ranges for the camera.
    class Camera {
    public:

      /// @brief Creates a Camera object.
      /// @param [in] api AquetiAPI object that the Camera lives inside.
      /// @param [in] name Name of the Camera to open, may be obtained by calling
      ///         aqt::AquetiAPI::GetAvailableCameras().
      Camera(AquetiAPI &api, ::std::string name);

      /// @brief Destroys a Camera.
      ~Camera();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a Camera and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Returns whether the camera is currently recording.
      /// @return true if the camera is recording, false if it is not.
      bool IsRecording();

      /// @brief Start recording on the camera.
      /// @param [in] policy Reservation policy to use, which tells when the recording
      ///        can be deleted.  The default is the special value
      ///        aqt_RESERVATION_POLICY_USE_SYSTEM_DEFAULT that causes the system to use
      ///        its current default policy.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status StartRecording(ReservationPolicy policy = aqt_RESERVATION_POLICY_USE_SYSTEM_DEFAULT);

      /// @brief Stops recording on the camera.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status StopRecording();

      /// @brief Gets the name of the DataRouter that the camera records to.
      ///
      /// If the camera is not associated with a DataRouter, the name will be empty.
      /// If there is a problem, status will be set to not okay and the name will be empty.
      /// @return The name of the DataRouter.
      ::std::string GetDataRouter();

      /// @brief Sets the DataRouter that the camera will record to when it is recording.
      /// @param dataRouterName Name of the DataRouter the camera is to used.  Can be obtained with
      ///         aqt::AquetiAPI::GetAvailableDataRouters().
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status  SetDataRouter(::std::string dataRouterName);

      /// @brief Returns whether the camera is able to stream live now.
      /// @return true if the camera is able to stream now, false if it is not.
      bool GetCanStreamLiveNow();

      /// @brief Returns a vector of available stored data ranges for the camera.
      /// @param [in] enableSubset If this is set to true, then ranges will be
      ///        returned even if only a subset of the image sources for a camera
      ///        are available during this time.  This can cause gaps in the
      ///        rendered image where there is no video data.  Defaults to false.
      /// @return Vector of intervals that the system has storage for.  Note that
      /// the last one will have an end time of aqt_Interval_UNDEFINED_END if it
      /// is currently recording.  Also note that this will return data that is
      /// available but not reserved, so may be deleted as space runs out.
      ::std::vector<aqt::Interval> GetStoredDataRanges(bool enableSubset = false);

      /// @brief Returns a vector of JSON strings describing the streaming modes.
      /// @return Vector of JSON-formatted strings describing the streaming modes
      /// available on this camera.  This describes the stream type (encoding),
      /// quality level, resolution, and frame rate for zero or more streams coming
      /// from each sensor in the camera.
      ::std::string GetStreamingModes();

      /// @brief Sets a streaming mode based on its index.
      /// @param [in] mode Index of the mode (first one is 0) to set the camera in.
      ///         The available modes can be found by calling GetStreamingModes().
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetStreamingMode(uint32_t mode);

      /// @brief Sets a streaming mode based on a JSON string.
      /// @param [in] JSONConfiguration Set the streaming mode of the camera based on
      ///         the JSON-formatted configuration description.  This requires detailed
      ///         knowledge of the camera type and architecture and will not normally be
      ///         called by a client program.  It will be called by configuration utilities
      ///         supplied by the camera vendor.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetStreamingMode(::std::string JSONConfiguration);

      /// @brief Private class declared for definition and use by the API implementation.
      class Camera_private;

    private:
      Camera_private *m_private = nullptr;
    };

  } // End camera namespace

  namespace update {

    /// @brief Holds the data and methods for controlling system updates.
    ///
    /// This class controls and reports an update interface.  It wraps an
    /// aqt_Update C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// Provides determination of and updating of system software versions.
    class Update {
    public:

      /// @brief Creates an Update object.
      /// @param [in] api AquetiAPI object that the updated entity lives inside.
      /// @param [in] entityName Name of the entity to update, may be obtained by calling
      ///         aqt::AquetiAPI::GetAvailableDataRouter() or one of the GetAvailable
      ///         methods, or may be provided by the vendor.
      Update(AquetiAPI &api, ::std::string entityName);

      /// @brief Destroys an Update object.
      ~Update();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of an Update and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Returns the software version from the entity.
      ///
      /// To get the software version for the Aqueti API itself, call this on the
      /// entity named "/aqt".
      /// @return String description of the software version.
      ::std::string GetSoftwareVersion();

      /// @brief Installs new software onto the specified entity.
      /// @param [in] data Binary data that contains the new software update.
      /// @param [in] checksum String-formatted checksum description matching the update.
      ///         This will be checked against the binary data once it arrives at the
      ///         entity to verify that there have been no errors in transmission or
      ///         tampering with the data before it is installed.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Install(std::vector<uint8_t> data, std::string checksum);

      /// @brief Installs new software onto the specified entity.
      /// @param [in] dataURL URL pointing to binary data that contains the new software update.
      /// @param [in] checksumURL URL pointing to string-formatted checksum description
      ///         matching the update.
      ///         This will be checked against the binary data once it arrives at the
      ///         entity to verify that there have been no errors in transmission or
      ///         tampering with the data before it is installed.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InstallFromURL(std::string dataURL, std::string checksumURL);

      /// @brief Private class declared for definition and use by the API implementation.
      class Update_private;

    private:
      Update_private *m_private = nullptr;
    };

  } // End update namespace

  namespace externalAnalysis {

    /// @brief Holds the data for a rectangle, which describes a region on an image.
    ///
    /// This class controls and reports a rectangle.  It wraps an
    /// aqt_Rectangle C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class Rectangle {
    public:
      /// @brief Creates a Rectangle.
      Rectangle();

      /// @brief Creates a Rectangle from an aqt_Rectangle.
      /// @param [in] rectangle The aqt_Rectangle to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~Rectangle() -- Rectangle is taking ownership
      ///             of it at construction.
      Rectangle(aqt_Rectangle rectangle);

      /// @brief Destroys a Rectangle.
      ~Rectangle();

      /// @brief Copy constructor for a Rectangle, not usually needed by client code.
      /// @param [in] copy Rectangle to copy.  This performs a deep copy of the the
      ///        Rectangle to avoid double deletion.
      Rectangle(const Rectangle& copy);

      /// @brief Assignment for a Rectangle, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        Rectangle to avoid double deletion.
      Rectangle &operator = (const Rectangle &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a Rectangle and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the Rectangle.
      struct timeval Time() const;
      /// @brief Get the name of the Rectangle.
      ::std::string Name() const;
      /// @brief Get the user data string associated with the Rectangle.
      ///
      /// @brief Set the time for the image the Rectangle is associated with.
      /// @param [in] val Time for the image the Rectangle is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the Rectangle.
      /// @param [in] val Name for the Rectangle.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the normalized X location (0-1) of the center of the Rectangle.
      double XNorm() const;
      /// @brief Get the normalized Y location (0-1) of the center of the Rectangle.
      double YNorm() const;
      /// @brief Get the normalized width of the Rectangle (0-1).
      double WidthNorm() const;
      /// @brief Get the normalized height of the Rectangle (0-1).
      double HeightNorm() const;

      /// @brief Set the normalized X location (0-1) of the center of the Rectangle.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status XNorm(double val);
      /// @brief Set the normalized Y location (0-1) of the center of the Rectangle.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status YNorm(double val);
      /// @brief Set the normalized width of the Rectangle (0-1).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status WidthNorm(double val);
      /// @brief Get the normalized height of the Rectangle (0-1).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status HeightNorm(double val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_Rectangle const RawRectangle() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class Rectangle_private;

    private:
      Rectangle_private *m_private = nullptr;
    };

    /// @brief Holds the data for a point, associated with a location on an image.
    ///
    /// This class controls and reports a point.  It wraps an
    /// aqt_Point C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class Point {
    public:
      /// @brief Creates a Point.
      Point();

      /// @brief Creates a Point from an aqt_Point.
      /// @param [in] point The aqt_Point to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~Point() -- Point is taking ownership
      ///             of it at construction.
      Point(aqt_Point point);

      /// @brief Destroys a Point.
      ~Point();

      /// @brief Copy constructor for a Point, not usually needed by client code.
      /// @param [in] copy Point to copy.  This performs a deep copy of the the
      ///        Point to avoid double deletion.
      Point(const Point& copy);

      /// @brief Assignment for a Point, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        Point to avoid double deletion.
      Point &operator = (const Point &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a Point and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the image the Point is associated with.
      struct timeval Time() const;
      /// @brief Get the name of the Point.
      ::std::string Name() const;

      /// @brief Set the time for the image the Point is associated with.
      /// @param [in] val Time for the image the Point is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the Point.
      /// @param [in] val Name for the Point.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the normalized X location (0-1) of the center of the Point.
      double XNorm() const;
      /// @brief Get the normalized Y location (0-1) of the center of the Point.
      double YNorm() const;

      /// @brief Set the normalized X location (0-1) of the center of the Point.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status XNorm(double val);
      /// @brief Set the normalized Y location (0-1) of the center of the Point.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status YNorm(double val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_Point const RawPoint() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class Point_private;

    private:
      Point_private *m_private = nullptr;
    };

    /// @brief Holds the data for a FloatArray, associated with an image.
    ///
    /// This class controls and reports a FloatArray.  It wraps an
    /// aqt_FloatArray C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class FloatArray {
    public:
      /// @brief Creates a FloatArray.
      FloatArray();

      /// @brief Creates a FloatArray from an aqt_FloatArray.
      /// @param [in] floatArray The aqt_FloatArray to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~FloatArray() -- FloatArray is taking ownership
      ///             of it at construction.
      FloatArray(aqt_FloatArray floatArray);

      /// @brief Destroys a FloatArray.
      ~FloatArray();

      /// @brief Copy constructor for a FloatArray, not usually needed by client code.
      /// @param [in] copy FloatArray to copy.  This performs a deep copy of the the
      ///        FloatArray to avoid double deletion.
      FloatArray(const FloatArray& copy);

      /// @brief Assignment for a FloatArray, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        FloatArray to avoid double deletion.
      FloatArray &operator = (const FloatArray &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a FloatArray and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the image the FloatArray is associated with.
      struct timeval Time() const;
      /// @brief Get the name of the FloatArray.
      ::std::string Name() const;

      /// @brief Set the time for the image the FloatArray is associated with.
      /// @param [in] val Time for the image the FloatArray is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the FloatArray.
      /// @param [in] val Name for the FloatArray.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the value associated with this FloatArray.
      ::std::vector<float> Value() const;

      /// @brief Set the value associated with this FloatArray.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Value(::std::vector<float> val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_FloatArray const RawFloatArray() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class FloatArray_private;

    private:
      FloatArray_private *m_private = nullptr;
    };

    /// @brief Holds the data for a U8Array, associated with an image.
    ///
    /// This class controls and reports a U8Array.  It wraps an
    /// aqt_U8Array C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class U8Array {
    public:
      /// @brief Creates a U8Array.
      U8Array();

      /// @brief Creates a U8Array from an aqt_U8Array.
      /// @param [in] U8Array The aqt_U8Array to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~U8Array() -- U8Array is taking ownership
      ///             of it at construction.
      U8Array(aqt_U8Array U8Array);

      /// @brief Destroys a U8Array.
      ~U8Array();

      /// @brief Copy constructor for a U8Array, not usually needed by client code.
      /// @param [in] copy U8Array to copy.  This performs a deep copy of the the
      ///        U8Array to avoid double deletion.
      U8Array(const U8Array& copy);

      /// @brief Assignment for a U8Array, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        U8Array to avoid double deletion.
      U8Array &operator = (const U8Array &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of an U8Array and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the image the U8Array is associated with.
      struct timeval Time() const;
      /// @brief Get the name of the U8Array.
      ::std::string Name() const;

      /// @brief Set the time for the image the U8Array is associated with.
      /// @param [in] val Time for the image the U8Array is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the U8Array.
      /// @param [in] val Name for the U8Array.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the value associated with this U8Array.
      ::std::vector<uint8_t> Value() const;

      /// @brief Set the value associated with this U8Array.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Value(::std::vector<uint8_t> val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_U8Array const RawU8Array() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class U8Array_private;

    private:
      U8Array_private *m_private = nullptr;
    };

    /// @brief Holds the data for a camera model, associated with an image.
    ///
    /// This class controls and reports a CameraModel.  It wraps an
    /// aqt_CameraModel C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class CameraModel {
    public:
      /// @brief Creates a CameraModel.
      CameraModel();

      /// @brief Creates a CameraModel from an aqt_CameraModel.
      /// @param [in] cameraModel The aqt_CameraModel to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~CameraModel() -- CameraModel is taking ownership
      ///             of it at construction.
      CameraModel(aqt_CameraModel cameraModel);

      /// @brief Destroys a CameraModel.
      ~CameraModel();

      /// @brief Copy constructor for a CameraModel, not usually needed by client code.
      /// @param [in] copy CameraModel to copy.  This performs a deep copy of the the
      ///        CameraModel to avoid double deletion.
      CameraModel(const CameraModel& copy);

      /// @brief Assignment for a CameraModel, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        CameraModel to avoid double deletion.
      CameraModel &operator = (const CameraModel &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a CameraModel and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the image the CameraModel is associated with.
      struct timeval Time() const;
      /// @brief Get the name of the CameraModel.
      ::std::string Name() const;

      /// @brief Set the time for the image the CameraModel is associated with.
      /// @param [in] val Time for the image the CameraModel is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the CameraModel.
      /// @param [in] val Name for the CameraModel.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the string value associated with this CameraModel.
      ::std::string Value() const;

      /// @brief Set the string value associated with this CameraModel.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Value(::std::string val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_CameraModel const RawCameraModel() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class CameraModel_private;

    private:
      CameraModel_private *m_private = nullptr;
    };

    /// @brief Holds the data for a thumbnail, which describes a subset of an image.
    ///
    /// This class controls and reports a thumbnail.  It wraps an
    /// aqt_Thumbnail C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.

    class Thumbnail {
    public:
      /// @brief Creates a Thumbnail.
      Thumbnail();

      /// @brief Creates a Thumbnail from an aqt_Thumbnail.
      /// @param [in] thumbnail The aqt_Thumbnail to refer to when calling this
      ///             object's methods.  It is not copied on construction, but it
      ///             is destroyed in ~Thumbnail() -- Thumbnail is taking ownership
      ///             of it at construction.
      Thumbnail(aqt_Thumbnail thumbnail);

      /// @brief Destroys a Thumbnail.
      ~Thumbnail();

      /// @brief Copy constructor for a Thumbnail, not usually needed by client code.
      /// @param [in] copy Thumbnail to copy.  This performs a deep copy of the the
      ///        Thumbnail to avoid double deletion.
      Thumbnail(const Thumbnail& copy);

      /// @brief Assignment for a Thumbnail, not usually needed by client code.
      /// @param [in] copy Frame to copy.  This performs a deep copy of the
      ///        Thumbnail to avoid double deletion.
      Thumbnail &operator = (const Thumbnail &copy);

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of a Thumbnail and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus();

      /// @brief Get the time for the image the Thumbnail is associated with.
      struct timeval Time() const;
      /// @brief Get the name of the Thumbnail.
      ::std::string Name() const;

      /// @brief Set the time for the image the Thumbnail is associated with.
      /// @param [in] val Time for the image the Thumbnail is associated with.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Time(struct timeval val);

      /// @brief Set the name for the Thumbnail.
      /// @param [in] val Name for the Thumbnail.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status Name(::std::string val);

      /// @brief Get the normalized X location (0-1) of the center of the Thumbnail.
      double XNorm() const;
      /// @brief Get the normalized Y location (0-1) of the center of the Thumbnail.
      double YNorm() const;
      /// @brief Get the normalized width of the Thumbnail (0-1).
      double WidthNorm() const;
      /// @brief Get the normalized height of the Thumbnail (0-1).
      double HeightNorm() const;
      /// @brief Get the type of the image storing this Thumbnail.
      aqt_ImageType ImageType() const;
      /// @brief Get the image data storing this Thumbnail.
      ::std::vector<uint8_t> ImageData() const;

      /// @brief Set the normalized X location (0-1) of the center of the Thumbnail.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status XNorm(double val);
      /// @brief Set the normalized Y location (0-1) of the center of the Thumbnail.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status YNorm(double val);
      /// @brief Set the normalized width of the Thumbnail (0-1).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status WidthNorm(double val);
      /// @brief Get the normalized height of the Thumbnail (0-1).
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status HeightNorm(double val);
      /// @brief Set the type of the image storing this Thumbnail.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status ImageType(aqt_ImageType val);
      /// @brief Set the image data for this Thumbnail.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status ImageData(::std::vector<uint8_t> val);

      /// @brief Accessor for the passed-in information during construction, not used by client code.
      aqt_Thumbnail const RawThumbnail() const;

      /// @brief Private class declared for definition and use by the API implementation.
      class Thumbnail_private;

    private:
      Thumbnail_private *m_private = nullptr;
    };

    /// @brief Holds the data and methods for controlling external analysis.
    ///
    /// This class controls and reports a camera.  It wraps an
    /// aqt_ExternalAnalysis C structure and provides a C++ interface for it.
    /// The GetStatus() method should be called after each method (including
    /// the constructor) to make sure that the operation was a success.
    ///
    /// Provides control over reading and creating external-analysis metadata
    /// entries for entities in the system.  Includes reading and creating
    /// raw images, rectangles, points, FloatArrays, U8Arrays, CameraModels,
    /// and Thumbnails.
    ///
    /// The object is given the name of a source entity in the system from which
    /// it is to retrieve data, often a single sensor from a camera system
    /// (also known as a microcamera).
    ///
    /// Retrieval of images or metadata proceeds
    /// by calling SetStartTime() to the beginning of the interval of interest
    /// and then calling GetNext*() functions to retrieve images and/or other
    /// types of metadata until the time on the last one is later than the end
    /// of the interval desired or no more results are returned.
    ///
    /// Insertion proceeds as with retrieval but after an image or other item has
    /// been returned, results from analyzing it can be used to construct a new
    /// item (which should have the same time as the data its analysis is based
    /// on), which can then be inserted.

    class ExternalAnalysis {
    public:
      /// @brief Creates an ExternalAnalysis object.
      /// @param [in] api AquetiAPI object that the ExternalAnalysis lives inside.
      /// @param [in] sourceName Name of the entity to open, obtained from the vendor
      ///       or by calling aqt::AquetiAPI::GetAvailableCameras()
      ///       or aqt::render::RenderStream::GetSourcesPotentiallyVisibleAtLocation()
      ///       or potentially from detailed status on another entity.
      ExternalAnalysis(
        AquetiAPI &api,
        ::std::string sourceName
      );

      /// @brief Destroys an ExternalAnalysis.
      ~ExternalAnalysis();

      /// @brief Returns the status of the most-recent operation and clears error/warnings.
      ///
      /// This should be called after the construction of an ExternalAnalysis and after each method
      /// call that does not itself return an aqt_Status to ensure that the operation
      /// completed.
      /// @return aqt_Status returned by the most-recent operation on the wrapped
      ///         class, or other errors in case the Image itself is broken.
      aqt_Status GetStatus() const;

      /// @brief Sets the time to start looking for images or metadata.
      /// @param val Time on the clock for the local machine to start.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetStartTime(struct timeval val);

      /// @brief Sets the types of images to be returned.
      ///
      /// This method filters images so that only the desired types are returned.
      /// It is used along with SetMinImageSize() and SetMaxImageSize() to restrict analysis
      /// to a subset of images.
      /// @param val Vector of image types to be returned, defaults to ALL_IMAGE_TYPES.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetImageTypes(::std::vector<aqt_ImageType> val = ALL_IMAGE_TYPES);

      /// @brief Sets the minimum size of images to be returned.
      ///
      /// This method filters images so that only the desired types are returned.
      /// It is used along with SetImageTypes() and SetMaxImageSize() to restrict analysis
      /// to a subset of images.
      /// @param width Minimum width for images.  Default is 1.
      /// @param height Minimum height for images.  Default is 1.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetMinImageSize(uint32_t width, uint32_t height);

      /// @brief Sets the maximum size of images to be returned.
      ///
      /// This method filters images so that only the desired types are returned.
      /// It is used along with SetImageTypes() and SetMinImageSize() to restrict analysis
      /// to a subset of images.
      /// @param width Maximum width for images.  Default is 2^32-1.
      /// @param height Maximum height for images.  Default is 2^32-1.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetMaxImageSize(uint32_t width, uint32_t height);

      /// @brief Gets the image of the desired type and size with the next-largest time.
      /// @return Either an image of one of the requested types on success or an
      ///         empty image on failure or when there are no more images of the
      ///         requested type and size ranges.  The receiver must call ReleaseData()
      ///         on non-empty images when it is done with them to avoid leaking memory.
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      Image GetNextImage();

      /// @brief Sets a filter on the names of metadata to be returned.
      ///
      /// This method filters metadata objects so that only those with the desired name are returned.
      /// @param val Name of entries to be returned, defaults to ALL_NAMES.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status SetNameFilter(::std::string val = ALL_NAMES);

      /// @brief Gets the rectangle of the desired name with the next-largest time.
      /// @return Either a Rectangle with the desired name (on success) or a default
      ///         Rectangle (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      Rectangle GetNextRectangle();

      /// @brief Gets the point of the desired name with the next-largest time.
      /// @return Either a Point with the desired name (on success) or a default
      ///         Point (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      Point GetNextPoint();

      /// @brief Gets the FloatArray of the desired name with the next-largest time.
      /// @return Either a FloatArray with the desired name (on success) or a default
      ///         FloatArray (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      FloatArray GetNextFloatArray();

      /// @brief Gets the U8Array of the desired name with the next-largest time.
      /// @return Either a U8Array with the desired name (on success) or a default
      ///         U8Array (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      U8Array GetNextU8Array();

      /// @brief Gets the CameraModel of the desired name with the next-largest time.
      /// @return Either a CameraModel with the desired name (on success) or a default
      ///         CameraModel (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      CameraModel GetNextCameraModel();

      /// @brief Gets the Thumbnail of the desired name with the next-largest time.
      /// @return Either a Thumbnail with the desired name (on success) or a default
      ///         Thumbnail (on failure, or when there are no more).
      ///         When there are no more elements, sets the status to aqt_STATUS_NO_NEXT_ELEMENT
      ///         (which can be checked by calling GetStatus()).
      Thumbnail GetNextThumbnail();

      /// @brief Insert a new Rectangle metadata object for this entity.
      /// @param val New Rectangle to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertRectangle(const Rectangle &val);

      /// @brief Insert a new Point metadata object for this entity.
      /// @param val New Point to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertPoint(const Point &val);

      /// @brief Insert a new FloatArray metadata object for this entity.
      /// @param val New FloatArray to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertFloatArray(const FloatArray &val);

      /// @brief Insert a new U8Array metadata object for this entity.
      /// @param val New U8Array to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertU8Array(const U8Array &val);

      /// @brief Insert a new CameraModel metadata object for this entity.
      /// @param val New CameraModel to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertCameraModel(const CameraModel &val);

      /// @brief Insert a new Thumbnail metadata object for this entity.
      /// @param val New Thumbnail to be stored.
      /// @return aqt_STATUS_OKAY on success, a specific error code on failure.
      ///         GetStatus() should not be called after this method, since it is returned here.
      aqt_Status InsertThumbnail(const Thumbnail &val);

      /// @brief Private class declared for definition and use by the API implementation.
      class ExternalAnalysis_private;

    private:
      class ExternalAnalysis_private *m_private = nullptr;
    };


  } // End namespace externalAnalysis

} // End aqt namespace

/// @todo Implement multiple cameras and extrinsic parameters/poses.
