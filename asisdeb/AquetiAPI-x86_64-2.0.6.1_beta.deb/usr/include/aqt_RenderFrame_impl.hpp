/* Copyright (C) Aqueti, Inc - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 */

#pragma once

/// @todo Consider re-implementing this based on using the aqt::Image class, rather than
/// keeping the aqt_Image structure internally.

/**
* @file aqt_RenderFrame_impl.hpp
* @brief Internal implementation file.
*
* This is an internal wrapper file that should not be directly included
* by application code or by code that implements the API.
* @author Aqueti.
* @date February 2, 2018.
*/

#include <string.h>

namespace aqt {

  namespace render {

    class RenderFrame::RenderFrame_private {
    public:
      aqt_RenderFrame frame = nullptr;
      aqt_Status status = aqt_STATUS_OKAY;
    };

    RenderFrame::RenderFrame()
    {
      m_private = new RenderFrame_private;
      m_private->status = aqt_RenderFrameCreate(&m_private->frame);
    }

    RenderFrame::RenderFrame(aqt_RenderFrame frame)
    {
      m_private = new RenderFrame_private;
      if (!frame) {
        m_private->status = aqt_STATUS_BAD_PARAMETER;
        return;
      }
      m_private->status = aqt_RenderFrameCopy(&m_private->frame, frame);
    }

    RenderFrame::~RenderFrame()
    {
      if (m_private) {
        if (m_private->frame) {
          aqt_RenderFrameDestroy(m_private->frame);
        }
        delete m_private;
      }
    }

    RenderFrame::RenderFrame(const RenderFrame &copy)
    {
      m_private = new RenderFrame_private();
      m_private->status = aqt_RenderFrameCopy(&m_private->frame, copy.RawFrame());
    }

    RenderFrame &RenderFrame::operator = (const RenderFrame &copy)
    {
      // Get rid of any pre-existing data that we have.
      if (m_private) {
        if (m_private->frame) {
          aqt_RenderFrameDestroy(m_private->frame);
        }
        delete m_private;
      }

      m_private = new RenderFrame_private();
      m_private->status = aqt_RenderFrameCopy(&m_private->frame, copy.RawFrame());
      return *this;
    }

    aqt_Status RenderFrame::GetStatus()
    {
      if (!m_private) {
        return aqt_STATUS_NULL_OBJECT_POINTER;
      }
      return m_private->status;
    }

    uint32_t RenderFrame::Width() const
    {
      uint32_t ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      m_private->status = aqt_ImageGetWidth(image, &ret);
      return ret;
    }

    uint32_t RenderFrame::Height() const
    {
      uint32_t ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      m_private->status = aqt_ImageGetHeight(image, &ret);
      return ret;
    }

    aqt_ImageType RenderFrame::Type() const
    {
      aqt_ImageType ret = aqt_EMPTY_IMAGE;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      m_private->status = aqt_ImageGetType(image, &ret);
      return ret;
    }

    struct timeval RenderFrame::Time() const
    {
      struct timeval ret = {};
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      m_private->status = aqt_ImageGetTime(image, &ret);
      return ret;
    }

    const uint8_t *RenderFrame::Data() const
    {
      const uint8_t *ret = nullptr;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      uint32_t size;
      m_private->status = aqt_ImageGetData(image, &ret, &size);
      return ret;
    }

    uint32_t RenderFrame::Size() const
    {
      uint32_t ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return ret;
      }
      const uint8_t *data;
      m_private->status = aqt_ImageGetData(image, &data, &ret);
      return ret;
    }

    void RenderFrame::ReleaseData()
    {
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return;
      }
      aqt_Image image;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetImage(m_private->frame, &image))) {
        return;
      }
      m_private->status = aqt_ImageReleaseData(image);
      return;
    }

    double RenderFrame::Pan() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetPan(info, &ret);
      return ret;
    }

    double RenderFrame::Tilt() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetTilt(info, &ret);
      return ret;
    }

    double RenderFrame::Zoom() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetZoom(info, &ret);
      return ret;
    }

    double RenderFrame::HFOV() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetHFOV(info, &ret);
      return ret;
    }

    double RenderFrame::VFOV() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetVFOV(info, &ret);
      return ret;
    }

    double RenderFrame::SubsetMinX() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetSubsetMinX(info, &ret);
      return ret;
    }

    double RenderFrame::SubsetMinY() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetSubsetMinY(info, &ret);
      return ret;
    }

    double RenderFrame::SubsetMaxX() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetSubsetMaxX(info, &ret);
      return ret;
    }

    double RenderFrame::SubsetMaxY() const
    {
      double ret = 0;
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetSubsetMaxY(info, &ret);
      return ret;
    }

    struct timeval RenderFrame::RenderStartTime() const
    {
      struct timeval ret = {};
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      aqt_RenderStateInfo info;
      if (aqt_STATUS_OKAY !=
        (m_private->status = aqt_RenderFrameGetState(m_private->frame, &info))) {
        return ret;
      }

      m_private->status = aqt_RenderStateInfoGetRenderStartTime(info, &ret);
      return ret;
    }

    aqt_RenderFrame const RenderFrame::RawFrame() const
    {
      aqt_RenderFrame ret = nullptr;
      if (!m_private) {
        return ret;
      }
      if (!m_private->frame) {
        m_private->status = aqt_STATUS_NULL_OBJECT_POINTER;
        return ret;
      }
      m_private->status = aqt_STATUS_OKAY;
      return m_private->frame;
    }

  } // End namespace render

} // End namespace aqt

