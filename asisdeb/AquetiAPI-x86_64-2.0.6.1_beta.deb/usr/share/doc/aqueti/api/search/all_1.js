var searchData=
[
  ['boolparameter',['BoolParameter',['../classaqt_1_1render_1_1RenderStream.html#ad1a365b3752d56b0b37211cb129d6fdd',1,'aqt::render::RenderStream::BoolParameter(aqt_RenderBoolShaderParamType which)'],['../classaqt_1_1render_1_1RenderStream.html#a542dace2844ddf7f86789b50352faacf',1,'aqt::render::RenderStream::BoolParameter(aqt_RenderBoolShaderParamType which, bool newVal)']]]
];
