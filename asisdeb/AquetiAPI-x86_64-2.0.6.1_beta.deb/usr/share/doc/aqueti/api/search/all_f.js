var searchData=
[
  ['quality',['Quality',['../classaqt_1_1StreamProperties.html#a08ce6ff42b9d3f2c36b7b3bb4ecb57be',1,'aqt::StreamProperties::Quality()'],['../classaqt_1_1StreamProperties.html#a96228647f7122a782a4d0e5a754eae9e',1,'aqt::StreamProperties::Quality(double quality)']]]
];
